// =====================================================
// نظام حماية البيانات - التأكد من حفظ البيانات
// يحل مشكلة ضياع البيانات بعد تسجيل الخروج/الدخول
// =====================================================

const Persistence = {
  // ===== تشخيص =====
  diagnose: () => {
    const report = {
      localStorage: typeof localStorage !== 'undefined',
      keys: {},
      browser: navigator.userAgent,
      online: navigator.onLine,
      timestamp: new Date().toISOString(),
    };

    Object.values(DB_KEYS).forEach(key => {
      const val = localStorage.getItem(key);
      report.keys[key] = {
        exists: val !== null,
        size: val ? val.length : 0,
      };
    });

    console.log('[Persistence] Diagnostic Report:', report);
    return report;
  },

  // ===== التحقق هل البيانات موجودة قبل أي عملية حساسة =====
  checkData: () => {
    const products = Products.all();
    const users = Users.all();
    const sales = Sales.all();
    return {
      products: products.length,
      users: users.length,
      sales: sales.length,
    };
  },

  // ===== حماية ضد الحذف التلقائي =====
  // نتأكد إن Service Worker ما يمسح localStorage
  protect: () => {
    // حفظ علامة إن البيانات محفوظة
    const lastSave = localStorage.getItem('__last_data_check__');
    const stats = Persistence.checkData();
    localStorage.setItem('__last_data_check__', JSON.stringify({
      ...stats,
      ts: Date.now(),
    }));

    // تنبيه إذا البيانات اختفت
    if (lastSave) {
      try {
        const old = JSON.parse(lastSave);
        if (old.products > 0 && stats.products === 0) {
          console.error('[Persistence] WARNING: Products disappeared!', old, stats);
          toast('⚠️ تم اكتشاف ضياع في البيانات! يُنصح بأخذ نسخة احتياطية فوراً', 'error', 6000);
        }
      } catch (e) {}
    }
  },

  // ===== استعادة البيانات من نسخة احتياطية محلية =====
  hasLocalBackup: () => {
    return localStorage.getItem('__local_backup__') !== null;
  },

  createLocalBackup: () => {
    try {
      const backup = {};
      Object.values(DB_KEYS).forEach(key => {
        const val = localStorage.getItem(key);
        if (val) backup[key] = val;
      });
      localStorage.setItem('__local_backup__', JSON.stringify({
        data: backup,
        createdAt: new Date().toISOString(),
        stats: Persistence.checkData(),
      }));
      console.log('[Persistence] Local backup created');
      return true;
    } catch (e) {
      console.error('[Persistence] Local backup failed:', e);
      return false;
    }
  },

  restoreLocalBackup: () => {
    try {
      const raw = localStorage.getItem('__local_backup__');
      if (!raw) return false;
      const backup = JSON.parse(raw);
      Object.entries(backup.data).forEach(([key, value]) => {
        localStorage.setItem(key, value);
      });
      console.log('[Persistence] Local backup restored');
      return true;
    } catch (e) {
      console.error('[Persistence] Local backup restore failed:', e);
      return false;
    }
  },

  // ===== حفظ تلقائي بعد كل عملية =====
  // نعمل override على dbSet و dbGet
  init: () => {
    // فحص أولي
    Persistence.protect();
    Persistence.diagnose();

    // ملاحظة: لا نغير dbSet/dbGet لأن باقي الكود يعتمد عليها
    // لكن نضيف مستمع للحفظ
    const originalSetItem = Storage.prototype.setItem;
    Storage.prototype.setItem = function (key, value) {
      originalSetItem.call(this, key, value);
      // نسجل آخر حفظ لكل عملية
      if (key && key.startsWith('pos_') && key !== '__last_data_check__') {
        // نسجل الوقت
        const saves = JSON.parse(localStorage.getItem('__save_log__') || '[]');
        saves.unshift({ key, ts: Date.now() });
        localStorage.setItem('__save_log__', JSON.stringify(saves.slice(0, 20)));
      }
    };

    console.log('[Persistence] Protection initialized');
  },

  // ===== عرض تقرير الحالة =====
  showStatus: () => {
    const stats = Persistence.checkData();
    const storageUsed = Object.values(DB_KEYS).reduce((sum, k) => {
      const v = localStorage.getItem(k);
      return sum + (v ? v.length : 0);
    }, 0);

    const content = `
      <div style="display:grid;gap:0.75rem;">
        <div style="background:var(--primary-light);padding:1rem;border-radius:8px;">
          <h3 style="margin:0 0 0.5rem;">📊 حالة البيانات</h3>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:0.5rem;">
            <div>👥 المستخدمون: <strong>${stats.users}</strong></div>
            <div>📦 المنتجات: <strong>${stats.products}</strong></div>
            <div>💰 المبيعات: <strong>${stats.sales}</strong></div>
            <div>💾 حجم التخزين: <strong>${(storageUsed / 1024).toFixed(1)} KB</strong></div>
          </div>
        </div>

        <div style="background:var(--success-light);padding:1rem;border-radius:8px;border-inline-start:4px solid var(--success);">
          <strong>✅ البيانات محفوظة في متصفحك</strong>
          <p style="margin:0.3rem 0 0;color:var(--text-muted);font-size:0.9rem;">
            كل ما تدخله يبقى محفوظاً حتى بعد تسجيل الخروج وإغلاق المتصفح.
            <br>⚠️ مسح بيانات المتصفح أو عمل "إعادة تعيين" يحذفها.
          </p>
        </div>

        <div style="background:var(--warning-light);padding:1rem;border-radius:8px;">
          <strong>🛡️ نسخة أمان محلية</strong>
          <p style="margin:0.3rem 0;color:var(--text-muted);font-size:0.9rem;">
            تنشأ تلقائياً. لو صارت مشكلة، تقدر تستعيدها.
          </p>
          <div style="display:flex;gap:0.5rem;margin-top:0.5rem;flex-wrap:wrap;">
            <button class="btn btn-sm btn-primary" id="createLocalBackupBtn">💾 إنشاء نسخة أمان</button>
            ${Persistence.hasLocalBackup() ? '<button class="btn btn-sm btn-warning" id="restoreLocalBackupBtn">🔄 استعادة من نسخة الأمان</button>' : ''}
          </div>
        </div>

        <div style="background:var(--danger-light);padding:1rem;border-radius:8px;border-inline-start:4px solid var(--danger);">
          <strong>⚠️ تحذير مهم</strong>
          <p style="margin:0.3rem 0;color:var(--text-muted);font-size:0.9rem;">
            <b>لا تضغط زر "إعادة تعيين البيانات"</b> في صفحة الدخول — هذا يمسح كل شي.
            <br>ولو تستخدم وضع التصفح الخاص (Incognito)، البيانات تنحذف لما تقفل النافذة.
          </p>
        </div>
      </div>
    `;
    openModal('💾 حالة حفظ البيانات', content, { large: true });

    document.getElementById('createLocalBackupBtn')?.addEventListener('click', () => {
      if (Persistence.createLocalBackup()) {
        toast('✅ تم إنشاء نسخة الأمان', 'success');
        Persistence.showStatus();
      } else {
        toast('❌ فشل إنشاء النسخة', 'error');
      }
    });
    document.getElementById('restoreLocalBackupBtn')?.addEventListener('click', () => {
      if (confirm('استعادة البيانات من نسخة الأمان؟')) {
        if (Persistence.restoreLocalBackup()) {
          toast('✅ تم الاستعادة - جاري التحديث', 'success');
          setTimeout(() => location.reload(), 1500);
        } else {
          toast('❌ فشل الاستعادة', 'error');
        }
      }
    });
  },
};

// تشغيل تلقائي
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', Persistence.init);
} else {
  Persistence.init();
}
