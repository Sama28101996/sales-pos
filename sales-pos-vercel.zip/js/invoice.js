// =====================================================
// توليد فاتورة PDF
// =====================================================

const Invoice = {
  generate: (sale) => {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    const settings = Settings.get();
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const storeName = settings.storeName || 'My Store';

    // ====== الشعار خلفية (شبه شفاف، يغطي كل الصفحة) ======
    if (settings.logoBase64) {
      try {
        // نقسم الشعار لـ 4 أرباع ونضع كل ربع بشفافية عالية
        // الطريقة الأبسط: نضع الشعار وسط الصفحة بحجم كبير بشفافية 0.06
        const logoSize = Math.min(pageWidth, pageHeight) * 0.6; // 60% من أصغر بُعد
        const logoX = (pageWidth - logoSize) / 2;
        const logoY = (pageHeight - logoSize) / 2;
        // png يشتغل مع addImage، opacity عن طريق setGState
        // jsPDF يدعم الشفافية عبر setGState لو احتجنا
        const png = settings.logoBase64;
        // لو الشعار SVG نتجاهله (jsPDF ما يدعمه بشكل مباشر)
        if (png.startsWith('data:image/png') || png.startsWith('data:image/jpeg')) {
          doc.saveGraphicsState();
          // setGState مع opacity (jsPDF v2+)
          if (typeof doc.setGState === 'function') {
            try {
              doc.setGState(new doc.GState({ opacity: 0.07 }));
            } catch (e) {
              // fallback: استخدم alpha channel
            }
          }
          doc.addImage(png, 'PNG', logoX, logoY, logoSize, logoSize, undefined, 'FAST');
          doc.restoreGraphicsState();
        }
      } catch (e) {
        console.warn('Failed to add logo', e);
      }
    }

    // ====== الترويسة ======
    doc.setFontSize(20);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(37, 99, 235);
    doc.text(storeName, pageWidth / 2, 18, { align: 'center' });

    doc.setFontSize(10);
    doc.setTextColor(100, 100, 100);
    doc.setFont('helvetica', 'normal');
    if (settings.storePhone) {
      doc.text(`Phone: ${settings.storePhone}`, pageWidth / 2, 24, { align: 'center' });
    }
    if (settings.storeAddress) {
      doc.text(settings.storeAddress, pageWidth / 2, 29, { align: 'center' });
    }

    // خط فاصل
    doc.setDrawColor(37, 99, 235);
    doc.setLineWidth(0.5);
    doc.line(15, 33, pageWidth - 15, 33);

    // ====== عنوان الفاتورة ======
    doc.setFontSize(18);
    doc.setTextColor(15, 23, 42);
    doc.setFont('helvetica', 'bold');
    doc.text('SALES INVOICE', pageWidth / 2, 42, { align: 'center' });

    // ====== معلومات الفاتورة ======
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(50, 50, 50);
    const date = new Date(sale.createdAt);
    doc.text(`Invoice No: ${sale.invoiceNo}`, 15, 52);
    doc.text(`Date: ${date.toLocaleString('en-GB')}`, pageWidth - 15, 52, { align: 'right' });

    doc.text(`Customer: ${sale.customerName || 'Walk-in'}`, 15, 58);
    doc.text(`Type: ${sale.type === 'cash' ? 'CASH' : 'CREDIT'}`, pageWidth - 15, 58, { align: 'right' });

    doc.text(`Seller: ${sale.sellerName || '-'}`, 15, 64);

    // ====== ملاحظة (إن وُجدت) ======
    let tableTop = 75;
    if (sale.note && sale.note.trim()) {
      doc.setFillColor(254, 249, 195); // خلفية صفراء فاتحة
      doc.setDrawColor(250, 204, 21);
      doc.roundedRect(15, 68, pageWidth - 30, 10, 1.5, 1.5, 'FD');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      doc.setTextColor(133, 77, 14);
      doc.text('NOTE:', 17, 73.5);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(50, 50, 50);
      const noteText = truncateText(doc, sale.note, 130);
      doc.text(noteText, 32, 73.5);
      tableTop = 82;
    }

    // ====== جدول الأصناف ======
    doc.setFillColor(241, 245, 249);
    doc.rect(15, tableTop, pageWidth - 30, 8, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(15, 23, 42);
    doc.text('Product', 17, tableTop + 5.5);
    doc.text('Qty', 110, tableTop + 5.5, { align: 'center' });
    doc.text('Price', 140, tableTop + 5.5, { align: 'center' });
    doc.text('Total', pageWidth - 17, tableTop + 5.5, { align: 'right' });

    // الصفوف
    let y = tableTop + 14;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(50, 50, 50);

    sale.items.forEach((item, idx) => {
      if (idx % 2 === 0) {
        doc.setFillColor(250, 250, 250);
        doc.rect(15, y - 5, pageWidth - 30, 7, 'F');
      }
      doc.text(truncateText(doc, item.name, 70), 17, y);
      doc.text(String(item.qty), 110, y, { align: 'center' });
      doc.text(`${item.price.toFixed(2)} د.ع`, 140, y, { align: 'center' });
      doc.text(`${item.subtotal.toFixed(2)} د.ع`, pageWidth - 17, y, { align: 'right' });
      y += 7;

      // سطر تكلفة
      doc.setFontSize(7);
      doc.setTextColor(120, 120, 120);
      doc.text(`Cost: ${item.cost.toFixed(2)} $ | Barcode: ${item.barcode || '-'}`, 17, y - 1);
      doc.setFontSize(9);
      doc.setTextColor(50, 50, 50);
      y += 3;
    });

    // خط
    y += 3;
    doc.setDrawColor(200, 200, 200);
    doc.line(15, y, pageWidth - 15, y);

    // ====== الإجماليات ======
    y += 8;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);

    const total = sale.total;
    const cost = sale.items.reduce((s, i) => s + (i.cost * i.qty), 0);
    const profit = total - cost;

    doc.setTextColor(50, 50, 50);
    doc.text('Total Cost:', pageWidth - 60, y, { align: 'right' });
    doc.text(`${cost.toFixed(2)} د.ع`, pageWidth - 17, y, { align: 'right' });
    y += 7;

    doc.text('Total Sales:', pageWidth - 60, y, { align: 'right' });
    doc.text(`${total.toFixed(2)} د.ع`, pageWidth - 17, y, { align: 'right' });
    y += 7;

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(16, 185, 129);
    doc.text('Net Profit:', pageWidth - 60, y, { align: 'right' });
    doc.text(`${profit.toFixed(2)} د.ع`, pageWidth - 17, y, { align: 'right' });
    y += 10;

    if (sale.type === 'debt') {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(10);
      doc.setTextColor(50, 50, 50);
      doc.text('Paid Amount:', pageWidth - 60, y, { align: 'right' });
      doc.text(`${(sale.paidAmount || 0).toFixed(2)} د.ع`, pageWidth - 17, y, { align: 'right' });
      y += 7;

      doc.setFont('helvetica', 'bold');
      doc.setTextColor(239, 68, 68);
      doc.text('Remaining:', pageWidth - 60, y, { align: 'right' });
      doc.text(`${(sale.remainingAmount || 0).toFixed(2)} د.ع`, pageWidth - 17, y, { align: 'right' });
      y += 10;
    }

    // ====== الملاحظات الأساسية (فوق) ======
    if (settings.primaryNotes) {
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(11);
      doc.setTextColor(37, 99, 235);
      // نقسم النص الطويل لأسطر
      const primaryLines = doc.splitTextToSize(settings.primaryNotes, pageWidth - 40);
      let pnY = pageHeight - 45;
      primaryLines.forEach(line => {
        doc.text(line, pageWidth / 2, pnY, { align: 'center' });
        pnY += 5.5;
      });
    }

    // ====== الملاحظات الثانوية (تحت الأساسية) ======
    if (settings.secondaryNotes) {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(120, 120, 120);
      const secondaryLines = doc.splitTextToSize(settings.secondaryNotes, pageWidth - 40);
      let snY = pageHeight - 25;
      secondaryLines.forEach(line => {
        doc.text(line, pageWidth / 2, snY, { align: 'center' });
        snY += 4;
      });
    }

    // ====== التذييل الافتراضي (إذا لا توجد ملاحظات) ======
    if (!settings.primaryNotes && !settings.secondaryNotes) {
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(8);
      doc.setTextColor(150, 150, 150);
      doc.text('Thank you for your business!', pageWidth / 2, pageHeight - 15, { align: 'center' });
    }
    doc.setFontSize(7);
    doc.setTextColor(150, 150, 150);
    doc.text(`Generated: ${new Date().toLocaleString('en-GB')}`, pageWidth / 2, pageHeight - 8, { align: 'center' });

    // حفظ
    const filename = `Invoice_${sale.invoiceNo}.pdf`;
    doc.save(filename);
    toast(`تم تحميل الفاتورة ${filename}`, 'success');
  },

  viewDetails: (sale) => {
    const settings = Settings.get();
    const content = `
      <div style="background:var(--bg);padding:1rem;border-radius:8px;margin-bottom:1rem;">
        <div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:0.5rem;">
          <div>
            <h3>${sale.invoiceNo}</h3>
            <p style="color:var(--text-muted);">${new Date(sale.createdAt).toLocaleString('ar-EG')}</p>
          </div>
          <div style="text-align:left;">
            ${sale.type === 'cash' ? '<span class="badge badge-success">نقدي</span>' : '<span class="badge badge-warning">آجل</span>'}
          </div>
        </div>
        <hr style="margin:0.5rem 0;border:none;border-top:1px solid var(--border);" />
        <p><strong>العميل:</strong> د.ع{escapeHtml(sale.customerName)}</p>
        <p><strong>البائع:</strong> د.ع{escapeHtml(sale.sellerName)}</p>
        ${sale.note && sale.note.trim() ? `
          <div style="margin-top:0.6rem;padding:0.6rem 0.8rem;background:#fef9c3;border-right:3px solid #facc15;border-radius:6px;">
            <strong style="color:#854d0e;">📝 ملاحظة:</strong>
            <div style="color:#1e293b;margin-top:0.25rem;white-space:pre-wrap;line-height:1.5;">${escapeHtml(sale.note)}</div>
          </div>
        ` : ''}
      </div>

      <h4>الأصناف:</h4>
      <table>
        <thead>
          <tr>
            <th>المنتج</th>
            <th>الكمية</th>
            <th>السعر</th>
            <th>الإجمالي</th>
          </tr>
        </thead>
        <tbody>
          ${sale.items.map(i => `
            <tr>
              <td>${escapeHtml(i.name)}</td>
              <td>${i.qty}</td>
              <td>${i.price.toFixed(2)} $</td>
              <td>${i.subtotal.toFixed(2)} $</td>
            </tr>
          `).join('')}
        </tbody>
      </table>

      <div style="margin-top:1rem;background:var(--primary-light);padding:1rem;border-radius:8px;">
        <div style="display:flex;justify-content:space-between;font-size:1.2rem;font-weight:700;">
          <span>الإجمالي:</span>
          <span>${sale.total.toFixed(2)} $</span>
        </div>
        ${sale.type === 'debt' ? `
          <div style="display:flex;justify-content:space-between;margin-top:0.5rem;color:var(--success);">
            <span>المدفوع:</span>
            <span>${(sale.paidAmount || 0).toFixed(2)} $</span>
          </div>
          <div style="display:flex;justify-content:space-between;color:var(--danger);font-weight:600;">
            <span>المتبقي:</span>
            <span>${(sale.remainingAmount || 0).toFixed(2)} $</span>
          </div>
        ` : ''}
      </div>

      ${settings.primaryNotes || settings.secondaryNotes ? `
        <div style="margin-top:1rem;padding:0.75rem;background:#f8fafc;border-radius:6px;border-right:3px solid var(--primary);">
          ${settings.primaryNotes ? `<p style="margin:0;font-weight:600;color:var(--primary);">${escapeHtml(settings.primaryNotes)}</p>` : ''}
          ${settings.secondaryNotes ? `<p style="margin:0.5rem 0 0;font-size:0.85rem;color:var(--text-muted);">${escapeHtml(settings.secondaryNotes)}</p>` : ''}
        </div>
      ` : ''}

      <div style="margin-top:1rem;display:flex;gap:0.5rem;justify-content:flex-start;flex-wrap:wrap;">
        <button class="btn btn-primary" id="dlInvoiceBtn">📥 تحميل PDF</button>
        <button class="btn btn-success" id="printInvoiceBtn">🖨️ طباعة فورية</button>
        <button class="btn btn-info" id="shareInvoiceBtn">📤 مشاركة</button>
        <button class="btn btn-ghost" data-close="genericModal">إغلاق</button>
      </div>
    `;
    openModal('تفاصيل الفاتورة', content);
    document.getElementById('dlInvoiceBtn')?.addEventListener('click', () => Invoice.generate(sale));
    document.getElementById('printInvoiceBtn')?.addEventListener('click', () => Invoice.print(sale));
    document.getElementById('shareInvoiceBtn')?.addEventListener('click', () => Invoice.share(sale));
  },

  // ===== الطباعة الفورية =====
  print: (sale) => {
    const settings = Settings.get();
    const printWindow = window.open('', '_blank', 'width=800,height=900');
    if (!printWindow) {
      toast('يرجى السماح بالنوافذ المنبثقة للطباعة', 'warning');
      return;
    }

    const itemsHtml = sale.items.map((i, idx) => `
      <tr>
        <td style="text-align:center;">${idx + 1}</td>
        <td>${escapeHtml(i.name)}</td>
        <td style="text-align:center;">${i.qty}</td>
        <td style="text-align:left;">${i.price.toFixed(2)}</td>
        <td style="text-align:left;font-weight:600;">${i.subtotal.toFixed(2)}</td>
      </tr>
    `).join('');

    const html = `
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <title>فاتورة ${sale.invoiceNo}</title>
  <style>
    @page { size: A4; margin: 8mm; }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif;
      color: #0f172a;
      line-height: 1.5;
      padding: 12mm;
      background: #fff;
    }
    .invoice-box {
      max-width: 800px;
      margin: 0 auto;
    }
    .header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      border-bottom: 3px solid #2563eb;
      padding-bottom: 12px;
      margin-bottom: 16px;
      position: relative;
      z-index: 2;
    }
    .store-logo {
      max-width: 80px;
      max-height: 80px;
      object-fit: contain;
      margin-bottom: 6px;
      display: block;
    }
    .store-info h1 {
      color: #2563eb;
      font-size: 22px;
      margin: 0;
    }
    .watermark {
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%) rotate(-30deg);
      z-index: 1;
      pointer-events: none;
      opacity: 0.08;
      max-width: 70%;
      max-height: 70%;
    }
    .watermark img {
      max-width: 500px;
      max-height: 500px;
      width: 100%;
      object-fit: contain;
    }
    .invoice-box {
      max-width: 800px;
      margin: 0 auto;
      position: relative;
      z-index: 2;
    }
    .store-info p {
      font-size: 12px;
      color: #64748b;
      margin-top: 2px;
    }
    .invoice-info {
      text-align: left;
    }
    .invoice-info h2 {
      color: #2563eb;
      font-size: 18px;
    }
    .invoice-info p {
      font-size: 12px;
      color: #64748b;
    }
    .invoice-info .badge {
      display: inline-block;
      padding: 2px 10px;
      border-radius: 12px;
      font-size: 11px;
      font-weight: 700;
      margin-top: 4px;
    }
    .badge-cash { background: #d1fae5; color: #065f46; }
    .badge-debt { background: #fef3c7; color: #92400e; }
    .meta-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
      margin-bottom: 16px;
      padding: 10px;
      background: #f8fafc;
      border-radius: 6px;
      font-size: 13px;
    }
    .meta-grid div { padding: 2px 0; }
    .meta-grid strong { color: #475569; }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 14px;
      font-size: 13px;
    }
    th {
      background: #2563eb;
      color: #fff;
      padding: 8px 6px;
      font-weight: 600;
      font-size: 12px;
    }
    th:first-child { border-top-right-radius: 4px; }
    th:last-child { border-top-left-radius: 4px; }
    td {
      padding: 7px 6px;
      border-bottom: 1px solid #e2e8f0;
    }
    tbody tr:nth-child(even) { background: #f8fafc; }
    .totals {
      margin-top: 10px;
      padding: 10px 14px;
      background: #f1f5f9;
      border-radius: 6px;
      font-size: 14px;
    }
    .totals .row {
      display: flex;
      justify-content: space-between;
      padding: 3px 0;
    }
    .totals .row.grand {
      font-size: 18px;
      font-weight: 700;
      color: #2563eb;
      border-top: 2px dashed #cbd5e1;
      margin-top: 6px;
      padding-top: 8px;
    }
    .totals .paid { color: #10b981; }
    .totals .remaining { color: #ef4444; font-weight: 700; }
    .footer {
      margin-top: 30px;
      padding-top: 14px;
      border-top: 1px solid #e2e8f0;
      text-align: center;
      font-size: 12px;
      color: #64748b;
    }
    .footer .primary {
      font-weight: 700;
      color: #2563eb;
      font-size: 13px;
      margin-bottom: 4px;
    }
    .footer .stamp {
      display: inline-block;
      margin-top: 30px;
      padding: 6px 20px;
      border: 2px dashed #94a3b8;
      border-radius: 6px;
      color: #94a3b8;
      font-size: 11px;
    }
    @media print {
      body { padding: 0; }
      .no-print { display: none !important; }
    }
    .no-print {
      text-align: center;
      margin: 20px 0;
      padding: 10px;
      background: #fef3c7;
      border-radius: 6px;
      font-size: 13px;
    }
    .no-print button {
      background: #2563eb;
      color: #fff;
      border: none;
      padding: 10px 24px;
      border-radius: 6px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      font-family: inherit;
      margin: 0 4px;
    }
    .no-print button.close {
      background: #64748b;
    }
  </style>
</head>
<body>
  <div class="no-print">
    🖨️ <strong>جاهزة للطباعة</strong> — اضغط الزر أو Ctrl+P
    <br><br>
    <button onclick="window.print()">🖨️ طباعة الآن</button>
    <button class="close" onclick="window.close()">✕ إغلاق</button>
  </div>

  <div class="invoice-box">
    ${settings.logoBase64 ? `<div class="watermark"><img src="${settings.logoBase64}" alt="watermark" /></div>` : ''}
    <div class="header">
      <div class="store-info">
        ${settings.logoBase64 ? `<img src="${settings.logoBase64}" class="store-logo" alt="شعار المتجر" />` : ''}
        <h1>${escapeHtml(settings.storeName || 'متجري')}</h1>
        ${settings.storePhone ? `<p>📞 ${escapeHtml(settings.storePhone)}</p>` : ''}
        ${settings.storeAddress ? `<p>📍 ${escapeHtml(settings.storeAddress)}</p>` : ''}
      </div>
      <div class="invoice-info">
        <h2>فاتورة ${sale.invoiceNo}</h2>
        <p>${new Date(sale.createdAt).toLocaleString('ar-EG')}</p>
        <div>
          <span class="badge ${sale.type === 'cash' ? 'badge-cash' : 'badge-debt'}">
            ${sale.type === 'cash' ? '💵 نقدي' : '📝 آجل'}
          </span>
        </div>
      </div>
    </div>

    <div class="meta-grid">
      <div><strong>العميل:</strong> د.ع{escapeHtml(sale.customerName)}</div>
      <div><strong>البائع:</strong> د.ع{escapeHtml(sale.sellerName || '—')}</div>
    </div>

    <table>
      <thead>
        <tr>
          <th style="width:40px;">#</th>
          <th>المنتج</th>
          <th style="width:60px;">الكمية</th>
          <th style="width:80px;">السعر</th>
          <th style="width:100px;">الإجمالي</th>
        </tr>
      </thead>
      <tbody>
        ${itemsHtml}
      </tbody>
    </table>

    <div class="totals">
      <div class="row">
        <span>عدد الأصناف:</span>
        <strong>${sale.items.length}</strong>
      </div>
      ${sale.discount > 0 ? `
        <div class="row">
          <span>الخصم:</span>
          <strong style="color:#f59e0b;">- ${sale.discount.toFixed(2)}</strong>
        </div>
      ` : ''}
      <div class="row grand">
        <span>الإجمالي الكلي:</span>
        <span>${sale.total.toFixed(2)} ${settings.currency || '$'}</span>
      </div>
      ${sale.type === 'debt' ? `
        <div class="row paid">
          <span>المدفوع:</span>
          <span>${(sale.paidAmount || 0).toFixed(2)} ${settings.currency || '$'}</span>
        </div>
        <div class="row remaining">
          <span>المتبقي (دين):</span>
          <span>${(sale.remainingAmount || 0).toFixed(2)} ${settings.currency || '$'}</span>
        </div>
      ` : ''}
    </div>

    ${(settings.primaryNotes || settings.secondaryNotes) ? `
      <div style="margin-top:14px;padding:10px;background:#f8fafc;border-right:3px solid #2563eb;border-radius:4px;font-size:12px;">
        ${settings.primaryNotes ? `<p style="font-weight:700;color:#2563eb;margin:0;">${escapeHtml(settings.primaryNotes)}</p>` : ''}
        ${settings.secondaryNotes ? `<p style="color:#64748b;margin:4px 0 0;">${escapeHtml(settings.secondaryNotes)}</p>` : ''}
      </div>
    ` : ''}

    <div class="footer">
      ${settings.primaryNotes ? `<div class="primary">${escapeHtml(settings.primaryNotes)}</div>` : `
        <div class="primary">شكراً لزيارتكم ❤️</div>
      `}
      ${settings.secondaryNotes ? `<div>${escapeHtml(settings.secondaryNotes)}</div>` : '<div>نتطلع لخدمتكم مرة ثانية</div>'}
      <div class="stamp">ختم المتجر</div>
    </div>
  </div>

  <script>
    // طباعة تلقائية بعد التحميل
    window.addEventListener('load', () => {
      setTimeout(() => {
        if (window.opener || confirm('طباعة الفاتورة الآن؟')) {
          window.print();
        }
      }, 500);
    });
  <\/script>
</body>
</html>
    `;

    printWindow.document.write(html);
    printWindow.document.close();
  },

  // ===== مشاركة الفاتورة =====
  share: async (sale) => {
    const settings = Settings.get();
    const total = sale.total.toFixed(2);
    const text = `🧾 *فاتورة ${sale.invoiceNo}*\n` +
      `📅 ${new Date(sale.createdAt).toLocaleString('ar-EG')}\n` +
      `👤 العميل: ${sale.customerName}\n` +
      `💰 الإجمالي: *${total} ${settings.currency || '$'}*\n` +
      `${sale.type === 'cash' ? '✅ دفع نقدي' : `📝 دين: ${(sale.remainingAmount || 0).toFixed(2)}`}\n` +
      `🏪 ${settings.storeName || 'متجرنا'}`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: `فاتورة ${sale.invoiceNo}`,
          text: text,
        });
        toast('✅ تمت المشاركة', 'success');
      } catch (e) {
        // المستخدم ألغى
      }
    } else if (navigator.clipboard) {
      try {
        await navigator.clipboard.writeText(text);
        toast('📋 تم نسخ الفاتورة للحافظة - الصقها بأي مكان', 'success', 3000);
      } catch (e) {
        toast('فشل النسخ', 'error');
      }
    } else {
      // fallback
      const ta = document.createElement('textarea');
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
      toast('📋 تم نسخ الفاتورة', 'success');
    }
  },
};

function truncateText(doc, text, maxWidth) {
  if (doc.getTextWidth(text) <= maxWidth) return text;
  let truncated = text;
  while (doc.getTextWidth(truncated + '...') > maxWidth && truncated.length > 0) {
    truncated = truncated.slice(0, -1);
  }
  return truncated + '...';
}
