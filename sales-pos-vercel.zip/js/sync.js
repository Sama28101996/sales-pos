// =====================================================
// نظام مزامنة الفريق بين الأجهزة
// حل مشكلة: عضو يضاف على جهاز ولا يظهر على جهاز آخر
// =====================================================

const Sync = {
  // ===== الطريقة 1: تصدير/استيراد عبر QR أو نص =====
  // نولّد نص JSON صغير فيه المستخدمين الجدد فقط
  exportNewUsers: () => {
    const users = Users.all();
    // فقط صدّر الأعضاء غير الأدمن الأصلي
    const exportable = users
      .filter(u => u.username !== 'admin') // استثناء الأدمن الأصلي
      .map(u => ({
        id: u.id,
        username: u.username,
        password: u.password,
        name: u.name,
        role: u.role,
        permissions: u.permissions || [],
        createdAt: u.createdAt,
      }));

    return JSON.stringify({
      type: 'users_export',
      version: '3.1',
      timestamp: new Date().toISOString(),
      users: exportable,
    });
  },

  importUsers: (jsonStr) => {
    try {
      const data = JSON.parse(jsonStr);
      if (data.type !== 'users_export') {
        throw new Error('ملف غير صالح');
      }
      const incoming = data.users || [];
      let added = 0;
      let updated = 0;

      incoming.forEach(u => {
        const existing = Users.findByUsername(u.username);
        if (existing) {
          // تحديث (بدون ما نغير كلمة المرور المحلية)
          Users.update(existing.id, {
            name: u.name,
            role: u.role,
            permissions: u.permissions,
          });
          updated++;
        } else {
          // إضافة جديد
          Users.add({
            username: u.username,
            password: u.password,
            name: u.name,
            role: u.role,
            permissions: u.permissions,
            createdAt: u.createdAt,
          });
          added++;
        }
      });

      return { added, updated, total: incoming.length };
    } catch (e) {
      throw new Error('فشل قراءة الملف: ' + e.message);
    }
  },

  // ===== نافذة المزامنة =====
  showSyncDialog: () => {
    const currentUsers = Users.all().filter(u => u.username !== 'admin');
    const content = `
      <div style="display:grid;gap:1rem;">
        <div style="background:var(--primary-light);padding:1rem;border-radius:8px;">
          <h3 style="margin:0 0 0.5rem;">👥 الأعضاء الحاليون على هذا الجهاز</h3>
          <p>عددهم: <strong>${currentUsers.length}</strong></p>
          <details style="margin-top:0.5rem;">
            <summary style="cursor:pointer;color:var(--primary);">عرض القائمة</summary>
            <div style="margin-top:0.5rem;padding:0.5rem;background:#fff;border-radius:6px;max-height:200px;overflow:auto;">
              ${currentUsers.length === 0 ? '<p style="color:var(--text-muted);">لا يوجد أعضاء بعد</p>' : currentUsers.map(u => `
                <div style="padding:0.4rem;border-bottom:1px solid var(--border);">
                  <strong>${escapeHtml(u.name)}</strong>
                  <code style="background:var(--bg);padding:1px 6px;border-radius:3px;margin:0 0.3rem;">${escapeHtml(u.username)}</code>
                  <span style="color:var(--text-muted);font-size:0.85rem;">${ROLES[u.role]?.name || u.role}</span>
                </div>
              `).join('')}
            </div>
          </details>
        </div>

        <div style="background:var(--success-light);padding:1rem;border-radius:8px;border-inline-start:4px solid var(--success);">
          <h3 style="margin:0 0 0.5rem;">📤 الخطوة 1: من جهاز الأدمن</h3>
          <p style="margin:0 0 0.5rem;font-size:0.9rem;">انسخ النص التالي وشاركه مع البائع:</p>
          <textarea id="exportText" rows="4" style="width:100%;font-size:0.75rem;direction:ltr;text-align:left;font-family:monospace;" readonly></textarea>
          <div style="display:flex;gap:0.5rem;margin-top:0.5rem;flex-wrap:wrap;">
            <button class="btn btn-sm btn-primary" id="copyExportBtn">📋 نسخ</button>
            <button class="btn btn-sm btn-secondary" id="downloadExportBtn">💾 تنزيل ملف</button>
            <button class="btn btn-sm btn-info" id="showQrBtn">📱 QR Code</button>
          </div>
        </div>

        <div style="background:var(--warning-light);padding:1rem;border-radius:8px;border-inline-start:4px solid var(--warning);">
          <h3 style="margin:0 0 0.5rem;">📥 الخطوة 2: من جهاز البائع</h3>
          <p style="margin:0 0 0.5rem;font-size:0.9rem;">ألصق النص المستلم هنا لاستيراد الأعضاء:</p>
          <textarea id="importText" rows="4" style="width:100%;font-size:0.75rem;direction:ltr;text-align:left;font-family:monospace;" placeholder='ألصق النص هنا...'></textarea>
          <div style="display:flex;gap:0.5rem;margin-top:0.5rem;flex-wrap:wrap;">
            <button class="btn btn-sm btn-primary" id="importTextBtn">📥 استيراد من نص</button>
            <label class="btn btn-sm btn-secondary" style="cursor:pointer;margin:0;">
              📂 من ملف
              <input type="file" id="importFileInput" accept=".json,.txt" style="display:none;" />
            </label>
          </div>
        </div>

        <details style="background:var(--bg);padding:0.75rem;border-radius:8px;">
          <summary style="cursor:pointer;font-weight:600;">ℹ️ كيف يعمل هذا؟</summary>
          <div style="margin-top:0.5rem;font-size:0.9rem;line-height:1.7;">
            <p>كل جهاز يحفظ بياناته محلياً (localStorage). عشان عضو يظهر على كل الأجهزة:</p>
            <ol style="margin:0.5rem 0;padding-inline-start:1.5rem;">
              <li>الأدمن يصدّر قائمة الأعضاء من جهازه</li>
              <li>يشارك النص (واتساب، إيميل، إلخ) مع البائع</li>
              <li>البائع يلصق النص بجهازه ويستورد</li>
            </ol>
            <p>💡 <b>أفضل حل دائم:</b> استخدم Google Drive Backup (صفحة ☁️ بالقائمة) — كل البيانات تتزامن تلقائياً.</p>
          </div>
        </details>
      </div>
    `;
    openModal('🔄 مزامنة الفريق بين الأجهزة', content, { large: true });

    // تعبئة النص المُصدّر
    const exportText = document.getElementById('exportText');
    const exported = Sync.exportNewUsers();
    exportText.value = exported;

    // نسخ
    document.getElementById('copyExportBtn').addEventListener('click', () => {
      navigator.clipboard.writeText(exported).then(() => {
        toast('✅ تم النسخ - ابعثه للبائع', 'success', 2000);
      }).catch(() => {
        exportText.select();
        document.execCommand('copy');
        toast('✅ تم النسخ', 'success');
      });
    });

    // تنزيل ملف
    document.getElementById('downloadExportBtn').addEventListener('click', () => {
      const blob = new Blob([exported], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `users_export_${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      toast('✅ تم التنزيل', 'success');
    });

    // QR Code
    document.getElementById('showQrBtn').addEventListener('click', () => {
      Sync.showQrCode(exported);
    });

    // استيراد من نص
    document.getElementById('importTextBtn').addEventListener('click', () => {
      const text = document.getElementById('importText').value.trim();
      if (!text) {
        toast('ألصق النص أولاً', 'warning');
        return;
      }
      try {
        const result = Sync.importUsers(text);
        toast(`✅ تمت المزامنة: ${result.added} جديد، ${result.updated} محدّث`, 'success', 4000);
        closeModal('genericModal');
        TeamPage.refresh();
      } catch (e) {
        toast('❌ ' + e.message, 'error');
      }
    });

    // استيراد من ملف
    document.getElementById('importFileInput').addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const text = await file.text();
      try {
        const result = Sync.importUsers(text);
        toast(`✅ تمت المزامنة: ${result.added} جديد، ${result.updated} محدّث`, 'success', 4000);
        closeModal('genericModal');
        TeamPage.refresh();
      } catch (err) {
        toast('❌ ' + err.message, 'error');
      }
    });
  },

  // ===== QR Code (بدون مكتبة خارجية) =====
  showQrCode: (text) => {
    // نستخدم خدمة Google Chart API
    const encoded = encodeURIComponent(text);
    const qrUrl = `https://chart.googleapis.com/chart?cht=qr&chs=400x400&chl=${encoded}&choe=UTF-8`;

    const content = `
      <div style="text-align:center;">
        <p style="margin-bottom:1rem;">📱 البائع يمسح هذا الـ QR من جهازه:</p>
        <div style="background:#fff;padding:1rem;border-radius:8px;display:inline-block;">
          <img src="${qrUrl}" alt="QR Code" style="max-width:300px;width:100%;display:block;" />
        </div>
        <p style="margin-top:1rem;color:var(--text-muted);font-size:0.85rem;">
          💡 لو الـ QR كبير، صدّر نص وابعثه عادي.
        </p>
        <div style="margin-top:1rem;">
          <button class="btn btn-ghost" data-close="genericModal">إغلاق</button>
        </div>
      </div>
    `;
    openModal('📱 QR Code للمزامنة', content);
  },

  // ===== مزامنة تلقائية عبر Google Drive =====
  // لما يكون الأدمن مربوط بـ Drive، كل عضو جديد يُرفع تلقائياً
  syncUsersToDrive: async () => {
    if (!Backup.isConnected()) return;
    console.log('[Sync] Syncing users to Drive...');
    await Backup.createBackup(true);
  },
};
