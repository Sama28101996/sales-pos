// =====================================================
// نظام صور المنتجات
// - رفع من الجهاز
// - التقاط من الكاميرا مباشرة
// - ضغط الصور تلقائياً لتوفير المساحة
// - عرض الصور في المنتجات ونقطة البيع
// =====================================================

const ProductImages = {
  MAX_SIZE_KB: 500, // الحد الأقصى لحجم الصورة بعد الضغط
  MAX_DIMENSION: 800, // الحد الأقصى للأبعاد
  QUALITY: 0.85, // جودة JPEG

  // ===== ضغط الصورة =====
  compress: (file) => {
    return new Promise((resolve, reject) => {
      if (!file.type.startsWith('image/')) {
        reject(new Error('الملف ليس صورة'));
        return;
      }

      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          let { width, height } = img;

          // تصغير الأبعاد إذا لزم
          if (width > ProductImages.MAX_DIMENSION || height > ProductImages.MAX_DIMENSION) {
            if (width > height) {
              height = (height * ProductImages.MAX_DIMENSION) / width;
              width = ProductImages.MAX_DIMENSION;
            } else {
              width = (width * ProductImages.MAX_DIMENSION) / height;
              height = ProductImages.MAX_DIMENSION;
            }
          }

          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0, width, height);

          // تحويل إلى JPEG مضغوط
          const compressedDataUrl = canvas.toDataURL('image/jpeg', ProductImages.QUALITY);

          // التحقق من الحجم
          const sizeKB = compressedDataUrl.length * 0.75 / 1024; // تقدير
          if (sizeKB > ProductImages.MAX_SIZE_KB) {
            // ضغط أكثر
            const recompressed = canvas.toDataURL('image/jpeg', 0.6);
            resolve(recompressed);
          } else {
            resolve(compressedDataUrl);
          }
        };
        img.onerror = () => reject(new Error('فشل تحميل الصورة'));
        img.src = e.target.result;
      };
      reader.onerror = () => reject(new Error('فشل قراءة الملف'));
      reader.readAsDataURL(file);
    });
  },

  // ===== التقاط صورة من الكاميرا =====
  captureFromCamera: (onCapture) => {
    // إنشاء نافذة الكاميرا (كـ overlay مستقل، ما يأثر على المودال الأصلي)
    const modal = document.createElement('div');
    modal.className = 'modal active';
    modal.id = 'cameraCaptureModal';
    modal.style.zIndex = '11000'; // فوق أي overlay ثاني
    modal.innerHTML = `
      <div class="modal-content" style="max-width:600px;">
        <div class="modal-header">
          <h2>📸 التقاط صورة المنتج</h2>
          <button class="icon-btn close-modal" data-close="cameraCaptureModal">✕</button>
        </div>
        <div class="modal-body" style="text-align:center;">
          <div style="position:relative;background:#000;border-radius:8px;overflow:hidden;min-height:300px;display:flex;align-items:center;justify-content:center;">
            <video id="cameraVideo" autoplay playsinline style="width:100%;max-height:400px;display:block;"></video>
            <canvas id="cameraCanvas" style="display:none;"></canvas>
          </div>
          <div id="cameraStatus" style="margin-top:0.5rem;color:var(--text-muted);font-size:0.85rem;">
            جاري تشغيل الكاميرا...
          </div>
          <div style="margin-top:1rem;display:flex;gap:0.5rem;justify-content:center;flex-wrap:wrap;">
            <button class="btn btn-primary" id="captureBtn" disabled>📸 التقط</button>
            <button class="btn btn-ghost" data-close="cameraCaptureModal">إلغاء</button>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(modal);

    // إغلاق المودال
    const closeModal = () => {
      const stream = document.getElementById('cameraVideo')?.srcObject;
      if (stream) {
        stream.getTracks().forEach(t => t.stop());
      }
      modal.remove();
    };
    modal.querySelectorAll('[data-close="cameraCaptureModal"]').forEach(b => {
      b.addEventListener('click', closeModal);
    });

    // تشغيل الكاميرا
    const video = modal.querySelector('#cameraVideo');
    const status = modal.querySelector('#cameraStatus');
    const captureBtn = modal.querySelector('#captureBtn');

    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      status.innerHTML = '❌ الكاميرا غير مدعومة في هذا المتصفح. استخدم الرفع من الجهاز.';
      return;
    }

    navigator.mediaDevices.getUserMedia({
      video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 } },
      audio: false,
    })
      .then((stream) => {
        video.srcObject = stream;
        captureBtn.disabled = false;
        status.textContent = '📷 وجّه الكاميرا نحو المنتج ثم اضغط التقط';
      })
      .catch((err) => {
        console.error('Camera error:', err);
        let detail = err.name || 'خطأ';
        if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
          detail = 'تم رفض إذن الكاميرا. اسمح بالوصول من إعدادات المتصفح، أو استخدم الرفع من الجهاز.';
        } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
          detail = 'لا توجد كاميرا متاحة. استخدم الرفع من الجهاز.';
        } else if (err.name === 'NotReadableError') {
          detail = 'الكاميرا مستخدمة من تطبيق آخر. أغلقه ثم حاول مرة ثانية، أو ارفع من الجهاز.';
        } else if (err.name === 'NotSupportedError' || err.name === 'TypeError') {
          detail = 'الكاميرا تتطلب HTTPS. افتح التطبيق على https:// أو استخدم الرفع من الجهاز.';
        }
        status.innerHTML = `❌ تعذّر فتح الكاميرا (${detail})`;
        captureBtn.disabled = true;
        // إخفاء زر التقط لأنه ما يشتغل
        captureBtn.style.display = 'none';
      });

    // التقاط الصورة
    captureBtn.addEventListener('click', async () => {
      const canvas = modal.querySelector('#cameraCanvas');
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(video, 0, 0);

      const dataUrl = canvas.toDataURL('image/jpeg', ProductImages.QUALITY);
      const sizeKB = dataUrl.length * 0.75 / 1024;
      const finalDataUrl = sizeKB > ProductImages.MAX_SIZE_KB
        ? canvas.toDataURL('image/jpeg', 0.6)
        : dataUrl;

      closeModal();
      if (onCapture) onCapture(finalDataUrl);
    });
  },

  // ===== رفع من الجهاز (بدون capture = يطلع خيار كاميرا/ستوديو) =====
  uploadFromDevice: () => {
    return new Promise((resolve, reject) => {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/*';
      // بدون input.capture = المستخدم يشوف خيار "كاميرا أو ستوديو/معرض"
      input.onchange = async (e) => {
        const file = e.target.files[0];
        if (!file) {
          reject(new Error('لم يتم اختيار ملف'));
          return;
        }
        try {
          const compressed = await ProductImages.compress(file);
          resolve(compressed);
        } catch (err) {
          reject(err);
        }
      };
      // تخلّي onchange يشتغل أكثر من مرة لو المستخدم ألغى ثم اختار مرة ثانية
      input.addEventListener('cancel', () => reject(new Error('لم يتم اختيار ملف')));
      input.click();
    });
  },

  // ===== اختيار بين التقاط أو رفع (overlay داخل نفس المودال بدون تدميره) =====
  choose: (onSelect) => {
    // بدل ما نفتح مودال جديد بـ openModal (اللي يدمّر محتوى genericModal = يدمّر نموذج الإضافة)
    // نعمل overlay فوق المودال الحالي
    let overlay = document.getElementById('imagePickerOverlay');
    if (overlay) overlay.remove();

    overlay = document.createElement('div');
    overlay.id = 'imagePickerOverlay';
    overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:10000;display:flex;align-items:center;justify-content:center;padding:1rem;';
    overlay.innerHTML = `
      <div style="background:var(--surface,#fff);border-radius:12px;padding:1.25rem;max-width:420px;width:100%;box-shadow:0 20px 60px rgba(0,0,0,0.3);">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem;">
          <h3 style="margin:0;font-size:1.1rem;">إضافة صورة للمنتج</h3>
          <button type="button" id="ipCloseBtn" style="background:none;border:none;font-size:1.5rem;cursor:pointer;color:var(--text-muted);">✕</button>
        </div>
        <div style="display:grid;gap:0.75rem;">
          <button type="button" class="btn btn-primary" id="chooseCamera" style="padding:1rem;">
            <span style="font-size:1.4rem;">📸</span> التقاط من الكاميرا
          </button>
          <button type="button" class="btn btn-secondary" id="chooseUpload" style="padding:1rem;">
            <span style="font-size:1.4rem;">📁</span> رفع من الجهاز (الاستوديو)
          </button>
        </div>
        <p style="margin-top:0.75rem;font-size:0.78rem;color:var(--text-muted);text-align:center;">
          الحد الأقصى: 500KB • يتم ضغط الصورة تلقائياً
        </p>
      </div>
    `;
    document.body.appendChild(overlay);

    const closeOverlay = () => {
      const ov = document.getElementById('imagePickerOverlay');
      if (ov) ov.remove();
    };

    // إغلاق بزر X
    overlay.querySelector('#ipCloseBtn').addEventListener('click', closeOverlay);
    // إغلاق بالنقر خارج الصندوق
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) closeOverlay();
    });

    overlay.querySelector('#chooseCamera').addEventListener('click', () => {
      closeOverlay();
      // مهلة صغيرة عشان الـ overlay يقفل بالكامل قبل ما الكاميرا تنفتح
      setTimeout(() => {
        ProductImages.captureFromCamera(async (dataUrl) => {
          if (onSelect) onSelect(dataUrl);
        });
      }, 200);
    });

    overlay.querySelector('#chooseUpload').addEventListener('click', () => {
      closeOverlay();
      setTimeout(async () => {
        try {
          const dataUrl = await ProductImages.uploadFromDevice();
          if (onSelect) onSelect(dataUrl);
        } catch (err) {
          if (err.message !== 'لم يتم اختيار ملف') {
            toast('فشل رفع الصورة: ' + err.message, 'error');
          }
        }
      }, 200);
    });
  },

  // ===== معاينة الصورة =====
  preview: (dataUrl, size = 'medium') => {
    if (!dataUrl) return '';
    const sizes = { small: 32, medium: 60, large: 120 };
    const px = sizes[size] || sizes.medium;
    return `<img src="${dataUrl}" class="product-thumb product-thumb-${size}" alt="صورة المنتج" />`;
  },

  // ===== استخراج الصورة من المنتج =====
  getImage: (product) => {
    return product?.image || product?.photo || '';
  },

  // ===== حقل الصورة في نموذج المنتج =====
  imageField: (currentImage = '') => {
    return `
      <div class="form-group">
        <label>صورة المنتج (اختياري)</label>
        <div class="image-upload-area" id="imageUploadArea">
          <div class="image-preview" id="imagePreview">
            ${currentImage
              ? `<img src="${currentImage}" alt="صورة" />`
              : `<div class="image-placeholder">📦<br><small>لم تختار صورة بعد</small></div>`
            }
          </div>
          <input type="hidden" name="image" id="productImageInput" value="${escapeHtml(currentImage)}" />
          <div style="display:flex;gap:0.5rem;margin-top:0.5rem;flex-wrap:wrap;">
            <button type="button" class="btn btn-primary btn-sm" id="uploadImageBtn">📸 التقاط / رفع</button>
            ${currentImage ? '<button type="button" class="btn btn-danger btn-sm" id="removeImageBtn">🗑️ حذف</button>' : ''}
          </div>
          <small style="color:var(--text-muted);font-size:0.8rem;display:block;margin-top:0.3rem;">
            الحد الأقصى: 500KB. يتم ضغط الصورة تلقائياً.
          </small>
        </div>
      </div>
    `;
  },

  // ===== ربط أحداث حقل الصورة =====
  bindImageField: () => {
    const uploadBtn = document.getElementById('uploadImageBtn');
    const removeBtn = document.getElementById('removeImageBtn');
    const preview = document.getElementById('imagePreview');
    const hiddenInput = document.getElementById('productImageInput');

    if (uploadBtn) {
      uploadBtn.addEventListener('click', () => {
        ProductImages.choose((dataUrl) => {
          hiddenInput.value = dataUrl;
          preview.innerHTML = `<img src="${dataUrl}" alt="صورة" />`;
          toast('✅ تم رفع الصورة', 'success', 1500);
          // إضافة زر الحذف إذا لم يكن موجوداً
          if (!document.getElementById('removeImageBtn')) {
            const removeBtnNew = document.createElement('button');
            removeBtnNew.type = 'button';
            removeBtnNew.id = 'removeImageBtn';
            removeBtnNew.className = 'btn btn-danger btn-sm';
            removeBtnNew.textContent = '🗑️ حذف';
            uploadBtn.parentElement.appendChild(removeBtnNew);
            ProductImages.bindImageField(); // إعادة الربط
          }
        });
      });
    }

    if (removeBtn) {
      removeBtn.addEventListener('click', () => {
        hiddenInput.value = '';
        preview.innerHTML = `<div class="image-placeholder">📦<br><small>لم تختار صورة بعد</small></div>`;
        removeBtn.remove();
      });
    }
  },
};
