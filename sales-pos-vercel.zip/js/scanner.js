// =====================================================
// ماسح الباركود - يستخدم html5-qrcode (الأكثر توافقًا)
// =====================================================

const Scanner = {
  instance: null,
  isOpen: false,
  onDetect: null,
  stream: null,
  permissionAsked: false,

  open: async (callback) => {
    Scanner.onDetect = callback;
    const modal = document.getElementById('scannerModal');
    modal.classList.add('active');
    Scanner.isOpen = true;

    // طلب الإذن مسبقاً على iOS
    if (!Scanner.permissionAsked) {
      Scanner.permissionAsked = true;
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ video: true });
          stream.getTracks().forEach(t => t.stop());
        } catch (e) {
          console.warn('Initial permission request failed:', e);
        }
      }
    }

    setTimeout(() => Scanner._start(), 200);
  },

  close: () => {
    Scanner._stop();
    const modal = document.getElementById('scannerModal');
    modal.classList.remove('active');
    Scanner.isOpen = false;
    Scanner.onDetect = null;
    const manualInput = document.getElementById('manualBarcode');
    if (manualInput) manualInput.value = '';
  },

  _start: () => {
    const readerEl = document.getElementById('scannerReader');
    if (!readerEl) return;
    readerEl.innerHTML = '<div id="qr-reader-inner" style="width:100%;height:100%;background:#000;"></div>';

    // التحقق من HTTPS
    if (location.protocol !== 'https:' && location.hostname !== 'localhost' && !location.hostname.startsWith('127.')) {
      Scanner._showError('الكاميرا تتطلب اتصال آمن (HTTPS).');
      return;
    }

    // التحقق من دعم الكاميرا
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      Scanner._showError('المتصفح لا يدعم الكاميرا. استخدم الإدخال اليدوي بالأسفل.');
      return;
    }

    // التحقق من وجود مكتبة html5-qrcode
    if (typeof Html5Qrcode === 'undefined') {
      Scanner._showError('مكتبة السكان لم تُحمَّل. استخدم الإدخال اليدوي بالأسفل.');
      return;
    }

    // تجربة الكاميرا الخلفية أولاً
    Scanner._tryCamera('environment').catch(() => {
      // fallback: الكاميرا الأمامية
      return Scanner._tryCamera('user');
    }).catch(err => {
      Scanner._showError(err);
    });
  },

  _tryCamera: (facingMode) => {
    return new Promise((resolve, reject) => {
      const readerId = 'qr-reader-inner';
      try {
        // تنظيف أي instance سابق
        if (Scanner.instance) {
          try {
            Scanner.instance.stop().catch(() => {});
            Scanner.instance.clear();
          } catch (e) {}
          Scanner.instance = null;
        }

        Scanner.instance = new Html5Qrcode(readerId, {
          verbose: false,
          formatsToSupport: [
            Html5QrcodeSupportedFormats.QR_CODE,
            Html5QrcodeSupportedFormats.CODE_128,
            Html5QrcodeSupportedFormats.CODE_39,
            Html5QrcodeSupportedFormats.EAN_13,
            Html5QrcodeSupportedFormats.EAN_8,
            Html5QrcodeSupportedFormats.UPC_A,
            Html5QrcodeSupportedFormats.UPC_E,
            Html5QrcodeSupportedFormats.CODE_93,
            Html5QrcodeSupportedFormats.CODABAR,
            Html5QrcodeSupportedFormats.ITF,
          ]
        });

        const config = {
          fps: 10,
          qrbox: { width: 250, height: 150 },
          aspectRatio: 1.5,
          disableFlip: false,
        };

        Scanner.instance.start(
          { facingMode: facingMode },
          config,
          (decodedText, decodedResult) => {
            // نجاح - تم قراءة الباركود
            if (Scanner.onDetect) {
              Scanner.onDetect(decodedText);
              Scanner.close();
            }
            resolve(decodedText);
          },
          (errorMessage) => {
            // أخطاء قراءة متكررة - نتجاهلها
          }
        ).then(() => {
          // الكاميرا اشتغلت
        }).catch(err => {
          reject(Scanner._getErrorMessage(err));
        });

      } catch (e) {
        reject(Scanner._getErrorMessage(e));
      }
    });
  },

  _getErrorMessage: (err) => {
    const errStr = String(err?.message || err || '');
    if (errStr.includes('NotAllowed') || errStr.includes('Permission')) {
      return '⛔ تم رفض إذن الكاميرا.<br><br>اذهب لـ <b>إعدادات الجوال</b> ← <b>التطبيقات</b> ← <b>المتصفح</b> ← <b>الأذونات</b> ← فعّل <b>الكاميرا</b>.<br><br>أو استخدم الإدخال اليدوي بالأسفل.';
    }
    if (errStr.includes('NotFound') || errStr.includes('not found')) {
      return '📷 لم يتم العثور على كاميرا متاحة. أغلق أي تطبيق يستخدم الكاميرا وأعد المحاولة.';
    }
    if (errStr.includes('NotReadable') || errStr.includes('in use')) {
      return '⚠️ الكاميرا مشغولة من تطبيق آخر. أغلق واتساب/إنستغرام ثم أعد المحاولة.';
    }
    if (errStr.includes('Overconstrained') || errStr.includes('not satisfied')) {
      return '⚙️ الكاميرا المطلوبة غير متاحة. جرب كاميرا أخرى.';
    }
    if (errStr.includes('Secure') || errStr.includes('secure')) {
      return '🔒 الكاميرا تتطلب اتصال آمن (HTTPS).';
    }
    return 'تعذّر تشغيل الكاميرا.<br><br><small style="opacity:0.7;">' + errStr.substring(0, 100) + '</small><br><br>أو استخدم الإدخال اليدوي بالأسفل.';
  },

  _showError: (htmlMessage) => {
    const readerEl = document.getElementById('scannerReader');
    if (readerEl) {
      readerEl.innerHTML = `
        <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;color:white;text-align:center;padding:1.5rem;background:linear-gradient(135deg, #1e293b, #0f172a);border-radius:8px;">
          <div style="font-size:4rem;margin-bottom:0.75rem;">📷</div>
          <div style="font-size:3rem;margin-bottom:0.5rem;">❌</div>
          <p style="font-size:0.95rem;line-height:1.6;max-width:300px;">${htmlMessage}</p>
        </div>
      `;
    }
  },

  _stop: () => {
    if (Scanner.stream) {
      Scanner.stream.getTracks().forEach(track => track.stop());
      Scanner.stream = null;
    }
    if (Scanner.instance) {
      try {
        const inst = Scanner.instance;
        Scanner.instance = null;
        inst.stop().then(() => {
          try { inst.clear(); } catch (e) {}
        }).catch(() => {
          try { inst.clear(); } catch (e) {}
        });
      } catch (e) {
        Scanner.instance = null;
      }
    }
  },
};

// ربط أحداث السكان
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('[data-close="scannerModal"]').forEach(btn => {
    btn.addEventListener('click', () => Scanner.close());
  });

  const manualBtn = document.getElementById('manualBarcodeBtn');
  const manualInput = document.getElementById('manualBarcode');
  if (manualBtn && manualInput) {
    const submit = () => {
      const val = manualInput.value.trim();
      if (val && Scanner.onDetect) {
        Scanner.onDetect(val);
        Scanner.close();
        manualInput.value = '';
      }
    };
    manualBtn.addEventListener('click', submit);
    manualInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        submit();
      }
    });
  }
});
