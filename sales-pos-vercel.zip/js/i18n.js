// =====================================================
// نظام الترجمة - 30 لغة
// =====================================================

const SUPPORTED_LANGUAGES = [
  { code: 'ar', name: 'العربية', flag: '🇸🇦', dir: 'rtl' },
  { code: 'en', name: 'English', flag: '🇬🇧', dir: 'ltr' },
  { code: 'tr', name: 'Türkçe', flag: '🇹🇷', dir: 'ltr' },
  { code: 'ku', name: 'Kurdî', flag: '🇮🇶', dir: 'rtl' },
  { code: 'fa', name: 'فارسی', flag: '🇮🇷', dir: 'rtl' },
  { code: 'ur', name: 'اردو', flag: '🇵🇰', dir: 'rtl' },
  { code: 'he', name: 'עברית', flag: '🇮🇱', dir: 'rtl' },
  { code: 'fr', name: 'Français', flag: '🇫🇷', dir: 'ltr' },
  { code: 'es', name: 'Español', flag: '🇪🇸', dir: 'ltr' },
  { code: 'de', name: 'Deutsch', flag: '🇩🇪', dir: 'ltr' },
  { code: 'it', name: 'Italiano', flag: '🇮🇹', dir: 'ltr' },
  { code: 'pt', name: 'Português', flag: '🇵🇹', dir: 'ltr' },
  { code: 'ru', name: 'Русский', flag: '🇷🇺', dir: 'ltr' },
  { code: 'zh', name: '中文', flag: '🇨🇳', dir: 'ltr' },
  { code: 'ja', name: '日本語', flag: '🇯🇵', dir: 'ltr' },
  { code: 'ko', name: '한국어', flag: '🇰🇷', dir: 'ltr' },
  { code: 'hi', name: 'हिन्दी', flag: '🇮🇳', dir: 'ltr' },
  { code: 'bn', name: 'বাংলা', flag: '🇧🇩', dir: 'ltr' },
  { code: 'id', name: 'Bahasa Indonesia', flag: '🇮🇩', dir: 'ltr' },
  { code: 'ms', name: 'Bahasa Melayu', flag: '🇲🇾', dir: 'ltr' },
  { code: 'th', name: 'ไทย', flag: '🇹🇭', dir: 'ltr' },
  { code: 'vi', name: 'Tiếng Việt', flag: '🇻🇳', dir: 'ltr' },
  { code: 'tl', name: 'Filipino', flag: '🇵🇭', dir: 'ltr' },
  { code: 'sw', name: 'Kiswahili', flag: '🇰🇪', dir: 'ltr' },
  { code: 'am', name: 'አማርኛ', flag: '🇪🇹', dir: 'ltr' },
  { code: 'ha', name: 'Hausa', flag: '🇳🇬', dir: 'ltr' },
  { code: 'yo', name: 'Yorùbá', flag: '🇳🇬', dir: 'ltr' },
  { code: 'so', name: 'Soomaali', flag: '🇸🇴', dir: 'ltr' },
  { code: 'nl', name: 'Nederlands', flag: '🇳🇱', dir: 'ltr' },
  { code: 'pl', name: 'Polski', flag: '🇵🇱', dir: 'ltr' },
];

// الترجمات - حالياً العربية مكتملة + إنجليزية كاملة
// باقي اللغات تستخدم الإنجليزية كـ fallback
const TRANSLATIONS = {
  ar: {
    // عام
    app_name: 'نظام إدارة المبيعات',
    login: 'تسجيل الدخول',
    logout: 'تسجيل الخروج',
    save: 'حفظ',
    cancel: 'إلغاء',
    delete: 'حذف',
    edit: 'تعديل',
    add: 'إضافة',
    search: 'بحث',
    print: 'طباعة',
    export: 'تصدير',
    import: 'استيراد',
    settings: 'الإعدادات',
    back: 'رجوع',
    confirm: 'تأكيد',
    close: 'إغلاق',
    // القائمة
    dashboard: 'لوحة التحكم',
    pos: 'نقطة البيع',
    inventory: 'المخزون',
    purchase: 'إضافة بضاعة',
    sales_history: 'سجل المبيعات',
    customers: 'العملاء',
    debts: 'الديون',
    reports: 'التقارير',
    team: 'إدارة الفريق',
    team_report: 'كشوفات الأعضاء',
    // حقول
    name: 'الاسم',
    username: 'اسم المستخدم',
    password: 'كلمة المرور',
    phone: 'الهاتف',
    address: 'العنوان',
    price: 'السعر',
    cost: 'التكلفة',
    stock: 'المخزون',
    quantity: 'الكمية',
    total: 'الإجمالي',
    date: 'التاريخ',
    invoice: 'الفاتورة',
    customer: 'العميل',
    product: 'المنتج',
    category: 'الفئة',
    barcode: 'الباركود',
    payment: 'الدفع',
    paid: 'مدفوع',
    remaining: 'المتبقي',
    // إعدادات
    store_name: 'اسم المتجر',
    store_phone: 'هاتف المتجر',
    store_address: 'عنوان المتجر',
    currency: 'العملة',
    language: 'اللغة',
    primary_notes: 'الملاحظات الأساسية',
    primary_notes_help: 'تظهر في الفاتورة بخط واضح (مثل: شكراً لزيارتكم)',
    secondary_notes: 'الملاحظات الثانوية',
    secondary_notes_help: 'تظهر أسفل الفاتورة بخط صغير (مثل: شروط الاسترجاع)',
    logo: 'الشعار',
    logo_help: 'يظهر خلفية فاتورة PDF (مفضّل صورة شفافة PNG)',
    upload_logo: '📤 رفع شعار',
    remove_logo: '🗑️ إزالة الشعار',
    // فاتورة
    invoice_no: 'رقم الفاتورة',
    cash_sale: 'بيع نقدي',
    credit_sale: 'بيع آجل',
    subtotal: 'المجموع الفرعي',
    notes: 'ملاحظات',
    // فريق
    member: 'العضو',
    role: 'الدور',
    permissions: 'الصلاحيات',
    status: 'الحالة',
    actions: 'إجراءات',
    // رسالة
    saved_success: 'تم الحفظ بنجاح',
    deleted_success: 'تم الحذف',
    error_occurred: 'حدث خطأ',
  },
  en: {
    app_name: 'Sales Management System',
    login: 'Login',
    logout: 'Logout',
    save: 'Save',
    cancel: 'Cancel',
    delete: 'Delete',
    edit: 'Edit',
    add: 'Add',
    search: 'Search',
    print: 'Print',
    export: 'Export',
    import: 'Import',
    settings: 'Settings',
    back: 'Back',
    confirm: 'Confirm',
    close: 'Close',
    dashboard: 'Dashboard',
    pos: 'Point of Sale',
    inventory: 'Inventory',
    purchase: 'Add Stock',
    sales_history: 'Sales History',
    customers: 'Customers',
    debts: 'Debts',
    reports: 'Reports',
    team: 'Team Management',
    team_report: 'Team Statements',
    name: 'Name',
    username: 'Username',
    password: 'Password',
    phone: 'Phone',
    address: 'Address',
    price: 'Price',
    cost: 'Cost',
    stock: 'Stock',
    quantity: 'Quantity',
    total: 'Total',
    date: 'Date',
    invoice: 'Invoice',
    customer: 'Customer',
    product: 'Product',
    category: 'Category',
    barcode: 'Barcode',
    payment: 'Payment',
    paid: 'Paid',
    remaining: 'Remaining',
    store_name: 'Store Name',
    store_phone: 'Store Phone',
    store_address: 'Store Address',
    currency: 'Currency',
    language: 'Language',
    primary_notes: 'Primary Notes',
    primary_notes_help: 'Shown on invoice in clear text (e.g., Thank you for visiting)',
    secondary_notes: 'Secondary Notes',
    secondary_notes_help: 'Shown at bottom of invoice in small text (e.g., Return policy)',
    logo: 'Logo',
    logo_help: 'Appears as background on PDF invoice (transparent PNG preferred)',
    upload_logo: '📤 Upload Logo',
    remove_logo: '🗑️ Remove Logo',
    invoice_no: 'Invoice No',
    cash_sale: 'Cash Sale',
    credit_sale: 'Credit Sale',
    subtotal: 'Subtotal',
    notes: 'Notes',
    member: 'Member',
    role: 'Role',
    permissions: 'Permissions',
    status: 'Status',
    actions: 'Actions',
    saved_success: 'Saved successfully',
    deleted_success: 'Deleted',
    error_occurred: 'An error occurred',
  },
};

// fallback: أي لغة غير ar/en تستخدم الإنجليزية
['tr', 'ku', 'fa', 'ur', 'he', 'fr', 'es', 'de', 'it', 'pt', 'ru', 'zh', 'ja', 'ko', 'hi', 'bn', 'id', 'ms', 'th', 'vi', 'tl', 'sw', 'am', 'ha', 'yo', 'so', 'nl', 'pl'].forEach(l => {
  TRANSLATIONS[l] = TRANSLATIONS.en;
});

const I18n = {
  current: () => {
    const settings = Settings.get();
    return settings.language || 'ar';
  },

  t: (key) => {
    const lang = I18n.current();
    return (TRANSLATIONS[lang] && TRANSLATIONS[lang][key]) || (TRANSLATIONS.en[key]) || key;
  },

  setLanguage: (code) => {
    Settings.set({ language: code });
    const lang = SUPPORTED_LANGUAGES.find(l => l.code === code);
    if (lang) {
      document.documentElement.lang = code;
      document.documentElement.dir = lang.dir;
    }
  },

  applyDirection: () => {
    const code = I18n.current();
    const lang = SUPPORTED_LANGUAGES.find(l => l.code === code);
    if (lang) {
      document.documentElement.lang = code;
      document.documentElement.dir = lang.dir;
    }
  },

  getLanguageName: (code) => {
    const l = SUPPORTED_LANGUAGES.find(x => x.code === code);
    return l ? `${l.flag} ${l.name}` : code;
  },
};

// تطبيق الاتجاه عند التحميل
document.addEventListener('DOMContentLoaded', () => {
  I18n.applyDirection();
});
