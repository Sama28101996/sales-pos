// =====================================================
// سجل الفواتير - عرض وطباعة ومشاركة كل الفواتير
// =====================================================

const InvoiceList = {
  _search: '',
  _filter: 'all', // all | cash | debt

  render: () => {
    let sales = Sales.all().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    // تطبيق البحث
    const search = InvoiceList._search.toLowerCase();
    if (search) {
      sales = sales.filter(s =>
        s.invoiceNo.toLowerCase().includes(search) ||
        (s.customerName || '').toLowerCase().includes(search) ||
        (s.sellerName || '').toLowerCase().includes(search)
      );
    }

    // تطبيق الفلتر
    if (InvoiceList._filter === 'cash') sales = sales.filter(s => s.type === 'cash');
    else if (InvoiceList._filter === 'debt') sales = sales.filter(s => s.type === 'debt');

    const totalAmount = sales.reduce((s, x) => s + x.total, 0);
    const cashTotal = sales.filter(s => s.type === 'cash').reduce((s, x) => s + x.total, 0);
    const debtTotal = sales.filter(s => s.type === 'debt').reduce((s, x) => s + (x.remainingAmount || 0), 0);

    return `
      <div class="card">
        <div class="card-header">
          <h2>🧾 سجل الفواتير</h2>
          <div style="display:flex;gap:0.5rem;flex-wrap:wrap;">
            <input type="text" id="invoiceSearch" placeholder="🔍 بحث برقم الفاتورة أو العميل..." value="${escapeHtml(InvoiceList._search)}" style="min-width:200px;" />
            <select id="invoiceTypeFilter">
              <option value="all" ${InvoiceList._filter === 'all' ? 'selected' : ''}>كل الفواتير</option>
              <option value="cash" ${InvoiceList._filter === 'cash' ? 'selected' : ''}>نقدي فقط</option>
              <option value="debt" ${InvoiceList._filter === 'debt' ? 'selected' : ''}>آجل فقط</option>
            </select>
            <button class="btn btn-success" id="printAllBtn">🖨️ طباعة الكل</button>
          </div>
        </div>
        <div class="card-body">
          <div class="stats-grid" style="margin-bottom:1rem;">
            <div class="stat-card">
              <div class="stat-icon">🧾</div>
              <div class="stat-label">عدد الفواتير</div>
              <div class="stat-value">${sales.length}</div>
            </div>
            <div class="stat-card success">
              <div class="stat-icon">💵</div>
              <div class="stat-label">إجمالي المبيعات</div>
              <div class="stat-value">${totalAmount.toFixed(2)} $</div>
            </div>
            <div class="stat-card">
              <div class="stat-icon">✅</div>
              <div class="stat-label">المبيعات النقدية</div>
              <div class="stat-value">${cashTotal.toFixed(2)} $</div>
            </div>
            <div class="stat-card danger">
              <div class="stat-icon">📝</div>
              <div class="stat-label">الديون المعلقة</div>
              <div class="stat-value">${debtTotal.toFixed(2)} $</div>
            </div>
          </div>

          <div class="table-wrap">
            ${sales.length === 0
              ? '<div class="empty-state"><div class="empty-icon">🧾</div><p>لا توجد فواتير</p></div>'
              : `<table>
                  <thead>
                    <tr>
                      <th>رقم الفاتورة</th>
                      <th>التاريخ</th>
                      <th>العميل</th>
                      <th>البائع</th>
                      <th>النوع</th>
                      <th>الأصناف</th>
                      <th>الإجمالي</th>
                      <th>المتبقي</th>
                      <th>إجراءات</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${sales.map(s => `
                      <tr>
                        <td><strong>${s.invoiceNo}</strong></td>
                        <td><small>${new Date(s.createdAt).toLocaleString('ar-EG')}</small></td>
                        <td>${escapeHtml(s.customerName)}</td>
                        <td>${escapeHtml(s.sellerName || '—')}</td>
                        <td>${s.type === 'cash'
                          ? '<span class="badge badge-success">💵 نقدي</span>'
                          : '<span class="badge badge-warning">📝 آجل</span>'}</td>
                        <td>${(s.items || []).length}</td>
                        <td><strong>${s.total.toFixed(2)} $</strong></td>
                        <td>${s.type === 'debt'
                          ? `<span style="color:var(--danger);font-weight:600;">${(s.remainingAmount || 0).toFixed(2)} $</span>`
                          : '<span style="color:var(--text-muted);">—</span>'}</td>
                        <td class="actions-cell">
                          <button class="btn btn-sm btn-success" data-print-invoice="${s.id}" title="طباعة فورية">🖨️</button>
                          <button class="btn btn-sm btn-primary" data-view-invoice="${s.id}" title="عرض التفاصيل">👁️</button>
                          <button class="btn btn-sm btn-info" data-pdf-invoice="${s.id}" title="تحميل PDF">📥</button>
                          <button class="btn btn-sm btn-warning" data-share-invoice="${s.id}" title="مشاركة">📤</button>
                        </td>
                      </tr>
                    `).join('')}
                  </tbody>
                </table>`
            }
          </div>
        </div>
      </div>
    `;
  },

  bindEvents: () => {
    const searchInput = document.getElementById('invoiceSearch');
    searchInput?.addEventListener('input', (e) => {
      InvoiceList._search = e.target.value;
      InvoiceList.refresh();
      // إعادة التركيز
      const newInput = document.getElementById('invoiceSearch');
      if (newInput) {
        newInput.focus();
        newInput.setSelectionRange(newInput.value.length, newInput.value.length);
      }
    });

    document.getElementById('invoiceTypeFilter')?.addEventListener('change', (e) => {
      InvoiceList._filter = e.target.value;
      InvoiceList.refresh();
    });

    document.getElementById('printAllBtn')?.addEventListener('click', () => {
      const sales = Sales.all();
      if (sales.length === 0) {
        toast('لا توجد فواتير للطباعة', 'warning');
        return;
      }
      InvoiceList.printBatch(sales);
    });

    // أزرار كل صف
    document.querySelectorAll('[data-print-invoice]').forEach(btn => {
      btn.addEventListener('click', () => {
        const sale = Sales.find(btn.dataset.printInvoice);
        if (sale) Invoice.print(sale);
      });
    });

    document.querySelectorAll('[data-view-invoice]').forEach(btn => {
      btn.addEventListener('click', () => {
        const sale = Sales.find(btn.dataset.viewInvoice);
        if (sale) Invoice.viewDetails(sale);
      });
    });

    document.querySelectorAll('[data-pdf-invoice]').forEach(btn => {
      btn.addEventListener('click', () => {
        const sale = Sales.find(btn.dataset.pdfInvoice);
        if (sale) Invoice.generate(sale);
      });
    });

    document.querySelectorAll('[data-share-invoice]').forEach(btn => {
      btn.addEventListener('click', () => {
        const sale = Sales.find(btn.dataset.shareInvoice);
        if (sale) Invoice.share(sale);
      });
    });
  },

  refresh: () => {
    const container = document.getElementById('pageContainer');
    container.innerHTML = InvoiceList.render();
    InvoiceList.bindEvents();
  },

  // ===== طباعة مجموعة فواتير =====
  printBatch: (sales) => {
    const settings = Settings.get();
    const printWindow = window.open('', '_blank', 'width=800,height=900');
    if (!printWindow) {
      toast('يرجى السماح بالنوافذ المنبثقة', 'warning');
      return;
    }

    const html = `
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <title>تقرير الفواتير</title>
  <style>
    @page { size: A4; margin: 10mm; }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Cairo', sans-serif; padding: 8mm; }
    h1 { text-align: center; color: #2563eb; margin-bottom: 8px; }
    .meta { text-align: center; color: #64748b; margin-bottom: 16px; font-size: 13px; }
    table { width: 100%; border-collapse: collapse; font-size: 12px; margin-bottom: 16px; }
    th { background: #2563eb; color: #fff; padding: 6px; text-align: right; }
    td { padding: 5px 6px; border-bottom: 1px solid #e2e8f0; }
    tr:nth-child(even) { background: #f8fafc; }
    .summary {
      margin-top: 16px;
      padding: 12px;
      background: #f1f5f9;
      border-radius: 6px;
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 8px;
      text-align: center;
    }
    .summary div { padding: 8px; }
    .summary strong { display: block; color: #2563eb; font-size: 18px; }
    .no-print { text-align: center; margin: 20px 0; padding: 10px; background: #fef3c7; border-radius: 6px; }
    .no-print button { background: #2563eb; color: #fff; border: none; padding: 8px 20px; border-radius: 6px; font-size: 13px; font-weight: 600; cursor: pointer; font-family: inherit; margin: 0 4px; }
    @media print { .no-print { display: none; } }
  </style>
</head>
<body>
  <div class="no-print">
    🖨️ تقرير ${sales.length} فاتورة - اضغط Ctrl+P أو الزر
    <br><br>
    <button onclick="window.print()">🖨️ طباعة</button>
    <button style="background:#64748b;" onclick="window.close()">✕ إغلاق</button>
  </div>

  <h1>🧾 تقرير الفواتير</h1>
  <div class="meta">
    ${escapeHtml(settings.storeName || 'متجري')} •
    طُبع: ${new Date().toLocaleString('ar-EG')} •
    عدد الفواتير: ${sales.length}
  </div>

  <table>
    <thead>
      <tr>
        <th>رقم</th>
        <th>التاريخ</th>
        <th>العميل</th>
        <th>النوع</th>
        <th>الأصناف</th>
        <th>الإجمالي</th>
        <th>المتبقي</th>
      </tr>
    </thead>
    <tbody>
      ${sales.map(s => `
        <tr>
          <td>${s.invoiceNo}</td>
          <td>${new Date(s.createdAt).toLocaleDateString('ar-EG')}</td>
          <td>${escapeHtml(s.customerName)}</td>
          <td>${s.type === 'cash' ? 'نقدي' : 'آجل'}</td>
          <td>${(s.items || []).length}</td>
          <td><strong>${s.total.toFixed(2)}</strong></td>
          <td>${s.type === 'debt' ? (s.remainingAmount || 0).toFixed(2) : '—'}</td>
        </tr>
      `).join('')}
    </tbody>
  </table>

  <div class="summary">
    <div>
      <strong>${sales.length}</strong>
      <small>عدد الفواتير</small>
    </div>
    <div>
      <strong>${sales.reduce((s, x) => s + x.total, 0).toFixed(2)}</strong>
      <small>إجمالي المبيعات</small>
    </div>
    <div>
      <strong>${sales.filter(s => s.type === 'debt').reduce((s, x) => s + (x.remainingAmount || 0), 0).toFixed(2)}</strong>
      <small>الديون المعلقة</small>
    </div>
  </div>

  <script>
    window.addEventListener('load', () => {
      setTimeout(() => { if (window.opener) window.print(); }, 600);
    });
  <\/script>
</body>
</html>
    `;
    printWindow.document.write(html);
    printWindow.document.close();
  },
};
