// =====================================================
// نظام البيع - نقطة البيع (POS)
// =====================================================

const SalesPage = {
  cart: [], // { product, qty, customPrice }

  render: () => {
    return `
      <div class="pos-layout">
        <div class="product-search-area">
          <div class="card">
            <div class="card-header">
              <h2>🛒 إضافة منتجات للفاتورة</h2>
            </div>
            <div class="card-body">
              <div class="search-input-wrap">
                <input type="text" id="productSearch" placeholder="ابحث بالاسم أو امسح الباركود..." autofocus />
              </div>
              <div style="margin-top:0.75rem;display:flex;gap:0.5rem;flex-wrap:wrap;">
                <button class="btn btn-primary" id="posScanBtn">📷 سكان باركود</button>
                <button class="btn btn-ghost" id="posClearSearch">مسح</button>
              </div>
              <div id="searchResults" style="margin-top:1rem;"></div>
            </div>
          </div>
        </div>
        <div class="cart-panel">
          <div class="card-header">
            <h2>🧾 الفاتورة الحالية</h2>
          </div>
          <div class="cart-items" id="cartItems">
            <div class="empty-state">
              <div class="empty-icon">🛒</div>
              <p>الفاتورة فارغة</p>
              <p style="font-size:0.85rem;">ابدأ بإضافة منتجات</p>
            </div>
          </div>
          <div class="cart-total">
            <div class="cart-total-row">
              <span>عدد الأصناف:</span>
              <span id="cartItemCount">0</span>
            </div>
            <div class="cart-total-row grand">
              <span>الإجمالي:</span>
              <span id="cartTotal">0.00 د.ع</span>
            </div>
          </div>
          <div class="cart-actions" style="display:flex;flex-direction:column;gap:0.5rem;">
            <div class="form-group" style="margin:0;">
              <label style="font-size:0.8rem;color:var(--text-muted);margin-bottom:0.25rem;display:flex;align-items:center;gap:0.3rem;">
                📝 <span>ملاحظة على الفاتورة (اختياري)</span>
              </label>
              <textarea id="invoiceNote" placeholder="مثال: توصيل بكرا، هدية، دفع نصف المبلغ..." maxlength="300" rows="2" style="width:100%;padding:0.5rem;border:1.5px solid #e2e8f0;border-radius:8px;font-family:inherit;font-size:0.9rem;resize:vertical;box-sizing:border-box;background:#f8fafc;"></textarea>
              <small style="color:var(--text-muted);font-size:0.7rem;display:block;margin-top:0.15rem;text-align:left;">
                <span id="invoiceNoteCount">0</span>/300
              </small>
            </div>
            <button class="btn btn-success btn-block" id="checkoutCash">💵 بيع نقدي</button>
            <button class="btn btn-warning btn-block" id="checkoutDebt">📝 بيع آجل (دين)</button>
            <button class="btn btn-ghost btn-block" id="clearCart">🗑️ إفراغ الفاتورة</button>
          </div>
        </div>
      </div>
    `;
  },

  bindEvents: () => {
    const searchInput = document.getElementById('productSearch');
    const scanBtn = document.getElementById('posScanBtn');
    const clearSearchBtn = document.getElementById('posClearSearch');

    // البحث
    let searchTimeout;
    const onSearch = () => {
      clearTimeout(searchTimeout);
      const q = searchInput.value.trim();
      if (q.length === 0) {
        document.getElementById('searchResults').innerHTML = '';
        return;
      }
      // إذا كان الباركود (يحتوي على أرقام فقط وطويل) → حاول إضافة مباشرة
      if (q.length >= 8 && /^\d+$/.test(q)) {
        const product = Products.findByBarcode(q);
        if (product) {
          SalesPage.addToCart(product);
          searchInput.value = '';
          document.getElementById('searchResults').innerHTML = '';
          return;
        }
      }
      // بحث عادي
      searchTimeout = setTimeout(() => SalesPage._showSearchResults(q), 200);
    };

    searchInput?.addEventListener('input', onSearch);
    searchInput?.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        onSearch();
      }
    });

    scanBtn?.addEventListener('click', () => {
      Scanner.open((barcode) => {
        Scanner.close();
        const product = Products.findByBarcode(barcode);
        if (product) {
          SalesPage.addToCart(product);
          toast(`تم إضافة: ${product.name}`, 'success');
        } else {
          toast(`الباركود ${barcode} غير موجود في المخزون`, 'error');
        }
      });
    });

    clearSearchBtn?.addEventListener('click', () => {
      searchInput.value = '';
      document.getElementById('searchResults').innerHTML = '';
    });

    document.getElementById('clearCart')?.addEventListener('click', () => {
      if (SalesPage.cart.length === 0 && !document.getElementById('invoiceNote')?.value.trim()) return;
      if (confirm('إفراغ الفاتورة الحالية؟')) {
        SalesPage.cart = [];
        const noteEl = document.getElementById('invoiceNote');
        if (noteEl) noteEl.value = '';
        const cntEl = document.getElementById('invoiceNoteCount');
        if (cntEl) cntEl.textContent = '0';
        SalesPage.renderCart();
      }
    });

    // عداد أحرف الملاحظة
    const noteEl = document.getElementById('invoiceNote');
    const noteCnt = document.getElementById('invoiceNoteCount');
    if (noteEl && noteCnt) {
      noteEl.addEventListener('input', () => {
        noteCnt.textContent = String(noteEl.value.length);
      });
    }

    document.getElementById('checkoutCash')?.addEventListener('click', () => {
      SalesPage.checkout('cash');
    });

    document.getElementById('checkoutDebt')?.addEventListener('click', () => {
      SalesPage.checkout('debt');
    });

    document.getElementById('cartItems')?.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-cart-action]');
      if (!btn) return;
      const action = btn.dataset.cartAction;
      const productId = btn.dataset.productId;
      const item = SalesPage.cart.find(c => c.product.id === productId);
      if (!item) return;

      if (action === 'increase') SalesPage.updateQty(productId, item.qty + 1);
      else if (action === 'decrease') SalesPage.updateQty(productId, item.qty - 1);
      else if (action === 'remove') SalesPage.updateQty(productId, 0);
    });
  },

  _showSearchResults: (query) => {
    const q = (query || '').toLowerCase();
    const results = Products.all().filter(p => {
      if (p.name.toLowerCase().includes(q)) return true;
      if (String(p.barcode || '').includes(q)) return true;
      // يبحث في الباركودات الإضافية كمان
      if (Array.isArray(p.barcodes)) {
        return p.barcodes.some(b => String(b).includes(q));
      }
      return false;
    }).slice(0, 20);

    const container = document.getElementById('searchResults');
    if (results.length === 0) {
      container.innerHTML = '<p style="text-align:center;color:var(--text-muted);padding:1rem;">لا توجد نتائج</p>';
      return;
    }

    container.innerHTML = `
      <div style="display:grid;gap:0.5rem;">
        ${results.map(p => `
          <div class="cart-item product-card-with-image" style="border:1px solid var(--border);border-radius:8px;cursor:pointer;" data-add-to-cart="${p.id}">
            <div class="product-card-image">
              ${p.image
                ? `<img src="${p.image}" class="product-thumb product-thumb-medium" alt="${escapeHtml(p.name)}" />`
                : `<div class="product-thumb product-thumb-medium" style="display:flex;align-items:center;justify-content:center;font-size:1.5rem;background:var(--bg);">📦</div>`
              }
            </div>
            <div class="product-card-info">
              <div class="cart-item-name">${escapeHtml(p.name)}</div>
              <div class="cart-item-price">${p.price.toFixed(2)} $ • المخزون: ${p.stock}</div>
            </div>
            <button class="btn btn-sm btn-primary">إضافة</button>
          </div>
        `).join('')}
      </div>
    `;

    container.querySelectorAll('[data-add-to-cart]').forEach(el => {
      el.addEventListener('click', () => {
        const product = Products.find(el.dataset.addToCart);
        if (product) {
          SalesPage.addToCart(product);
          document.getElementById('productSearch').value = '';
          container.innerHTML = '';
        }
      });
    });
  },

  addToCart: (product) => {
    if (product.stock <= 0) {
      toast(`المنتج "${product.name}" نفد من المخزون`, 'error');
      return;
    }

    const existing = SalesPage.cart.find(c => c.product.id === product.id);
    if (existing) {
      if (existing.qty >= product.stock) {
        toast(`الكمية القصوى المتاحة: ${product.stock}`, 'warning');
        return;
      }
      existing.qty += 1;
    } else {
      SalesPage.cart.push({ product, qty: 1, customPrice: product.price });
    }
    SalesPage.renderCart();
  },

  updateQty: (productId, qty) => {
    if (qty <= 0) {
      SalesPage.cart = SalesPage.cart.filter(c => c.product.id !== productId);
    } else {
      const item = SalesPage.cart.find(c => c.product.id === productId);
      if (item) {
        if (qty > item.product.stock) {
          toast(`الكمية القصوى المتاحة: ${item.product.stock}`, 'warning');
          return;
        }
        item.qty = qty;
      }
    }
    SalesPage.renderCart();
  },

  renderCart: () => {
    const container = document.getElementById('cartItems');
    const countEl = document.getElementById('cartItemCount');
    const totalEl = document.getElementById('cartTotal');

    if (SalesPage.cart.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">🛒</div>
          <p>الفاتورة فارغة</p>
        </div>
      `;
      countEl.textContent = '0';
      totalEl.textContent = '0.00 د.ع';
      return;
    }

    let total = 0;
    let totalCost = 0;
    container.innerHTML = SalesPage.cart.map(({ product, qty, customPrice }) => {
      const usePrice = (typeof customPrice === 'number' && customPrice > 0) ? customPrice : product.price;
      const subtotal = usePrice * qty;
      const cost = (product.cost || 0) * qty;
      const profit = subtotal - cost;
      const profitPct = cost > 0 ? ((profit / cost) * 100) : 0;
      const isCustomPrice = usePrice !== product.price;
      const isLoss = profit < 0;

      total += subtotal;
      totalCost += cost;
      return `
        <div class="cart-item ${isCustomPrice ? 'has-custom-price' : ''}">
          <div class="cart-item-info">
            <div class="cart-item-name">${escapeHtml(product.name)}</div>
            <div class="cart-item-price">
              <div class="price-block price-block-suggested">
                <span class="price-label">💡 السعر المقترح</span>
                <span class="price-suggested-value">${product.price.toFixed(2)} $</span>
                <button type="button" class="btn-use-suggested" data-use-suggested="${product.id}" title="استخدم السعر المقترح">↺ استخدم</button>
              </div>
              <div class="price-block price-block-custom">
                <span class="price-label">✍️ سعر البيع الحر</span>
                <div class="custom-price-input-wrap">
                  <input type="number" class="cart-item-price-input" min="0" step="0.01" value="${usePrice.toFixed(2)}" data-price-input="${product.id}" placeholder="أدخل سعرك" />
                  <span class="price-currency">د.ع</span>
                </div>
                ${isCustomPrice ? '<span class="custom-badge">مخصص</span>' : ''}
              </div>
              <div class="price-block price-block-summary">
                <span class="price-line">× ${qty} = <strong class="cart-item-subtotal" data-subtotal="${product.id}">${subtotal.toFixed(2)} $</strong></span>
                ${cost > 0 ? `<span class="profit-indicator ${isLoss ? 'loss' : 'profit'}">${isLoss ? '⚠️ خسارة' : '✅ ربح'}: ${profit.toFixed(2)} $ (${profitPct.toFixed(0)}%)</span>` : ''}
              </div>
            </div>
          </div>
          <div class="qty-control">
            <button data-cart-action="decrease" data-product-id="${product.id}">−</button>
            <input type="number" value="${qty}" min="1" max="${product.stock}" data-qty-input="${product.id}" />
            <button data-cart-action="increase" data-product-id="${product.id}">+</button>
            <button data-cart-action="remove" data-product-id="${product.id}" style="background:var(--danger-light);color:var(--danger);">✕</button>
          </div>
        </div>
      `;
    }).join('');

    countEl.textContent = SalesPage.cart.length;
    let totalText = total.toFixed(2) + ' د.ع';
    if (totalCost > 0) {
      const totalProfit = total - totalCost;
      const totalProfitPct = totalCost > 0 ? ((totalProfit / totalCost) * 100) : 0;
      const profitClass = totalProfit < 0 ? 'loss' : 'profit';
      totalText += ` <span class="cart-profit ${profitClass}" style="font-size:0.85rem;display:block;margin-top:0.25rem;">${totalProfit < 0 ? '⚠️' : '✅'} ربح: ${totalProfit.toFixed(2)} $ (${totalProfitPct.toFixed(0)}%)</span>`;
    }
    totalEl.innerHTML = totalText;

    // ربط تعديل الكمية اليدوي
    container.querySelectorAll('[data-qty-input]').forEach(input => {
      input.addEventListener('change', (e) => {
        const qty = Number(e.target.value);
        SalesPage.updateQty(input.dataset.qtyInput, qty);
      });
    });

    // ربط تعديل سعر البيع المخصص
    container.querySelectorAll('[data-price-input]').forEach(input => {
      input.addEventListener('input', (e) => {
        const id = input.dataset.priceInput;
        const v = Number(e.target.value);
        SalesPage.updateCustomPrice(id, v);
      });
      // عند الخروج من الحقل، إذا فاضي يرجع للمقترح
      input.addEventListener('blur', (e) => {
        const id = input.dataset.priceInput;
        if (e.target.value === '' || Number(e.target.value) < 0) {
          const item = SalesPage.cart.find(c => c.product.id === id);
          if (item) {
            item.customPrice = item.product.price;
            SalesPage.renderCart();
          }
        }
      });
    });

    // زر "استخدم السعر المقترح"
    container.querySelectorAll('[data-use-suggested]').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.dataset.useSuggested;
        const item = SalesPage.cart.find(c => c.product.id === id);
        if (item) {
          item.customPrice = item.product.price;
          SalesPage.renderCart();
          toast('تم اعتماد السعر المقترح', 'success', 1500);
        }
      });
    });
  },

  updateCustomPrice: (productId, value) => {
    const item = SalesPage.cart.find(c => c.product.id === productId);
    if (!item) return;
    const v = Number(value);
    item.customPrice = (!isNaN(v) && v >= 0) ? v : item.product.price;
    // إعادة احتساب الإجمالي للصف فقط دون إعادة رسم الفاتورة (لتجنب فقدان تركيز الحقل)
    const qty = item.qty;
    const subtotal = item.customPrice * qty;
    const subEl = document.querySelector(`[data-subtotal="${productId}"]`);
    if (subEl) subEl.textContent = subtotal.toFixed(2) + ' د.ع';
    // إعادة احتساب الإجمالي العام
    let total = 0;
    SalesPage.cart.forEach(c => {
      const p = (typeof c.customPrice === 'number' && c.customPrice > 0) ? c.customPrice : c.product.price;
      total += p * c.qty;
    });
    const totalEl = document.getElementById('cartTotal');
    if (totalEl) totalEl.textContent = total.toFixed(2) + ' د.ع';
  },

  checkout: (type) => {
    if (SalesPage.cart.length === 0) {
      toast('الفاتورة فارغة', 'warning');
      return;
    }

    if (type === 'cash') {
      SalesPage._completeSale('cash', null);
    } else {
      // فتح نافذة اختيار العميل
      SalesPage._showCustomerSelector();
    }
  },

  _showCustomerSelector: () => {
    const customers = Customers.all();
    const content = `
      <div class="form-group">
        <label>اختر العميل</label>
        <select id="debtCustomerSelect">
          <option value="">— عميل جديد —</option>
          ${customers.map(c => `<option value="${c.id}">${escapeHtml(c.name)} ${c.phone ? '(' + c.phone + ')' : ''}</option>`).join('')}
        </select>
      </div>
      <div id="newCustomerFields" style="display:none;">
        <div class="form-group">
          <label>اسم العميل *</label>
          <input type="text" id="newCustName" />
        </div>
        <div class="form-group">
          <label>رقم الهاتف</label>
          <input type="tel" id="newCustPhone" />
        </div>
        <div class="form-group">
          <label>العنوان</label>
          <input type="text" id="newCustAddress" />
        </div>
      </div>
      <div class="form-group">
        <label>المبلغ المدفوع الآن (اختياري)</label>
        <input type="number" id="debtPaidAmount" min="0" step="0.01" value="0" />
        <small style="color:var(--text-muted);">اتركه 0 للدين الكامل</small>
      </div>
      <div class="modal-footer" style="padding-inline-start:0;">
        <button class="btn btn-warning" id="confirmDebtSale">تأكيد البيع الآجل</button>
        <button class="btn btn-ghost" data-close="genericModal">إلغاء</button>
      </div>
    `;
    openModal('بيع آجل - اختر العميل', content);

    document.getElementById('debtCustomerSelect').addEventListener('change', (e) => {
      document.getElementById('newCustomerFields').style.display = e.target.value === '' ? 'block' : 'none';
    });

    document.getElementById('confirmDebtSale').addEventListener('click', () => {
      const customerId = document.getElementById('debtCustomerSelect').value;
      let customer = null;

      if (customerId) {
        customer = Customers.find(customerId);
        if (!customer) {
          toast('العميل غير موجود', 'error');
          return;
        }
      } else {
        const name = document.getElementById('newCustName').value.trim();
        if (!name) {
          toast('اسم العميل مطلوب', 'error');
          return;
        }
        customer = Customers.add({
          name,
          phone: document.getElementById('newCustPhone').value.trim(),
          address: document.getElementById('newCustAddress').value.trim(),
        });
      }

      const paidAmount = Number(document.getElementById('debtPaidAmount').value || 0);
      SalesPage._completeSale('debt', customer, paidAmount);
    });
  },

  _completeSale: (type, customer, paidAmount = 0) => {
    const user = Auth.require();
    const items = SalesPage.cart.map(c => {
      const usePrice = (typeof c.customPrice === 'number' && c.customPrice > 0) ? c.customPrice : c.product.price;
      return {
        productId: c.product.id,
        name: c.product.name,
        barcode: c.product.barcode,
        qty: c.qty,
        price: usePrice,
        suggestedPrice: c.product.price,
        cost: c.product.cost,
        subtotal: c.qty * usePrice,
      };
    });

    const total = items.reduce((s, i) => s + i.subtotal, 0);
    const remaining = type === 'debt' ? Math.max(0, total - paidAmount) : 0;

    const sale = {
      type, // 'cash' or 'debt'
      customerId: customer?.id || null,
      customerName: customer?.name || 'نقدي',
      items,
      total,
      paidAmount: type === 'cash' ? total : paidAmount,
      remainingAmount: remaining,
      status: type === 'cash' ? 'paid' : (remaining > 0 ? 'partial' : 'paid'),
      sellerId: user.id,
      sellerName: user.name,
      note: (document.getElementById('invoiceNote')?.value || '').trim(),
    };

    const saved = Sales.add(sale);

    // تحديث المخزون
    items.forEach(i => Products.adjustStock(i.productId, -i.qty));

    // إنشاء سجل دين إذا في متبقي
    if (remaining > 0 && customer) {
      Debts.add({
        type: 'sale',
        customerId: customer.id,
        customerName: customer.name,
        saleId: saved.id,
        invoiceNo: saved.invoiceNo,
        amount: total,
        paidAmount,
        remainingAmount: remaining,
        status: 'pending',
      });

      // تحديث إجمالي ديون العميل
      const allDebts = Debts.byCustomer(customer.id);
      const totalDebt = allDebts.reduce((s, d) => s + d.remainingAmount, 0);
      Customers.update(customer.id, { totalDebt });
    }

    // تحديث إجمالي مشتريات العميل
    if (customer) {
      const customerSales = Sales.all().filter(s => s.customerId === customer.id);
      const totalPurchases = customerSales.reduce((s, x) => s + x.total, 0);
      Customers.update(customer.id, { totalPurchases });
    }

    // توليد PDF
    Invoice.generate(saved);

    // مسح الملاحظة بعد إتمام البيع
    const noteEl = document.getElementById('invoiceNote');
    if (noteEl) noteEl.value = '';
    const noteCnt = document.getElementById('invoiceNoteCount');
    if (noteCnt) noteCnt.textContent = '0';

    toast(`تمت العملية بنجاح - فاتورة رقم ${saved.invoiceNo}`, 'success');
    SalesPage.cart = [];
    SalesPage.renderCart();
    closeModal('genericModal');
  },
};

// =====================================================
// سجل المبيعات
// =====================================================
const SalesHistory = {
  render: () => {
    const sales = Sales.all().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    return `
      <div class="card">
        <div class="card-header">
          <h2>🧾 سجل المبيعات</h2>
          <div style="display:flex;gap:0.5rem;flex-wrap:wrap;">
            <input type="date" id="salesDateFrom" />
            <input type="date" id="salesDateTo" />
            <select id="salesTypeFilter">
              <option value="">كل الأنواع</option>
              <option value="cash">نقدي</option>
              <option value="debt">آجل</option>
            </select>
          </div>
        </div>
        <div class="card-body">
          <!-- 🔍 البحث برقم الفاتورة -->
          <div class="invoice-search-bar">
            <input type="text" id="invoiceQuickSearch" placeholder="🔍 ابحث برقم الفاتورة (مثال: INV-1001)..." style="flex:1;max-width:400px;" />
            <button class="btn btn-primary" id="invoiceQuickSearchBtn">بحث</button>
            <button class="btn btn-ghost" id="invoiceQuickSearchClear">✕ مسح</button>
          </div>
          <div id="invoiceSearchResult"></div>
          <div class="table-wrap" id="salesTableWrap">${SalesHistory._renderTable(sales)}</div>
        </div>
      </div>
    `;
  },

  _renderTable: (sales) => {
    if (sales.length === 0) {
      return '<div class="empty-state"><div class="empty-icon">🧾</div><p>لا توجد مبيعات بعد</p></div>';
    }

    const dateFrom = document.getElementById('salesDateFrom')?.value;
    const dateTo = document.getElementById('salesDateTo')?.value;
    const typeFilter = document.getElementById('salesTypeFilter')?.value;

    let filtered = sales;
    if (dateFrom) filtered = filtered.filter(s => new Date(s.createdAt) >= new Date(dateFrom));
    if (dateTo) filtered = filtered.filter(s => new Date(s.createdAt) <= new Date(dateTo + 'T23:59:59'));
    if (typeFilter) filtered = filtered.filter(s => s.type === typeFilter);

    if (filtered.length === 0) {
      return '<div class="empty-state"><div class="empty-icon">🔍</div><p>لا توجد نتائج تطابق الفلتر</p></div>';
    }

    return `
      <table>
        <thead>
          <tr>
            <th>رقم الفاتورة</th>
            <th>التاريخ</th>
            <th>العميل</th>
            <th>النوع</th>
            <th>الأصناف</th>
            <th>الإجمالي</th>
            <th>المتبقي</th>
            <th>البائع</th>
            <th>إجراءات</th>
          </tr>
        </thead>
        <tbody>
          ${filtered.map(s => `
            <tr>
              <td>
                <strong>${s.invoiceNo}</strong>
                ${s.note && s.note.trim() ? `<div title="${escapeHtml(s.note)}" style="margin-top:2px;"><span style="background:#fef9c3;color:#854d0e;padding:1px 6px;border-radius:4px;font-size:0.7rem;cursor:help;">📝 ملاحظة</span></div>` : ''}
              </td>
              <td>${new Date(s.createdAt).toLocaleString('ar-EG')}</td>
              <td>${escapeHtml(s.customerName)}</td>
              <td>${s.type === 'cash' ? '<span class="badge badge-success">نقدي</span>' : '<span class="badge badge-warning">آجل</span>'}</td>
              <td>${s.items.length} صنف</td>
              <td><strong>${s.total.toFixed(2)} $</strong></td>
              <td>${s.remainingAmount > 0 ? `<span style="color:var(--danger);">${s.remainingAmount.toFixed(2)} $</span>` : '—'}</td>
              <td>${escapeHtml(s.sellerName)}</td>
              <td class="actions-cell">
                <button class="btn btn-sm btn-ghost" data-action="view-sale" data-id="${s.id}">👁️</button>
                <button class="btn btn-sm btn-ghost" data-action="print-sale" data-id="${s.id}">🖨️</button>
                <button class="btn btn-sm btn-ghost" data-action="delete-sale" data-id="${s.id}">🗑️</button>
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;
  },

  bindEvents: () => {
    // 🔍 البحث برقم الفاتورة
    const searchInput = document.getElementById('invoiceQuickSearch');
    const searchBtn = document.getElementById('invoiceQuickSearchBtn');
    const clearBtn = document.getElementById('invoiceQuickSearchClear');

    const doInvoiceSearch = () => {
      const q = searchInput.value.trim();
      const resultEl = document.getElementById('invoiceSearchResult');
      if (!q) {
        resultEl.innerHTML = '';
        return;
      }
      const sale = Enhancements.searchInvoice(q);
      if (!sale) {
        resultEl.innerHTML = `
          <div class="invoice-search-result" style="background:var(--danger-light);border-color:var(--danger);">
            <span>❌ لم يتم العثور على فاتورة بالرقم "<strong>${escapeHtml(q)}</strong>"</span>
          </div>
        `;
        return;
      }
      resultEl.innerHTML = `
        <div class="invoice-search-result">
          <div>
            <strong>✅ تم العثور على الفاتورة ${sale.invoiceNo}</strong>
            <div style="font-size:0.85rem;color:var(--text-muted);margin-top:0.25rem;">
              ${new Date(sale.createdAt).toLocaleString('ar-EG')} •
              ${escapeHtml(sale.customerName)} •
              <strong>${sale.total.toFixed(2)} $</strong>
            </div>
          </div>
          <div style="display:flex;gap:0.4rem;">
            <button class="btn btn-sm btn-primary" id="searchResultView" data-id="${sale.id}">👁️ عرض</button>
            <button class="btn btn-sm btn-success" id="searchResultPrint" data-id="${sale.id}">🖨️ طباعة</button>
          </div>
        </div>
      `;
      document.getElementById('searchResultView')?.addEventListener('click', (e) => {
        Invoice.viewDetails(sale);
      });
      document.getElementById('searchResultPrint')?.addEventListener('click', () => {
        Invoice.generate(sale);
      });
    };

    searchBtn?.addEventListener('click', doInvoiceSearch);
    searchInput?.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') doInvoiceSearch();
    });
    clearBtn?.addEventListener('click', () => {
      searchInput.value = '';
      document.getElementById('invoiceSearchResult').innerHTML = '';
    });

    document.getElementById('salesDateFrom')?.addEventListener('change', () => {
      const wrap = document.getElementById('salesTableWrap');
      if (wrap) wrap.innerHTML = SalesHistory._renderTable(Sales.all().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)));
    });
    document.getElementById('salesDateTo')?.addEventListener('change', () => {
      const wrap = document.getElementById('salesTableWrap');
      if (wrap) wrap.innerHTML = SalesHistory._renderTable(Sales.all().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)));
    });
    document.getElementById('salesTypeFilter')?.addEventListener('change', () => {
      const wrap = document.getElementById('salesTableWrap');
      if (wrap) wrap.innerHTML = SalesHistory._renderTable(Sales.all().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)));
    });

    document.getElementById('salesTableWrap')?.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-action]');
      if (!btn) return;
      const action = btn.dataset.action;
      const id = btn.dataset.id;
      const sale = Sales.find(id);
      if (!sale) return;

      if (action === 'view-sale') {
        Invoice.viewDetails(sale);
      } else if (action === 'print-sale') {
        Invoice.generate(sale);
      } else if (action === 'delete-sale') {
        if (confirm(`حذف الفاتورة ${sale.invoiceNo}؟ سيتم إرجاع المخزون.`)) {
          // إرجاع المخزون
          sale.items.forEach(i => Products.adjustStock(i.productId, i.qty));
          // حذف الديون المرتبطة
          const linkedDebts = Debts.all().filter(d => d.saleId === sale.id);
          linkedDebts.forEach(d => Debts.remove(d.id));
          // حذف الفاتورة
          Sales.remove(sale.id);
          toast('تم حذف الفاتورة وإرجاع المخزون', 'success');
          document.getElementById('salesTableWrap').innerHTML = SalesHistory._renderTable(Sales.all().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)));
        }
      }
    });
  },
};
