// =====================================================
// صفحة الإعدادات
// =====================================================

const SettingsPage = {
  render: () => {
    const s = Settings.get();
    const langs = SUPPORTED_LANGUAGES;
    return `
      <div class="card">
        <div class="card-header">
          <h2>⚙️ ${I18n.t('settings')}</h2>
        </div>
        <div class="card-body">
          <form id="settingsForm">
            <!-- الشعار أولاً عشان يبان واضح -->
            <h3 style="margin-top:0;color:var(--primary);">🖼️ شعار المتجر (يظهر على الفواتير)</h3>
            <div class="form-group">
              <label>${I18n.t('logo_help')}</label>
              <div style="display:flex;gap:0.75rem;align-items:flex-start;flex-wrap:wrap;">
                <div id="logoPreview" style="width:120px;height:120px;border:2px dashed var(--border);border-radius:8px;display:flex;align-items:center;justify-content:center;background:#f8fafc;overflow:hidden;">
                  ${s.logoBase64 ? `<img src="${s.logoBase64}" style="max-width:100%;max-height:100%;object-fit:contain;" />` : '<span style="color:var(--text-muted);font-size:0.85rem;text-align:center;padding:0.5rem;">لا يوجد شعار</span>'}
                </div>
                <div style="display:flex;flex-direction:column;gap:0.5rem;">
                  <label class="btn btn-primary" style="cursor:pointer;">
                    📤 ${I18n.t('upload_logo')}
                    <input type="file" id="logoFileInput" accept="image/png,image/jpeg,image/svg+xml" style="display:none;" />
                  </label>
                  ${s.logoBase64 ? '<button type="button" class="btn btn-ghost" id="removeLogoBtn">🗑️ '+I18n.t('remove_logo')+'</button>' : ''}
                </div>
              </div>
              <input type="hidden" name="logoBase64" id="logoBase64Input" value="${escapeHtml(s.logoBase64 || '')}" />
              <small style="color:var(--text-muted);font-size:0.85rem;display:block;margin-top:0.4rem;">
                💡 PNG شفاف هو الأفضل. يبان واضح بأعلى الفاتورة + خلفية شفافة مائلة.
              </small>
            </div>

            <hr style="border:none;border-top:1px solid var(--border);margin:1.5rem 0;">

            <!-- معلومات المتجر -->
            <h3 style="color:var(--primary);">🏪 معلومات المتجر</h3>
            <div class="grid grid-2">
              <div class="form-group">
                <label>${I18n.t('store_name')}</label>
                <input type="text" name="storeName" value="${escapeHtml(s.storeName || '')}" />
              </div>
              <div class="form-group">
                <label>${I18n.t('store_phone')}</label>
                <input type="tel" name="storePhone" value="${escapeHtml(s.storePhone || '')}" />
              </div>
            </div>
            <div class="form-group">
              <label>${I18n.t('store_address')}</label>
              <input type="text" name="storeAddress" value="${escapeHtml(s.storeAddress || '')}" />
            </div>
            <div class="grid grid-2">
              <div class="form-group">
                <label>${I18n.t('currency')}</label>
                <input type="text" name="currency" value="${escapeHtml(s.currency || 'د.ع')}" />
              </div>
              <div class="form-group">
                <label>نسبة الضريبة %</label>
                <input type="number" name="taxRate" value="${s.taxRate || 0}" min="0" step="0.01" />
              </div>
            </div>

            <hr style="border:none;border-top:1px solid var(--border);margin:1.5rem 0;">

            <!-- اللغة -->
            <h3 style="color:var(--primary);">🌐 ${I18n.t('language')}</h3>
            <div class="form-group">
              <label>اختر لغة الواجهة (${langs.length} لغة متاحة)</label>
              <select name="language" id="settingsLanguageSelect">
                ${langs.map(l => `
                  <option value="${l.code}" ${s.language === l.code ? 'selected' : ''}>
                    ${l.flag} ${l.name} (${l.code.toUpperCase()})
                  </option>
                `).join('')}
              </select>
              <small style="color:var(--text-muted);display:block;margin-top:0.4rem;">
                💡 التغيير فوري - يحدّث اتجاه الصفحة (RTL/LTR) مباشرة
              </small>
            </div>

            <hr style="border:none;border-top:1px solid var(--border);margin:1.5rem 0;">

            <!-- الملاحظات -->
            <h3 style="color:var(--primary);">📝 ملاحظات الفاتورة</h3>
            <div class="form-group">
              <label>⭐ ${I18n.t('primary_notes')}</label>
              <textarea name="primaryNotes" rows="2" placeholder="مثال: شكراً لزيارتكم - نتشرف بخدمتكم">${escapeHtml(s.primaryNotes || '')}</textarea>
              <small style="color:var(--text-muted);">${I18n.t('primary_notes_help')}</small>
            </div>
            <div class="form-group">
              <label>📌 ${I18n.t('secondary_notes')}</label>
              <textarea name="secondaryNotes" rows="3" placeholder="مثال: البضاعة المباعة لا ترد ولا تستبدل بعد 24 ساعة">${escapeHtml(s.secondaryNotes || '')}</textarea>
              <small style="color:var(--text-muted);">${I18n.t('secondary_notes_help')}</small>
            </div>

            <hr style="border:none;border-top:1px solid var(--border);margin:1.5rem 0;">

            <!-- النسخ الاحتياطي -->
            <h3 style="color:var(--primary);">💾 النسخ الاحتياطي</h3>
            <p style="color:var(--text-muted);margin-top:0;">صدّر كل بياناتك (منتجات، مبيعات، عملاء، أعضاء) في ملف واحد. خزّنه على Google Drive أو USB، واستورده عند الحاجة.</p>
            <div style="display:flex;gap:0.5rem;flex-wrap:wrap;">
              <button type="button" class="btn btn-success" id="exportDataBtn">📤 ${I18n.t('export')} كل البيانات</button>
              <label class="btn btn-primary" style="cursor:pointer;">
                📥 ${I18n.t('import')} من ملف
                <input type="file" id="importFileInput" accept="application/json,.json" style="display:none;" />
              </label>
            </div>

            <hr style="border:none;border-top:1px solid var(--border);margin:1.5rem 0;">

            <div class="modal-footer" style="padding-inline-start:0;">
              <button type="submit" class="btn btn-primary btn-block">💾 ${I18n.t('save')}</button>
            </div>
          </form>
        </div>
      </div>
    `;
  },

  afterRender: () => {
    SettingsPage._bindLogoEvents();
    SettingsPage._bindBackupEvents();
    // تطبيق اللغة فوراً عند التغيير
    document.getElementById('settingsLanguageSelect')?.addEventListener('change', (e) => {
      I18n.setLanguage(e.target.value);
      SettingsPage.refresh();
      toast('تم تغيير اللغة — أعد تحميل الصفحة لرؤية كل النصوص', 'info');
    });
  },

  bindEvents: () => {},

  refresh: () => {
    const wrap = document.getElementById('pageContainer');
    if (wrap && document.getElementById('settingsForm')) {
      // نحتفظ بالـ form القيم ثم نعيد الرسم
      wrap.innerHTML = SettingsPage.render();
      SettingsPage._restoreFormValues();
      SettingsPage.afterRender();
    }
  },

  _restoreFormValues: () => {
    // عند تغيير اللغة، نعيد الرسم مع القيم المحفوظة في Settings
    // لا حاجة لعمل إضافي لأن render يقرأ من Settings
  },

  _bindLogoEvents: () => {
    document.getElementById('logoFileInput')?.addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      if (file.size > 2 * 1024 * 1024) {
        toast('حجم الصورة كبير (الحد الأقصى 2MB)', 'error');
        return;
      }
      const reader = new FileReader();
      reader.onload = (ev) => {
        const base64 = ev.target.result;
        document.getElementById('logoBase64Input').value = base64;
        const preview = document.getElementById('logoPreview');
        preview.innerHTML = `<img src="${base64}" style="max-width:100%;max-height:100%;object-fit:contain;" />`;
        toast('تم رفع الشعار — اضغط حفظ لتأكيد', 'success');
      };
      reader.readAsDataURL(file);
    });

    document.getElementById('removeLogoBtn')?.addEventListener('click', () => {
      document.getElementById('logoBase64Input').value = '';
      const preview = document.getElementById('logoPreview');
      preview.innerHTML = '<span style="color:var(--text-muted);font-size:0.85rem;">لا يوجد شعار</span>';
      toast('تم إزالة الشعار — اضغط حفظ لتأكيد', 'info');
    });
  },

  _bindBackupEvents: () => {
    document.getElementById('exportDataBtn')?.addEventListener('click', () => {
      const data = {};
      Object.entries(DB_KEYS).forEach(([k, key]) => {
        data[k] = dbGet(key);
      });
      data.exportedAt = new Date().toISOString();
      data.version = '1.0';
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `backup-${new Date().toISOString().slice(0,10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      toast('✅ تم تصدير النسخة الاحتياطية', 'success');
    });

    document.getElementById('importFileInput')?.addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      if (!confirm('⚠️ استيراد البيانات سيستبدل كل البيانات الحالية. هل أنت متأكد؟')) {
        e.target.value = '';
        return;
      }
      const text = await file.text();
      try {
        const data = JSON.parse(text);
        if (!data.version) throw new Error('ملف غير صالح');
        Object.entries(data).forEach(([k, v]) => {
          if (k === 'exportedAt' || k === 'version') return;
          if (DB_KEYS[k]) dbSet(DB_KEYS[k], v);
        });
        toast('✅ تم استيراد البيانات بنجاح — يتم إعادة تحميل الصفحة', 'success');
        setTimeout(() => location.reload(), 1500);
      } catch (err) {
        toast('❌ خطأ في قراءة الملف: ' + err.message, 'error');
      }
    });
  },

  handleSubmit: (e) => {
    e.preventDefault();
    const form = e.target;
    const fd = new FormData(form);
    const data = Object.fromEntries(fd);
    // logoBase64 قد يكون طويل - نتأكد من حفظه
    if (data.logoBase64 && data.logoBase64.length > 3 * 1024 * 1024) {
      toast('الصورة كبيرة جداً، الرجاء استخدام صورة أصغر', 'error');
      return;
    }
    const langChanged = I18n.current() !== data.language;
    Settings.set(data);
    if (langChanged) I18n.setLanguage(data.language);
    toast('✅ ' + I18n.t('saved_success'), 'success');
    if (langChanged) {
      setTimeout(() => location.reload(), 800);
    }
  },
};
