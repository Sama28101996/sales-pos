// =====================================================
// إدارة الفريق والصلاحيات
// =====================================================

const PERMISSION_LABELS = {
  [PERMISSIONS.VIEW_DASHBOARD]: 'عرض لوحة التحكم',
  [PERMISSIONS.INVENTORY_VIEW]: 'عرض المخزون',
  [PERMISSIONS.INVENTORY_EDIT]: 'إضافة/تعديل المخزون',
  [PERMISSIONS.SELL]: 'إجراء عمليات البيع',
  [PERMISSIONS.PURCHASE]: 'إجراء عمليات الشراء',
  [PERMISSIONS.CUSTOMERS_VIEW]: 'عرض العملاء',
  [PERMISSIONS.CUSTOMERS_EDIT]: 'إضافة/تعديل العملاء',
  [PERMISSIONS.DEBTS_VIEW]: 'عرض الديون',
  [PERMISSIONS.DEBTS_MANAGE]: 'تحصيل الديون',
  [PERMISSIONS.REPORTS_VIEW]: 'عرض التقارير',
  [PERMISSIONS.TEAM_MANAGE]: 'إدارة الفريق',
  [PERMISSIONS.TEAM_REPORT]: 'تقرير أعضاء الفريق',
  [PERMISSIONS.SETTINGS_MANAGE]: 'إدارة الإعدادات',
};

const TeamPage = {
  render: () => {
    const cloudStatus = (typeof CloudSync !== 'undefined') ? CloudSync.getStatus() : { enabled: false, lastSync: null };
    const lastSyncText = cloudStatus.lastSync
      ? new Date(cloudStatus.lastSync).toLocaleString('ar-EG', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })
      : 'لم تتم بعد';
    return `
      <div class="card">
        <div class="card-header">
          <h2>👨‍💼 إدارة الفريق</h2>
          <div style="display:flex;gap:0.5rem;flex-wrap:wrap;">
            <button class="btn btn-warning" id="showPasswordsBtn">🔐 عرض كلمات المرور</button>
            <button class="btn btn-info" id="syncUsersBtn">🔄 مزامنة بين الأجهزة</button>
            <button class="btn btn-success" id="addUserBtn">➕ إضافة عضو</button>
          </div>
        </div>
        <div class="card-body">
          <!-- حالة المزامنة السحابية -->
          <div style="background:linear-gradient(135deg, #dbeafe, #eff6ff);padding:0.85rem 1rem;border-radius:10px;margin-bottom:1rem;display:flex;align-items:center;gap:0.75rem;flex-wrap:wrap;">
            <div style="font-size:1.5rem;">☁️</div>
            <div style="flex:1;min-width:200px;">
              <div style="font-weight:700;color:#1e40af;">المزامنة السحابية للأعضاء</div>
              <div style="font-size:0.8rem;color:#475569;margin-top:0.15rem;">
                ${cloudStatus.enabled ? '✅ مفعّلة' : '⚪ غير مفعّلة (ستُنشأ عند أول إضافة/مزامنة)'} · آخر مزامنة: <b>${lastSyncText}</b>
              </div>
            </div>
            <button class="btn btn-primary" id="cloudSyncNowBtn" style="padding:0.4rem 0.8rem;font-size:0.85rem;">🔄 مزامنة الآن</button>
            <button class="btn btn-ghost" id="cloudResetBtn" style="padding:0.4rem 0.8rem;font-size:0.8rem;" title="إعادة تعيين الربط السحابي">🗑️</button>
          </div>
          <div class="table-wrap" id="usersTableWrap"></div>
        </div>
      </div>
    `;
  },

  renderTable: () => {
    const users = Users.all();
    const currentUser = Auth.require();

    if (users.length === 0) {
      return '<div class="empty-state"><div class="empty-icon">👥</div><p>لا يوجد أعضاء فريق</p></div>';
    }

    return `
      <table>
        <thead>
          <tr>
            <th>الاسم</th>
            <th>اسم المستخدم</th>
            <th>الدور</th>
            <th>الصلاحيات</th>
            <th>الحالة</th>
            <th>إجراءات</th>
          </tr>
        </thead>
        <tbody>
          ${users.map(u => {
            const perms = u.permissions || [];
            const isMe = u.id === currentUser.id;
            return `
              <tr>
                <td><strong>${escapeHtml(u.name)}</strong> ${isMe ? '<span class="badge badge-info">أنت</span>' : ''}</td>
                <td><code>${escapeHtml(u.username)}</code></td>
                <td>${ROLES[u.role]?.name || u.role}</td>
                <td>
                  ${perms.includes('*') ? '<span class="badge badge-success">كل الصلاحيات</span>' :
                    `<small>${perms.length} صلاحية</small>`}
                </td>
                <td>${u.disabled ? '<span class="badge badge-danger">معطّل</span>' : '<span class="badge badge-success">نشط</span>'}</td>
                <td class="actions-cell">
                  <button class="btn btn-sm btn-ghost" data-action="edit-user" data-id="${u.id}" title="تعديل">✏️</button>
                  <button class="btn btn-sm btn-ghost" data-action="reset-password" data-id="${u.id}" title="تغيير كلمة المرور">🔑</button>
                  <button class="btn btn-sm btn-ghost" data-action="view-password" data-id="${u.id}" title="عرض كلمة المرور">👁️</button>
                  ${!isMe ? `<button class="btn btn-sm btn-ghost" data-action="toggle-user" data-id="${u.id}" title="${u.disabled ? 'تفعيل' : 'تعطيل'}">${u.disabled ? '✅' : '⛔'}</button>` : ''}
                  ${!isMe ? `<button class="btn btn-sm btn-ghost" data-action="delete-user" data-id="${u.id}" title="حذف">🗑️</button>` : ''}
                </td>
              </tr>
            `;
          }).join('')}
        </tbody>
      </table>
    `;
  },

  form: (user = null) => {
    const u = user || { name: '', username: '', password: '', role: 'seller', permissions: [] };
    return `
      <form id="userForm">
        <div class="grid grid-2">
          <div class="form-group">
            <label>الاسم الكامل *</label>
            <input type="text" name="name" value="${escapeHtml(u.name)}" required />
          </div>
          <div class="form-group">
            <label>اسم المستخدم *</label>
            <input type="text" name="username" value="${escapeHtml(u.username)}" required ${user ? '' : 'autocomplete="off"'} />
          </div>
        </div>
        ${!user ? `
          <div class="form-group">
            <label>كلمة المرور *</label>
            <input type="password" name="password" required autocomplete="new-password" />
          </div>
        ` : `
          <div class="form-group">
            <label>كلمة المرور الجديدة (اتركها فارغة لعدم التغيير)</label>
            <input type="password" name="password" autocomplete="new-password" />
          </div>
        `}
        <div class="form-group">
          <label>الدور</label>
          <select name="role" id="userRoleSelect">
            ${Object.entries(ROLES).map(([key, role]) => `
              <option value="${key}" ${u.role === key ? 'selected' : ''}>${role.name}</option>
            `).join('')}
          </select>
          <small style="color:var(--text-muted);">الدور يحدد الصلاحيات الافتراضية (يمكن تخصيصها أدناه)</small>
        </div>
        <div class="form-group">
          <label>الصلاحيات المخصصة</label>
          <div class="perm-grid" id="permGrid">
            ${Object.entries(PERMISSION_LABELS).map(([perm, label]) => `
              <label class="perm-item ${u.permissions?.includes(perm) || u.permissions?.includes('*') ? 'checked' : ''}">
                <input type="checkbox" name="permissions" value="${perm}" ${u.permissions?.includes(perm) || u.permissions?.includes('*') ? 'checked' : ''} />
                <span>${label}</span>
              </label>
            `).join('')}
            <label class="perm-item ${u.permissions?.includes('*') ? 'checked' : ''}" style="background:var(--primary-light);">
              <input type="checkbox" name="permissions" value="*" ${u.permissions?.includes('*') ? 'checked' : ''} />
              <span><strong>كل الصلاحيات (أدمن)</strong></span>
            </label>
          </div>
        </div>
        <div class="modal-footer" style="padding-inline-start:0;">
          <button type="submit" class="btn btn-primary">${user ? 'حفظ التعديلات' : 'إضافة العضو'}</button>
          <button type="button" class="btn btn-ghost" data-close="genericModal">إلغاء</button>
        </div>
      </form>
    `;
  },

  handleSubmit: (e) => {
    e.preventDefault();
    const form = e.target;
    const fd = new FormData(form);
    const data = {
      name: fd.get('name').trim(),
      username: fd.get('username').trim(),
      role: fd.get('role'),
      permissions: fd.getAll('permissions'),
    };
    const password = fd.get('password');

    if (!data.name || !data.username) {
      toast('الاسم واسم المستخدم مطلوبان', 'error');
      return;
    }

    const isEdit = !!form.dataset.editId;
    if (!isEdit && !password) {
      toast('كلمة المرور مطلوبة للعضو الجديد', 'error');
      return;
    }

    if (isEdit) {
      const updates = { ...data };
      if (password) updates.password = password;
      Users.update(form.dataset.editId, updates);
      toast('تم تحديث العضو', 'success');
    } else {
      // التحقق من تكرار اسم المستخدم
      if (Users.findByUsername(data.username)) {
        toast('اسم المستخدم مستخدم بالفعل', 'error');
        return;
      }
      Users.add({ ...data, password });
      toast('تم إضافة العضو', 'success');
    }

    // مزامنة تلقائية مع السحابة
    if (typeof CloudSync !== 'undefined') {
      CloudSync.uploadUsers().then(res => {
        if (res.ok) {
          toast(`☁️ تمت مزامنة ${res.count} عضو للسحابة`, 'info', 2000);
        }
      });
    }

    closeModal('genericModal');
    TeamPage.refresh();
  },

  resetPassword: (user) => {
    const newPass = prompt(`أدخل كلمة المرور الجديدة لـ "${user.name}":`, '');
    if (newPass && newPass.length >= 3) {
      Users.update(user.id, { password: newPass });
      toast('تم تغيير كلمة المرور', 'success');
      // مزامنة تلقائية
      if (typeof CloudSync !== 'undefined') {
        CloudSync.uploadUsers();
      }
    }
  },

  bindEvents: () => {
    document.getElementById('showPasswordsBtn')?.addEventListener('click', () => {
      Enhancements.showPasswordsModal();
    });

    document.getElementById('addUserBtn')?.addEventListener('click', () => {
      openModal('إضافة عضو فريق', TeamPage.form());
      TeamPage._bindFormEvents();
    });

    document.getElementById('syncUsersBtn')?.addEventListener('click', () => {
      Sync.showSyncDialog();
    });

    // زر المزامنة السحابية
    document.getElementById('cloudSyncNowBtn')?.addEventListener('click', async () => {
      const btn = document.getElementById('cloudSyncNowBtn');
      const originalText = btn.textContent;
      btn.textContent = '⏳ جاري...';
      btn.disabled = true;
      try {
        const result = await CloudSync.fullSync();
        if (result.upload.ok || result.download.ok) {
          const upCount = result.upload.count || 0;
          const downCount = result.download.count || 0;
          const downAdded = result.download.added || 0;
          toast(`☁️ تمت المزامنة: رفع ${upCount}، تحميل ${downCount} (${downAdded} جديد)`, 'success', 3500);
          TeamPage.refresh();
        } else {
          toast(`⚠️ فشل: ${result.upload.error || result.download.error}`, 'error');
        }
      } catch (e) {
        toast('⚠️ فشل الاتصال بالسحابة', 'error');
      } finally {
        btn.textContent = originalText;
        btn.disabled = false;
      }
    });

    // زر إعادة تعيين المزامنة السحابية
    document.getElementById('cloudResetBtn')?.addEventListener('click', () => {
      if (confirm('⚠️ هل تريد إعادة تعيين الربط السحابي؟\n(سيتم إنشاء رابط جديد عند المزامنة التالية)')) {
        CloudSync.reset();
        toast('✅ تم إعادة التعيين', 'success');
        TeamPage.refresh();
      }
    });

    document.getElementById('usersTableWrap')?.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-action]');
      if (!btn) return;
      const action = btn.dataset.action;
      const id = btn.dataset.id;
      const user = Users.find(id);
      if (!user) return;

      if (action === 'edit-user') {
        openModal('تعديل العضو', TeamPage.form(user));
        const form = document.getElementById('userForm');
        form.dataset.editId = id;
        TeamPage._bindFormEvents();
      } else if (action === 'reset-password') {
        TeamPage.resetPassword(user);
      } else if (action === 'view-password') {
        // عرض كلمة المرور في نافذة منبثقة
        const content = `
          <div style="text-align:center;padding:1rem;">
            <p style="color:var(--text-muted);margin-bottom:1rem;">كلمة المرور لـ <strong>${escapeHtml(user.name)}</strong>:</p>
            <div style="background:var(--bg);padding:1rem;border-radius:8px;display:flex;align-items:center;justify-content:center;gap:0.5rem;">
              <code style="font-size:1.5rem;letter-spacing:2px;color:var(--primary);">${escapeHtml(user.password || '')}</code>
              <button class="btn btn-sm btn-ghost" id="copyPassInline" data-pass="${escapeHtml(user.password || '')}">📋 نسخ</button>
            </div>
          </div>
          <div style="margin-top:1rem;text-align:left;">
            <button class="btn btn-ghost" data-close="genericModal">إغلاق</button>
          </div>
        `;
        openModal('🔐 كلمة المرور', content);
        document.getElementById('copyPassInline')?.addEventListener('click', (e) => {
          const pass = e.currentTarget.dataset.pass;
          navigator.clipboard.writeText(pass).then(() => {
            toast('✅ تم نسخ كلمة المرور', 'success');
          });
        });
      } else if (action === 'toggle-user') {
        Users.update(id, { disabled: !user.disabled });
        toast(user.disabled ? 'تم تفعيل الحساب' : 'تم تعطيل الحساب', 'success');
        TeamPage.refresh();
        // مزامنة تلقائية
        if (typeof CloudSync !== 'undefined') {
          CloudSync.uploadUsers();
        }
      } else if (action === 'delete-user') {
        if (confirm(`حذف العضو "${user.name}"؟`)) {
          Users.remove(id);
          toast('تم الحذف', 'success');
          TeamPage.refresh();
          // مزامنة تلقائية
          if (typeof CloudSync !== 'undefined') {
            CloudSync.uploadUsers();
          }
        }
      }
    });
  },

  _bindFormEvents: () => {
    const form = document.getElementById('userForm');
    if (!form) return;
    form.addEventListener('submit', TeamPage.handleSubmit);

    // تحديث المظهر عند تغيير الصلاحيات
    form.querySelectorAll('input[name="permissions"]').forEach(cb => {
      cb.addEventListener('change', () => {
        const item = cb.closest('.perm-item');
        if (item) item.classList.toggle('checked', cb.checked);

        // إذا تم اختيار "كل الصلاحيات"، عطّل الباقي
        if (cb.value === '*' && cb.checked) {
          form.querySelectorAll('input[name="permissions"]').forEach(other => {
            if (other.value !== '*') {
              other.checked = false;
              other.closest('.perm-item').classList.remove('checked');
            }
          });
        } else if (cb.value !== '*' && cb.checked) {
          // إذا تم اختيار صلاحية محددة، ألغِ "*"
          const allCb = form.querySelector('input[value="*"]');
          if (allCb && allCb.checked) {
            allCb.checked = false;
            allCb.closest('.perm-item').classList.remove('checked');
          }
        }
      });
    });

    // تطبيق صلاحيات الدور تلقائياً
    const roleSelect = document.getElementById('userRoleSelect');
    roleSelect?.addEventListener('change', () => {
      const role = ROLES[roleSelect.value];
      if (!role) return;
      const perms = role.permissions;
      form.querySelectorAll('input[name="permissions"]').forEach(cb => {
        const checked = perms.includes(cb.value);
        cb.checked = checked;
        cb.closest('.perm-item').classList.toggle('checked', checked);
      });
    });
  },

  refresh: () => {
    const wrap = document.getElementById('usersTableWrap');
    if (wrap) wrap.innerHTML = TeamPage.renderTable();
  },
};
