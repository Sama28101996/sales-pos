// =====================================================
// PWA - تثبيت التطبيق + Service Worker
// =====================================================

const PWA = {
  deferredPrompt: null,
  swRegistered: false,

  // ===== تسجيل Service Worker =====
  registerSW: () => {
    if (!('serviceWorker' in navigator)) {
      console.warn('[PWA] Service Workers not supported');
      return;
    }
    if (PWA.swRegistered) return;

    window.addEventListener('load', () => {
      navigator.serviceWorker.register('./sw.js')
        .then((reg) => {
          console.log('[PWA] Service Worker registered:', reg.scope);
          PWA.swRegistered = true;

          // التحقق من التحديثات
          reg.addEventListener('updatefound', () => {
            const newWorker = reg.installing;
            console.log('[PWA] Update found, installing new version...');
            newWorker.addEventListener('statechange', () => {
              if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                PWA.showUpdateNotification();
              }
            });
          });
        })
        .catch((err) => {
          console.error('[PWA] SW registration failed:', err);
        });
    });
  },

  // ===== حدث التثبيت =====
  initInstallPrompt: () => {
    // تعطيل زر التثبيت - نمنع المتصفح من عرضه ولا ننشئ زر داخلي
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      PWA.deferredPrompt = e;
      // لا نستدعي showInstallButton - الزر معطل بطلب المستخدم
    });

    // عند نجاح التثبيت
    window.addEventListener('appinstalled', () => {
      console.log('[PWA] App installed successfully');
      PWA.deferredPrompt = null;
      PWA.hideInstallButton();
    });
  },

  // ===== عرض زر التثبيت (معطل) =====
  showInstallButton: () => {
    // الزر معطل بطلب المستخدم
    return;
  },

  hideInstallButton: () => {
    const btn = document.getElementById('pwaInstallBtn');
    if (btn) btn.remove();
  },

  // ===== تنفيذ التثبيت =====
  install: async () => {
    if (!PWA.deferredPrompt) {
      toast('التثبيت غير متاح حالياً. جرّب من متصفح Chrome أو Edge', 'info', 3500);
      return;
    }
    PWA.deferredPrompt.prompt();
    const { outcome } = await PWA.deferredPrompt.userChoice;
    console.log('[PWA] User choice:', outcome);
    if (outcome === 'accepted') {
      toast('جاري التثبيت...', 'info', 2000);
    } else {
      toast('يمكنك التثبيت لاحقاً من إعدادات المتصفح', 'info', 3000);
    }
    PWA.deferredPrompt = null;
  },

  // ===== إشعار التحديث =====
  showUpdateNotification: () => {
    const content = `
      <div style="text-align:center;">
        <div style="font-size:3rem;">🔄</div>
        <h3>يتوفر تحديث جديد</h3>
        <p style="color:var(--text-muted);margin:0.5rem 0;">نسخة جديدة من التطبيق جاهزة. هل تريد التحديث الآن؟</p>
        <div style="display:flex;gap:0.5rem;justify-content:center;margin-top:1rem;flex-wrap:wrap;">
          <button class="btn btn-primary" id="updateNowBtn">🔄 تحديث الآن</button>
          <button class="btn btn-ghost" id="updateLaterBtn">لاحقاً</button>
        </div>
      </div>
    `;
    openModal('تحديث التطبيق', content);
    document.getElementById('updateNowBtn').addEventListener('click', () => {
      navigator.serviceWorker.getRegistration().then((reg) => {
        if (reg && reg.waiting) {
          reg.waiting.postMessage({ type: 'SKIP_WAITING' });
        }
        location.reload();
      });
    });
    document.getElementById('updateLaterBtn').addEventListener('click', () => {
      closeModal('genericModal');
    });
  },

  // ===== التحقق هل التطبيق مثبت =====
  isInstalled: () => {
    return window.matchMedia('(display-mode: standalone)').matches
      || window.navigator.standalone === true
      || document.referrer.includes('android-app://');
  },

  // ===== تهيئة عامة =====
  init: () => {
    PWA.registerSW();
    PWA.initInstallPrompt();

    // إزالة أي زر تثبيت موجود (في حال تم تحميل الصفحة قبل التعطيل)
    setTimeout(() => PWA.hideInstallButton(), 100);
  },
};

// تشغيل تلقائي
PWA.init();
