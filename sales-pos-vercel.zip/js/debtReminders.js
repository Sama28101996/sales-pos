// =====================================================
// نظام تذكير الديون
// - تنبيهات داخلية (داخل التطبيق)
// - رسائل WhatsApp مباشرة
// - رسائل SMS
// - قوالب جاهزة بالعربي
// - تذكير مجدول (يومي/أسبوعي)
// =====================================================

const DebtReminders = {
  // ===== قوالب الرسائل الجاهزة =====
  templates: {
    gentle: {
      label: 'لطيف',
      icon: '😊',
      text: 'مرحباً {name}،\nنودّ تذكيركم بلطف بأن لديكم ديناً بمبلغ {amount} على متجرنا.\nنسعد باستلام المبلغ في أقرب وقت.\nشكراً لكم 🌸',
    },
    formal: {
      label: 'رسمي',
      icon: '📋',
      text: 'السيد/ة {name} المحترم/ة،\n\nنذكركم بأن لديكم رصيد دين مستحق بقيمة {amount}.\nنرجو التكرم بالسداد في أقرب وقت ممكن.\n\nمع خالص التقدير،\nإدارة المتجر',
    },
    urgent: {
      label: 'عاجل',
      icon: '⚠️',
      text: 'تنبيه عاجل: السيد/ة {name}، لديكم دين متأخر بمبلغ {amount}.\nيرجى المبادرة بالسداد خلال 48 ساعة.\nفي حال السداد أو الاستفسار، يرجى التواصل معنا.',
    },
    friendly: {
      label: 'ودي',
      icon: '💚',
      text: 'أهلاً {name}! 👋\nبس نذكّرك إن عندك دين {amount} من آخر مرة.\nلا تتأخر علينا 😉\nنشكرك!',
    },
    custom: {
      label: 'مخصص',
      icon: '✏️',
      text: '',
    },
  },

  // ===== تطبيق المتغيرات على القالب =====
  fillTemplate: (template, customer, amount, storeName) => {
    return template
      .replace(/{name}/g, customer.name || 'عزيزي العميل')
      .replace(/{amount}/g, `${Number(amount).toFixed(2)} $`)
      .replace(/{phone}/g, customer.phone || '')
      .replace(/{store}/g, storeName || 'متجرنا');
  },

  // ===== تنسيق رقم الهاتف لـ WhatsApp =====
  formatPhoneForWhatsApp: (phone) => {
    if (!phone) return null;
    // إزالة كل ما عدا الأرقام والـ +
    let cleaned = String(phone).replace(/[^\d+]/g, '');
    // إذا يبدأ بـ 0، استبدله بكود العراق 964
    if (cleaned.startsWith('0')) {
      cleaned = '964' + cleaned.substring(1);
    }
    // إذا لا يبدأ بـ + ولا كود، أضف +
    if (!cleaned.startsWith('+')) {
      cleaned = '+' + cleaned;
    }
    return cleaned.replace('+', ''); // واتساب يستخدم بدون +
  },

  // ===== إرسال عبر WhatsApp =====
  sendWhatsApp: (customer, amount, message) => {
    if (!customer.phone) {
      toast('❌ العميل ليس لديه رقم هاتف', 'error');
      return false;
    }
    const phone = DebtReminders.formatPhoneForWhatsApp(customer.phone);
    const encoded = encodeURIComponent(message);
    const url = `https://wa.me/${phone}?text=${encoded}`;
    window.open(url, '_blank');
    return true;
  },

  // ===== إرسال عبر SMS =====
  sendSMS: (customer, amount, message) => {
    if (!customer.phone) {
      toast('❌ العميل ليس لديه رقم هاتف', 'error');
      return false;
    }
    const phone = customer.phone.replace(/[^\d+]/g, '');
    const encoded = encodeURIComponent(message);
    const url = `sms:${phone}?body=${encoded}`;
    window.open(url, '_self');
    return true;
  },

  // ===== حفظ سجل التذكير =====
  logReminder: (customer, amount, channel, template) => {
    const logs = JSON.parse(localStorage.getItem('debt_reminders_log') || '[]');
    logs.unshift({
      id: Date.now().toString(),
      customerId: customer.id,
      customerName: customer.name,
      customerPhone: customer.phone,
      amount,
      channel,
      template: template.label,
      sentAt: new Date().toISOString(),
      sentBy: Auth.require()?.id,
    });
    // حفظ آخر 100 سجل فقط
    localStorage.setItem('debt_reminders_log', JSON.stringify(logs.slice(0, 100)));
  },

  getLog: () => {
    return JSON.parse(localStorage.getItem('debt_reminders_log') || '[]');
  },

  // ===== نافذة التذكير =====
  showReminderDialog: (customer) => {
    const settings = Settings.get();
    const amount = customer.totalDebt || 0;
    const storeName = settings.storeName || 'متجرنا';

    // تعبئة القوالب
    const templateOptions = Object.keys(DebtReminders.templates)
      .map(k => {
        const t = DebtReminders.templates[k];
        return `<option value="${k}">${t.icon} ${t.label}</option>`;
      }).join('');

    const content = `
      <div style="margin-bottom:1rem;padding:1rem;background:var(--danger-light);border-radius:8px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:0.5rem;">
        <div>
          <div style="font-weight:700;color:var(--danger);">👤 ${escapeHtml(customer.name)}</div>
          <div style="font-size:0.85rem;color:var(--text-muted);">${customer.phone || 'بدون رقم'}</div>
        </div>
        <div style="text-align:end;">
          <div style="font-size:0.85rem;color:var(--text-muted);">المبلغ المستحق</div>
          <div style="font-size:1.3rem;font-weight:700;color:var(--danger);">${amount.toFixed(2)} $</div>
        </div>
      </div>

      <div class="form-group">
        <label>📝 نوع الرسالة</label>
        <select id="reminderTemplate" style="font-size:1rem;">
          ${templateOptions}
        </select>
      </div>

      <div class="form-group">
        <label>💬 نص الرسالة</label>
        <textarea id="reminderText" rows="6" style="width:100%;font-family:inherit;font-size:0.95rem;line-height:1.6;direction:rtl;"></textarea>
        <small style="color:var(--text-muted);">يمكنك تعديل النص قبل الإرسال</small>
      </div>

      <div style="background:#f1f5f9;padding:0.75rem;border-radius:8px;font-size:0.85rem;color:var(--text-muted);">
        💡 <b>ملاحظة:</b> عند اختيار WhatsApp، سيفتح واتساب ويب مع الرسالة جاهزة. فقط اضغط إرسال من هناك.
      </div>

      <div class="modal-footer" style="padding-inline-start:0;display:flex;gap:0.5rem;flex-wrap:wrap;">
        <button class="btn btn-success" id="sendWhatsAppBtn" style="flex:1;min-width:140px;">📱 WhatsApp</button>
        <button class="btn btn-primary" id="sendSmsBtn" style="flex:1;min-width:140px;">💬 SMS</button>
        <button class="btn btn-ghost" data-close="genericModal">إلغاء</button>
      </div>
    `;

    openModal('📅 تذكير بدفع الدين', content, { large: true });

    const templateSelect = document.getElementById('reminderTemplate');
    const textArea = document.getElementById('reminderText');

    const updateText = () => {
      const key = templateSelect.value;
      const tpl = DebtReminders.templates[key];
      if (key === 'custom') {
        textArea.value = '';
        textArea.placeholder = 'اكتب رسالتك الخاصة هنا...';
        textArea.focus();
      } else {
        textArea.value = DebtReminders.fillTemplate(tpl.text, customer, amount, storeName);
      }
    };

    templateSelect.addEventListener('change', updateText);
    updateText();

    document.getElementById('sendWhatsAppBtn').addEventListener('click', () => {
      const tpl = DebtReminders.templates[templateSelect.value];
      const success = DebtReminders.sendWhatsApp(customer, amount, textArea.value);
      if (success) {
        DebtReminders.logReminder(customer, amount, 'whatsapp', tpl);
        toast('✅ تم فتح WhatsApp — اضغط إرسال هناك', 'success', 3000);
        setTimeout(() => closeModal('genericModal'), 1500);
      }
    });

    document.getElementById('sendSmsBtn').addEventListener('click', () => {
      const tpl = DebtReminders.templates[templateSelect.value];
      const success = DebtReminders.sendSMS(customer, amount, textArea.value);
      if (success) {
        DebtReminders.logReminder(customer, amount, 'sms', tpl);
        toast('✅ تم فتح تطبيق الرسائل', 'success', 2000);
        setTimeout(() => closeModal('genericModal'), 1500);
      }
    });
  },

  // ===== صفحة التذكيرات =====
  renderPage: () => {
    const customers = Customers.all().filter(c => (c.totalDebt || 0) > 0);
    customers.sort((a, b) => b.totalDebt - a.totalDebt);

    const totalDebt = customers.reduce((s, c) => s + (c.totalDebt || 0), 0);
    const log = DebtReminders.getLog();
    const recentLog = log.slice(0, 10);

    return `
      <div class="card">
        <div class="card-header">
          <h2>📅 تذكير الديون</h2>
        </div>
        <div class="card-body">
          <div class="stats-grid" style="margin-bottom:1.5rem;">
            <div class="stat-card danger">
              <div class="stat-icon">⚠️</div>
              <div class="stat-label">عملاء مديونون</div>
              <div class="stat-value">${customers.length}</div>
            </div>
            <div class="stat-card warning">
              <div class="stat-icon">💰</div>
              <div class="stat-label">إجمالي الديون</div>
              <div class="stat-value">${totalDebt.toFixed(2)} $</div>
            </div>
            <div class="stat-card">
              <div class="stat-icon">📤</div>
              <div class="stat-label">تذكيرات مرسلة</div>
              <div class="stat-value">${log.length}</div>
            </div>
          </div>

          <div class="card" style="background:var(--bg);margin-bottom:1.5rem;">
            <div class="card-header">
              <h3>📋 العملاء المديونون (${customers.length})</h3>
            </div>
            <div class="card-body">
              ${customers.length === 0
                ? '<p style="text-align:center;color:var(--text-muted);padding:2rem;">🎉 لا توجد ديون حالياً!</p>'
                : `<div style="display:grid;gap:0.5rem;">
                    ${customers.map(c => `
                      <div style="display:flex;align-items:center;justify-content:space-between;padding:1rem;background:#fff;border:1px solid var(--border);border-radius:10px;flex-wrap:wrap;gap:0.5rem;${(c.totalDebt > 100) ? 'border-inline-start:4px solid var(--danger);' : ''}">
                        <div style="flex:1;min-width:200px;">
                          <div style="font-weight:700;font-size:1.05rem;">${escapeHtml(c.name)}</div>
                          <div style="font-size:0.85rem;color:var(--text-muted);">
                            📞 ${escapeHtml(c.phone || 'لا يوجد')} ${c.address ? ' • ' + escapeHtml(c.address) : ''}
                          </div>
                          ${c.lastReminder ? `<div style="font-size:0.75rem;color:var(--text-muted);margin-top:0.2rem;">⏰ آخر تذكير: ${new Date(c.lastReminder).toLocaleString('ar-EG')}</div>` : ''}
                        </div>
                        <div style="text-align:end;">
                          <div style="font-size:1.4rem;font-weight:700;color:var(--danger);">${(c.totalDebt || 0).toFixed(2)} $</div>
                          <button class="btn btn-sm btn-success" data-remind="${c.id}" ${!c.phone ? 'disabled style="opacity:0.5;"' : ''}>📅 تذكير</button>
                        </div>
                      </div>
                    `).join('')}
                  </div>`
              }
            </div>
          </div>

          <div class="card" style="background:var(--bg);">
            <div class="card-header">
              <h3>📜 سجل التذكيرات (آخر ${recentLog.length})</h3>
              ${log.length > 0 ? '<button class="btn btn-sm btn-ghost" id="clearLogBtn">🗑️ مسح السجل</button>' : ''}
            </div>
            <div class="card-body">
              ${recentLog.length === 0
                ? '<p style="text-align:center;color:var(--text-muted);">لم يتم إرسال أي تذكير بعد</p>'
                : `<div style="display:grid;gap:0.5rem;">
                    ${recentLog.map(l => `
                      <div style="display:flex;align-items:center;justify-content:space-between;padding:0.6rem 0.8rem;background:#fff;border:1px solid var(--border);border-radius:6px;flex-wrap:wrap;gap:0.5rem;">
                        <div>
                          <div style="font-weight:600;">${escapeHtml(l.customerName)}</div>
                          <div style="font-size:0.8rem;color:var(--text-muted);">
                            ${l.channel === 'whatsapp' ? '📱 WhatsApp' : '💬 SMS'} • د.ع{l.template}
                          </div>
                        </div>
                        <div style="text-align:end;">
                          <div style="font-weight:700;color:var(--danger);">${Number(l.amount).toFixed(2)} $</div>
                          <div style="font-size:0.75rem;color:var(--text-muted);">${new Date(l.sentAt).toLocaleString('ar-EG')}</div>
                        </div>
                      </div>
                    `).join('')}
                  </div>`
              }
            </div>
          </div>
        </div>
      </div>
    `;
  },

  bindEvents: () => {
    document.querySelectorAll('[data-remind]').forEach(btn => {
      btn.addEventListener('click', () => {
        const customer = Customers.find(btn.dataset.remind);
        if (customer) {
          // تحديث آخر تذكير
          customer.lastReminder = new Date().toISOString();
          Customers.update(customer.id, customer);
          DebtReminders.showReminderDialog(customer);
        }
      });
    });

    document.getElementById('clearLogBtn')?.addEventListener('click', () => {
      if (confirm('مسح كل سجل التذكيرات؟')) {
        localStorage.removeItem('debt_reminders_log');
        toast('تم مسح السجل', 'success');
        DebtReminders.refresh();
      }
    });
  },

  refresh: () => {
    const container = document.getElementById('pageContainer');
    container.innerHTML = DebtReminders.renderPage();
    DebtReminders.bindEvents();
  },
};
