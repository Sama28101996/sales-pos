// =====================================================
// Google Drive Backup System
// - تسجيل دخول بحساب Google
// - نسخ احتياطي تلقائي يومي
// - نسخ احتياطي يدوي
// - استعادة من Drive
// - قائمة النسخ السابقة
// =====================================================

const Backup = {
  CLIENT_ID: '', // يُملأ من الإعدادات
  DISCOVERY_DOC: 'https://www.googleapis.com/discovery/v1/apis/drive/v3/rest',
  SCOPES: 'https://www.googleapis.com/auth/drive.file',
  FOLDER_NAME: 'نظام_إدارة_المبيعات_نسخ_احتياطية',
  tokenClient: null,
  accessToken: null,
  initialized: false,

  // ===== تهيئة المكتبة =====
  init: async () => {
    if (Backup.initialized) return true;

    // تحميل مكتبات Google
    if (typeof gapi === 'undefined') {
      await Backup._loadScript('https://apis.google.com/js/api.js');
    }
    if (typeof google === 'undefined' || !google.accounts) {
      await Backup._loadScript('https://accounts.google.com/gsi/client');
    }

    // تهيئة gapi
    await new Promise((resolve, reject) => {
      gapi.load('client', async () => {
        try {
          await gapi.client.init({
            discoveryDocs: [Backup.DISCOVERY_DOC],
          });
          resolve();
        } catch (e) {
          reject(e);
        }
      });
    });

    Backup.initialized = true;
    return true;
  },

  _loadScript: (src) => {
    return new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = src;
      s.async = true;
      s.defer = true;
      s.onload = resolve;
      s.onerror = reject;
      document.head.appendChild(s);
    });
  },

  // ===== التحقق هل في اتصال سابق =====
  hasStoredSession: () => {
    const saved = localStorage.getItem('gdrive_session');
    if (!saved) return false;
    try {
      const data = JSON.parse(saved);
      // الجلسة تنتهي بعد ساعة
      if (Date.now() - data.savedAt > 3500 * 1000) {
        localStorage.removeItem('gdrive_session');
        return false;
      }
      return true;
    } catch (e) {
      return false;
    }
  },

  getStoredSession: () => {
    try {
      return JSON.parse(localStorage.getItem('gdrive_session') || 'null');
    } catch (e) {
      return null;
    }
  },

  // ===== تسجيل الدخول =====
  signIn: async (clientId) => {
    if (!clientId) {
      toast('يرجى إدخال Google Client ID من الإعدادات أولاً', 'error', 4000);
      Backup._showSettingsModal();
      return false;
    }
    Backup.CLIENT_ID = clientId;
    localStorage.setItem('gdrive_client_id', clientId);

    try {
      await Backup.init();

      return new Promise((resolve, reject) => {
        Backup.tokenClient = google.accounts.oauth2.initTokenClient({
          client_id: Backup.CLIENT_ID,
          scope: Backup.SCOPES,
          callback: (response) => {
            if (response.error) {
              toast('فشل تسجيل الدخول: ' + response.error, 'error');
              reject(response);
              return;
            }
            Backup.accessToken = response.access_token;
            localStorage.setItem('gdrive_session', JSON.stringify({
              token: response.access_token,
              savedAt: Date.now(),
              clientId: Backup.CLIENT_ID,
            }));
            gapi.client.setToken({ access_token: response.access_token });
            toast('تم الربط بـ Google Drive بنجاح ✅', 'success');
            Backup._scheduleAutoBackup();
            resolve(true);
          },
        });
        Backup.tokenClient.requestAccessToken({ prompt: 'consent' });
      });
    } catch (e) {
      console.error('Sign-in error:', e);
      toast('خطأ في تسجيل الدخول: ' + (e.message || e), 'error', 4000);
      return false;
    }
  },

  signOut: () => {
    if (Backup.accessToken) {
      google.accounts.oauth2.revoke(Backup.accessToken, () => {});
    }
    Backup.accessToken = null;
    localStorage.removeItem('gdrive_session');
    gapi.client.setToken(null);
    toast('تم قطع الاتصال بـ Google Drive', 'info');
  },

  isConnected: () => {
    return Backup.hasStoredSession();
  },

  // ===== أخذ نسخة احتياطية كاملة =====
  createBackup: async (silent = false) => {
    if (!Backup.hasStoredSession()) {
      if (!silent) toast('يجب الربط بـ Google Drive أولاً', 'warning');
      return null;
    }

    try {
      // استرجاع التوكن إذا انتهت صلاحيته
      const session = Backup.getStoredSession();
      if (!session || !Backup.accessToken) {
        Backup.accessToken = session.token;
        if (typeof gapi !== 'undefined' && gapi.client) {
          gapi.client.setToken({ access_token: session.token });
        }
      }

      const data = Backup._collectData();
      const json = JSON.stringify(data, null, 2);
      const blob = new Blob([json], { type: 'application/json' });
      const filename = `sales_backup_${Backup._timestampForFile()}.json`;

      // إيجاد أو إنشاء المجلد
      const folderId = await Backup._getOrCreateFolder();

      // رفع الملف
      const metadata = {
        name: filename,
        mimeType: 'application/json',
        parents: [folderId],
        description: `نسخة احتياطية - ${new Date().toLocaleString('ar-EG')} - ${data.stats.totalProducts} منتج، ${data.stats.totalSales} فاتورة`,
      };

      const form = new FormData();
      form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
      form.append('file', blob);

      const response = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,createdTime,size', {
        method: 'POST',
        headers: new Headers({ Authorization: 'Bearer ' + Backup.accessToken }),
        body: form,
      });

      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.error?.message || 'فشل الرفع');
      }

      const result = await response.json();
      localStorage.setItem('last_backup_time', new Date().toISOString());

      if (!silent) toast(`✅ تم حفظ النسخة: ${result.name}`, 'success', 3000);
      return result;

    } catch (e) {
      console.error('Backup error:', e);
      if (e.message && e.message.includes('invalid_token')) {
        localStorage.removeItem('gdrive_session');
        toast('انتهت الجلسة، أعد الربط بـ Google Drive', 'warning', 4000);
      } else {
        if (!silent) toast('فشل النسخ الاحتياطي: ' + (e.message || e), 'error', 4000);
      }
      return null;
    }
  },

  // ===== جلب قائمة النسخ من Drive =====
  listBackups: async () => {
    if (!Backup.hasStoredSession()) return [];

    const session = Backup.getStoredSession();
    if (!Backup.accessToken) {
      Backup.accessToken = session.token;
      if (typeof gapi !== 'undefined' && gapi.client) {
        gapi.client.setToken({ access_token: session.token });
      }
    }

    try {
      const folderId = await Backup._getOrCreateFolder();
      const response = await fetch(
        `https://www.googleapis.com/drive/v3/files?q='${folderId}'+in+parents+and+mimeType='application/json'+and+trashed=false&orderBy=createdTime+desc&pageSize=30&fields=files(id,name,createdTime,size,description)`,
        { headers: { Authorization: 'Bearer ' + Backup.accessToken } }
      );

      if (!response.ok) throw new Error('فشل جلب القائمة');
      const data = await response.json();
      return data.files || [];
    } catch (e) {
      console.error('List error:', e);
      toast('فشل جلب قائمة النسخ: ' + (e.message || e), 'error');
      return [];
    }
  },

  // ===== تنزيل نسخة من Drive =====
  downloadBackup: async (fileId) => {
    if (!Backup.accessToken) {
      const session = Backup.getStoredSession();
      Backup.accessToken = session.token;
    }
    try {
      const response = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`, {
        headers: { Authorization: 'Bearer ' + Backup.accessToken },
      });
      if (!response.ok) throw new Error('فشل التنزيل');
      return await response.json();
    } catch (e) {
      console.error('Download error:', e);
      toast('فشل تنزيل النسخة: ' + (e.message || e), 'error');
      return null;
    }
  },

  // ===== استعادة نسخة =====
  restoreBackup: async (fileId) => {
    if (!confirm('⚠️ استعادة النسخة ستستبدل كل البيانات الحالية. هل أنت متأكد؟')) {
      return false;
    }
    const data = await Backup.downloadBackup(fileId);
    if (!data) return false;

    try {
      // تطبيق البيانات
      if (data.products) DB.set('products', data.products);
      if (data.sales) DB.set('sales', data.sales);
      if (data.purchases) DB.set('purchases', data.purchases);
      if (data.customers) DB.set('customers', data.customers);
      if (data.users) DB.set('users', data.users);
      if (data.debts) DB.set('debts', data.debts);
      if (data.settings) DB.set('settings', data.settings);

      toast('✅ تمت الاستعادة بنجاح - سيتم تحديث الصفحة', 'success', 2500);
      setTimeout(() => location.reload(), 2000);
      return true;
    } catch (e) {
      toast('فشل تطبيق النسخة: ' + (e.message || e), 'error');
      return false;
    }
  },

  // ===== تنزيل محلي (بدون Drive) =====
  downloadLocal: () => {
    const data = Backup._collectData();
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sales_backup_${Backup._timestampForFile()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast('✅ تم تنزيل النسخة على جهازك', 'success');
  },

  // ===== استعادة من ملف محلي =====
  restoreLocal: () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'application/json,.json';
    input.onchange = async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      if (!confirm('⚠️ استعادة النسخة ستستبدل كل البيانات الحالية. هل أنت متأكد؟')) return;

      try {
        const text = await file.text();
        const data = JSON.parse(text);
        if (data.products) DB.set('products', data.products);
        if (data.sales) DB.set('sales', data.sales);
        if (data.purchases) DB.set('purchases', data.purchases);
        if (data.customers) DB.set('customers', data.customers);
        if (data.users) DB.set('users', data.users);
        if (data.debts) DB.set('debts', data.debts);
        if (data.settings) DB.set('settings', data.settings);

        toast('✅ تمت الاستعادة بنجاح', 'success');
        setTimeout(() => location.reload(), 1500);
      } catch (err) {
        toast('ملف غير صالح: ' + err.message, 'error');
      }
    };
    input.click();
  },

  // ===== نسخ احتياطي تلقائي يومي =====
  _scheduleAutoBackup: () => {
    // إلغاء أي مؤقت سابق
    if (Backup._autoTimer) clearTimeout(Backup._autoTimer);

    const lastBackup = localStorage.getItem('last_backup_time');
    const now = Date.now();
    const oneDayMs = 24 * 60 * 60 * 1000;

    let nextDelay;
    if (lastBackup) {
      const elapsed = now - new Date(lastBackup).getTime();
      nextDelay = Math.max(60 * 1000, oneDayMs - elapsed); // دقيقة كحد أدنى
    } else {
      nextDelay = 30 * 1000; // أول مرة بعد 30 ثانية من الربط
    }

    Backup._autoTimer = setTimeout(async () => {
      const result = await Backup.createBackup(true);
      if (result) {
        toast('☁️ تم النسخ الاحتياطي اليومي التلقائي', 'info', 3000);
      }
      Backup._scheduleAutoBackup();
    }, nextDelay);

    console.log(`[Backup] Auto backup scheduled in ${Math.round(nextDelay / 60000)} min`);
  },

  // ===== أدوات داخلية =====
  _collectData: () => {
    return {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      products: DB.get('products') || [],
      sales: DB.get('sales') || [],
      purchases: DB.get('purchases') || [],
      customers: DB.get('customers') || [],
      users: DB.get('users') || [],
      debts: DB.get('debts') || [],
      settings: DB.get('settings') || {},
      stats: {
        totalProducts: (DB.get('products') || []).length,
        totalSales: (DB.get('sales') || []).length,
        totalCustomers: (DB.get('customers') || []).length,
      },
    };
  },

  _getOrCreateFolder: async () => {
    // بحث عن المجلد
    const query = `name='${Backup.FOLDER_NAME}'+and+mimeType='application/vnd.google-apps.folder'+and+trashed=false`;
    const search = await fetch(
      `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(query)}&fields=files(id,name)`,
      { headers: { Authorization: 'Bearer ' + Backup.accessToken } }
    );
    const searchData = await search.json();
    if (searchData.files && searchData.files.length > 0) {
      return searchData.files[0].id;
    }

    // إنشاء المجلد
    const create = await fetch('https://www.googleapis.com/drive/v3/files?fields=id', {
      method: 'POST',
      headers: {
        Authorization: 'Bearer ' + Backup.accessToken,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: Backup.FOLDER_NAME,
        mimeType: 'application/vnd.google-apps.folder',
      }),
    });
    const createData = await create.json();
    return createData.id;
  },

  _timestampForFile: () => {
    const d = new Date();
    const pad = (n) => String(n).padStart(2, '0');
    return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}`;
  },

  _showSettingsModal: () => {
    const currentId = localStorage.getItem('gdrive_client_id') || '';
    const content = `
      <div style="margin-bottom:1rem;padding:1rem;background:var(--primary-light);border-radius:8px;">
        <h3 style="margin:0 0 0.5rem;color:var(--primary-dark);">📘 إعداد Google Cloud Console</h3>
        <ol style="margin:0;padding-inline-start:1.2rem;line-height:1.9;">
          <li>اذهب إلى <a href="https://console.cloud.google.com" target="_blank">console.cloud.google.com</a></li>
          <li>أنشئ مشروع جديد (أو اختر موجود)</li>
          <li>فعّل <b>Google Drive API</b></li>
          <li>أنشئ <b>OAuth 2.0 Client ID</b> من نوع <b>Web application</b></li>
          <li>أضف هذا الرابط كـ <b>Authorized JavaScript origin</b>:
            <br><code style="background:#fff;padding:0.2rem 0.4rem;border-radius:4px;display:inline-block;margin-top:0.3rem;">${location.origin}</code>
          </li>
          <li>انسخ <b>Client ID</b> والصقه هنا</li>
        </ol>
      </div>
      <div class="form-group">
        <label>Google OAuth Client ID</label>
        <input type="text" id="gdriveClientId" value="${escapeHtml(currentId)}" placeholder="xxxxxxxxxxxx-xxxxxxxxxxxx.apps.googleusercontent.com" style="direction:ltr;text-align:left;" />
      </div>
      <div class="modal-footer" style="padding-inline-start:0;">
        <button class="btn btn-primary" id="saveClientId">حفظ ومتابعة</button>
        <button class="btn btn-ghost" data-close="genericModal">إلغاء</button>
      </div>
    `;
    openModal('إعداد Google Drive Backup', content);
    document.getElementById('saveClientId').addEventListener('click', async () => {
      const id = document.getElementById('gdriveClientId').value.trim();
      if (!id) {
        toast('يرجى إدخال Client ID', 'warning');
        return;
      }
      localStorage.setItem('gdrive_client_id', id);
      Backup.CLIENT_ID = id;
      closeModal('genericModal');
      await Backup.signIn(id);
    });
  },
};

// ===== صفحة الإعدادات Backup =====
const BackupPage = {
  render: () => {
    const connected = Backup.isConnected();
    const lastBackup = localStorage.getItem('last_backup_time');
    const lastText = lastBackup
      ? new Date(lastBackup).toLocaleString('ar-EG')
      : 'لا توجد نسخة سابقة';

    return `
      <div class="card">
        <div class="card-header">
          <h2>☁️ النسخ الاحتياطي السحابي (Google Drive)</h2>
        </div>
        <div class="card-body">
          <div style="display:grid;gap:1rem;">
            <div style="padding:1rem;border-radius:10px;background:${connected ? 'var(--success-light)' : 'var(--warning-light)'};display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:0.5rem;">
              <div>
                <div style="font-weight:700;font-size:1.05rem;color:${connected ? 'var(--success)' : 'var(--warning)'};">
                  ${connected ? '✅ متصل بـ Google Drive' : '⚠️ غير متصل'}
                </div>
                <div style="font-size:0.85rem;color:var(--text-muted);margin-top:0.2rem;">
                  آخر نسخة: ${lastText}
                </div>
              </div>
              <div style="display:flex;gap:0.5rem;flex-wrap:wrap;">
                ${connected
                  ? `<button class="btn btn-danger" id="gdriveDisconnect">قطع الاتصال</button>`
                  : `<button class="btn btn-primary" id="gdriveConnect">🔗 ربط بـ Google Drive</button>`
                }
              </div>
            </div>

            <div class="grid grid-2" style="gap:1rem;">
              <div class="card" style="background:var(--bg);">
                <div class="card-body" style="text-align:center;">
                  <div style="font-size:2.5rem;">☁️</div>
                  <h3>نسخة سحابية</h3>
                  <p style="color:var(--text-muted);font-size:0.9rem;margin:0.5rem 0;">احفظ بياناتك على Google Drive واسترجعها من أي جهاز</p>
                  <button class="btn btn-primary btn-block" id="cloudBackupNow" ${!connected ? 'disabled style="opacity:0.5;"' : ''}>☁️ نسخ احتياطي الآن</button>
                </div>
              </div>
              <div class="card" style="background:var(--bg);">
                <div class="card-body" style="text-align:center;">
                  <div style="font-size:2.5rem;">💾</div>
                  <h3>نسخة محلية</h3>
                  <p style="color:var(--text-muted);font-size:0.9rem;margin:0.5rem 0;">حمّل نسخة على جهازك كملف JSON</p>
                  <button class="btn btn-secondary btn-block" id="localBackupNow">💾 تنزيل محلي</button>
                </div>
              </div>
            </div>

            <div class="card" style="background:var(--bg);">
              <div class="card-header">
                <h3>📜 النسخ السابقة على Drive</h3>
                <button class="btn btn-sm btn-ghost" id="refreshBackupsList">🔄 تحديث</button>
              </div>
              <div class="card-body" id="backupsList">
                <p style="text-align:center;color:var(--text-muted);">اضغط تحديث لعرض النسخ</p>
              </div>
            </div>

            <div class="card" style="background:var(--bg);">
              <div class="card-header">
                <h3>📥 استعادة من ملف محلي</h3>
              </div>
              <div class="card-body">
                <p style="color:var(--text-muted);font-size:0.9rem;margin-bottom:0.5rem;">⚠️ الاستعادة تستبدل كل البيانات الحالية</p>
                <button class="btn btn-warning" id="restoreLocalBtn">📂 اختيار ملف واستعادة</button>
              </div>
            </div>

            <div style="padding:1rem;background:var(--primary-light);border-radius:8px;font-size:0.9rem;">
              <strong>💡 معلومة:</strong> عند التفعيل، يأخذ النظام نسخة احتياطية تلقائياً كل يوم. النسخ تُحفظ في مجلد خاص على Google Drive باسم "<b>${Backup.FOLDER_NAME}</b>".
            </div>
          </div>
        </div>
      </div>
    `;
  },

  bindEvents: () => {
    document.getElementById('gdriveConnect')?.addEventListener('click', async () => {
      const clientId = localStorage.getItem('gdrive_client_id');
      if (!clientId) {
        Backup._showSettingsModal();
      } else {
        await Backup.signIn(clientId);
        BackupPage.refresh();
      }
    });

    document.getElementById('gdriveDisconnect')?.addEventListener('click', () => {
      if (confirm('قطع الاتصال بـ Google Drive؟')) {
        Backup.signOut();
        BackupPage.refresh();
      }
    });

    document.getElementById('cloudBackupNow')?.addEventListener('click', async () => {
      const btn = document.getElementById('cloudBackupNow');
      btn.disabled = true;
      btn.textContent = '⏳ جاري الحفظ...';
      await Backup.createBackup(false);
      btn.disabled = false;
      btn.textContent = '☁️ نسخ احتياطي الآن';
      BackupPage.refresh();
    });

    document.getElementById('localBackupNow')?.addEventListener('click', () => {
      Backup.downloadLocal();
    });

    document.getElementById('restoreLocalBtn')?.addEventListener('click', () => {
      Backup.restoreLocal();
    });

    document.getElementById('refreshBackupsList')?.addEventListener('click', async () => {
      const list = document.getElementById('backupsList');
      list.innerHTML = '<p style="text-align:center;">⏳ جاري الجلب...</p>';
      const backups = await Backup.listBackups();
      if (backups.length === 0) {
        list.innerHTML = '<p style="text-align:center;color:var(--text-muted);">لا توجد نسخ سابقة على Drive</p>';
        return;
      }
      list.innerHTML = `
        <div style="display:grid;gap:0.5rem;">
          ${backups.map(b => `
            <div style="display:flex;align-items:center;justify-content:space-between;padding:0.75rem;background:#fff;border:1px solid var(--border);border-radius:8px;flex-wrap:wrap;gap:0.5rem;">
              <div>
                <div style="font-weight:600;">${escapeHtml(b.name)}</div>
                <div style="font-size:0.8rem;color:var(--text-muted);">
                  ${new Date(b.createdTime).toLocaleString('ar-EG')} • ${(b.size / 1024).toFixed(1)} KB
                </div>
                ${b.description ? `<div style="font-size:0.75rem;color:var(--text-muted);">${escapeHtml(b.description)}</div>` : ''}
              </div>
              <button class="btn btn-sm btn-warning" data-restore="${b.id}">📥 استعادة</button>
            </div>
          `).join('')}
        </div>
      `;
      list.querySelectorAll('[data-restore]').forEach(btn => {
        btn.addEventListener('click', async () => {
          await Backup.restoreBackup(btn.dataset.restore);
        });
      });
    });
  },

  refresh: () => {
    const container = document.getElementById('pageContainer');
    container.innerHTML = BackupPage.render();
    BackupPage.bindEvents();
  },
};
