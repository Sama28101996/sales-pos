// =====================================================
// التقارير والرسوم البيانية
// =====================================================

const Reports = {
  chart: null,

  render: () => {
    const stats = Reports._computeStats();

    return `
      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-icon">💰</div>
          <div class="stat-label">إجمالي المبيعات</div>
          <div class="stat-value">${stats.totalSales.toFixed(2)} $</div>
        </div>
        <div class="stat-card danger">
          <div class="stat-icon">📥</div>
          <div class="stat-label">إجمالي المشتريات</div>
          <div class="stat-value">${stats.totalPurchases.toFixed(2)} $</div>
        </div>
        <div class="stat-card success">
          <div class="stat-icon">📈</div>
          <div class="stat-label">صافي الربح</div>
          <div class="stat-value" style="color:${stats.netProfit >= 0 ? 'var(--success)' : 'var(--danger)'};">${stats.netProfit.toFixed(2)} $</div>
        </div>
        <div class="stat-card warning">
          <div class="stat-icon">💳</div>
          <div class="stat-label">الديون المعلقة</div>
          <div class="stat-value">${stats.totalDebts.toFixed(2)} $</div>
        </div>
      </div>

      <div class="card" style="margin-bottom:1.5rem;">
        <div class="card-header">
          <h2>📊 رسم بياني للربح والخسارة</h2>
          <div style="display:flex;gap:0.5rem;">
            <select id="reportPeriod">
              <option value="daily">يومي (آخر 14 يوم)</option>
              <option value="weekly">أسبوعي (آخر 8 أسابيع)</option>
              <option value="monthly">شهري (آخر 12 شهر)</option>
            </select>
          </div>
        </div>
        <div class="card-body">
          <canvas id="profitChart" style="max-height:400px;"></canvas>
        </div>
      </div>

      <div class="grid grid-2">
        <div class="card">
          <div class="card-header">
            <h2>🏆 أكثر المنتجات مبيعاً</h2>
          </div>
          <div class="card-body">
            <div id="topProducts"></div>
          </div>
        </div>

        <div class="card">
          <div class="card-header">
            <h2>⚠️ منتجات بمخزون منخفض</h2>
          </div>
          <div class="card-body">
            <div id="lowStock"></div>
          </div>
        </div>
      </div>

      <div class="card" style="margin-top:1.5rem;">
        <div class="card-header">
          <h2>👥 أفضل العملاء</h2>
        </div>
        <div class="card-body">
          <div id="topCustomers"></div>
        </div>
      </div>
    `;
  },

  _computeStats: () => {
    const sales = Sales.all();
    const purchases = Purchases.all();
    const debts = Debts.all();

    const totalSales = sales.reduce((s, x) => s + x.total, 0);
    const totalPurchases = purchases.reduce((s, x) => s + x.total, 0);

    // الربح = (مبيعات - تكلفة البضاعة المباعة)
    const totalCost = sales.reduce((s, sale) => {
      return s + sale.items.reduce((sub, item) => sub + (item.cost * item.qty), 0);
    }, 0);
    const netProfit = totalSales - totalCost;

    const totalDebts = debts.filter(d => d.remainingAmount > 0).reduce((s, d) => s + d.remainingAmount, 0);

    return { totalSales, totalPurchases, netProfit, totalDebts };
  },

  _buildChartData: (period) => {
    const sales = Sales.all();
    const purchases = Purchases.all();

    let labels = [];
    let salesData = [];
    let purchaseData = [];
    let profitData = [];

    const now = new Date();

    if (period === 'daily') {
      // آخر 14 يوم
      for (let i = 13; i >= 0; i--) {
        const d = new Date(now);
        d.setDate(d.getDate() - i);
        d.setHours(0, 0, 0, 0);
        const next = new Date(d);
        next.setDate(next.getDate() + 1);

        const daySales = sales.filter(s => {
          const sd = new Date(s.createdAt);
          return sd >= d && sd < next;
        });
        const dayPurchases = purchases.filter(p => {
          const pd = new Date(p.createdAt);
          return pd >= d && pd < next;
        });

        const salesTotal = daySales.reduce((s, x) => s + x.total, 0);
        const purchaseTotal = dayPurchases.reduce((s, x) => s + x.total, 0);
        const costTotal = daySales.reduce((s, sale) => s + sale.items.reduce((sub, item) => sub + (item.cost * item.qty), 0), 0);
        const profit = salesTotal - costTotal;

        labels.push(d.toLocaleDateString('ar-EG', { day: 'numeric', month: 'short' }));
        salesData.push(salesTotal);
        purchaseData.push(purchaseTotal);
        profitData.push(profit);
      }
    } else if (period === 'weekly') {
      // آخر 8 أسابيع
      for (let i = 7; i >= 0; i--) {
        const end = new Date(now);
        end.setDate(end.getDate() - (i * 7));
        end.setHours(23, 59, 59, 999);
        const start = new Date(end);
        start.setDate(start.getDate() - 6);
        start.setHours(0, 0, 0, 0);

        const wSales = sales.filter(s => {
          const sd = new Date(s.createdAt);
          return sd >= start && sd <= end;
        });
        const wPurchases = purchases.filter(p => {
          const pd = new Date(p.createdAt);
          return pd >= start && pd <= end;
        });

        const salesTotal = wSales.reduce((s, x) => s + x.total, 0);
        const purchaseTotal = wPurchases.reduce((s, x) => s + x.total, 0);
        const costTotal = wSales.reduce((s, sale) => s + sale.items.reduce((sub, item) => sub + (item.cost * item.qty), 0), 0);
        const profit = salesTotal - costTotal;

        labels.push(`أسبوع ${8 - i}`);
        salesData.push(salesTotal);
        purchaseData.push(purchaseTotal);
        profitData.push(profit);
      }
    } else {
      // شهري - آخر 12 شهر
      for (let i = 11; i >= 0; i--) {
        const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
        const next = new Date(now.getFullYear(), now.getMonth() - i + 1, 1);

        const mSales = sales.filter(s => {
          const sd = new Date(s.createdAt);
          return sd >= d && sd < next;
        });
        const mPurchases = purchases.filter(p => {
          const pd = new Date(p.createdAt);
          return pd >= d && pd < next;
        });

        const salesTotal = mSales.reduce((s, x) => s + x.total, 0);
        const purchaseTotal = mPurchases.reduce((s, x) => s + x.total, 0);
        const costTotal = mSales.reduce((s, sale) => s + sale.items.reduce((sub, item) => sub + (item.cost * item.qty), 0), 0);
        const profit = salesTotal - costTotal;

        labels.push(d.toLocaleDateString('ar-EG', { month: 'short', year: 'numeric' }));
        salesData.push(salesTotal);
        purchaseData.push(purchaseTotal);
        profitData.push(profit);
      }
    }

    return { labels, salesData, purchaseData, profitData };
  },

  renderChart: (period = 'daily') => {
    const ctx = document.getElementById('profitChart');
    if (!ctx) return;
    const data = Reports._buildChartData(period);

    if (Reports.chart) Reports.chart.destroy();

    Reports.chart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: data.labels,
        datasets: [
          {
            label: 'المبيعات',
            data: data.salesData,
            backgroundColor: 'rgba(16, 185, 129, 0.7)',
            borderColor: 'rgb(16, 185, 129)',
            borderWidth: 1,
            borderRadius: 6,
          },
          {
            label: 'المشتريات',
            data: data.purchaseData,
            backgroundColor: 'rgba(239, 68, 68, 0.7)',
            borderColor: 'rgb(239, 68, 68)',
            borderWidth: 1,
            borderRadius: 6,
          },
          {
            label: 'صافي الربح',
            data: data.profitData,
            type: 'line',
            borderColor: 'rgb(37, 99, 235)',
            backgroundColor: 'rgba(37, 99, 235, 0.1)',
            borderWidth: 3,
            tension: 0.3,
            fill: true,
            yAxisID: 'y1',
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: 'top', labels: { font: { family: 'Cairo', size: 13 } } },
        },
        scales: {
          x: { ticks: { font: { family: 'Cairo' } } },
          y: { beginAtZero: true, ticks: { font: { family: 'Cairo' } } },
          y1: { beginAtZero: true, position: 'left', grid: { display: false } },
        },
      },
    });
  },

  renderTopProducts: () => {
    const sales = Sales.all();
    const productSales = {};

    sales.forEach(s => {
      s.items.forEach(item => {
        if (!productSales[item.productId]) {
          productSales[item.productId] = {
            name: item.name,
            qty: 0,
            revenue: 0,
          };
        }
        productSales[item.productId].qty += item.qty;
        productSales[item.productId].revenue += item.subtotal;
      });
    });

    const top = Object.values(productSales).sort((a, b) => b.revenue - a.revenue).slice(0, 5);

    if (top.length === 0) return '<p style="text-align:center;color:var(--text-muted);padding:1rem;">لا توجد بيانات</p>';

    return `
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>المنتج</th>
            <th>الكمية</th>
            <th>الإيرادات</th>
          </tr>
        </thead>
        <tbody>
          ${top.map((p, i) => `
            <tr>
              <td>${i + 1}</td>
              <td>${escapeHtml(p.name)}</td>
              <td>${p.qty}</td>
              <td><strong>${p.revenue.toFixed(2)} $</strong></td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;
  },

  renderLowStock: () => {
    const alert = Settings.get().lowStockAlert || 5;
    const low = Products.all().filter(p => p.stock <= alert).sort((a, b) => a.stock - b.stock).slice(0, 10);

    if (low.length === 0) return '<p style="text-align:center;color:var(--text-muted);padding:1rem;">كل المنتجات بمخزون جيد ✅</p>';

    return `
      <table>
        <thead>
          <tr>
            <th>المنتج</th>
            <th>المخزون</th>
          </tr>
        </thead>
        <tbody>
          ${low.map(p => `
            <tr>
              <td>${escapeHtml(p.name)}</td>
              <td>${p.stock <= 0 ? '<span class="badge badge-danger">نفد</span>' : `<span class="badge badge-warning">${p.stock}</span>`}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;
  },

  renderTopCustomers: () => {
    const top = Customers.all().sort((a, b) => (b.totalPurchases || 0) - (a.totalPurchases || 0)).slice(0, 5);

    if (top.length === 0) return '<p style="text-align:center;color:var(--text-muted);padding:1rem;">لا يوجد عملاء</p>';

    return `
      <table>
        <thead>
          <tr>
            <th>العميل</th>
            <th>المشتريات</th>
            <th>الدين</th>
          </tr>
        </thead>
        <tbody>
          ${top.map(c => `
            <tr>
              <td><strong>${escapeHtml(c.name)}</strong></td>
              <td>${(c.totalPurchases || 0).toFixed(2)} $</td>
              <td>${(c.totalDebt || 0) > 0 ? `<span style="color:var(--danger);">${c.totalDebt.toFixed(2)} $</span>` : '—'}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;
  },

  bindEvents: () => {
    document.getElementById('reportPeriod')?.addEventListener('change', (e) => {
      Reports.renderChart(e.target.value);
    });
  },

  afterRender: () => {
    Reports.renderChart('daily');
    const top = document.getElementById('topProducts');
    if (top) top.innerHTML = Reports.renderTopProducts();
    const low = document.getElementById('lowStock');
    if (low) low.innerHTML = Reports.renderLowStock();
    const customers = document.getElementById('topCustomers');
    if (customers) customers.innerHTML = Reports.renderTopCustomers();
  },
};
