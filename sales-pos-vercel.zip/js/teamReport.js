// =====================================================
// كشف حساب عضو الفريق
// اختر عضو → يطلع لك:
//   - المبلغ الإجمالي (مبيعاته)
//   - سجل الدفعات
//   - المبلغ المتبقي (الدين عليه)
//   - المبلغ المفتوح من بضاعة (في المخزون)
// =====================================================

const TeamReport = {
  // التاريخ افتراضي: من بداية الشهر إلى اليوم
  _dateFrom: (() => {
    const d = new Date();
    return new Date(d.getFullYear(), d.getMonth(), 1).toISOString().slice(0, 10);
  })(),
  _dateTo: (() => new Date().toISOString().slice(0, 10)),
  _selectedUserId: null,

  render: () => {
    const users = Users.all();
    if (users.length === 0) {
      return `
        <div class="card">
          <div class="card-header"><h2>🧑‍💼 كشف حساب عضو الفريق</h2></div>
          <div class="card-body">
            <div class="empty-state">
              <div class="empty-icon">👥</div>
              <p>لا يوجد أعضاء فريق بعد. أضف أعضاء من "إدارة الفريق" أولاً.</p>
            </div>
          </div>
        </div>
      `;
    }

    return `
      <div class="card">
        <div class="card-header">
          <h2>🧑‍💼 كشف حساب عضو الفريق</h2>
        </div>
        <div class="card-body">
          <!-- اختيار العضو + التاريخ -->
          <div class="user-picker">
            <div class="user-picker-field">
              <label>اختر العضو</label>
              <select id="teamReportUserSelect">
                <option value="">— اختر عضو —</option>
                ${users.map(u => `
                  <option value="${u.id}" ${TeamReport._selectedUserId === u.id ? 'selected' : ''}>
                    ${escapeHtml(u.name)} (${escapeHtml(u.username)})
                  </option>
                `).join('')}
              </select>
            </div>
            <div class="user-picker-field">
              <label>من تاريخ</label>
              <input type="date" id="teamReportFrom" value="${TeamReport._dateFrom}" />
            </div>
            <div class="user-picker-field">
              <label>إلى تاريخ</label>
              <input type="date" id="teamReportTo" value="${TeamReport._dateTo}" />
            </div>
            <div class="user-picker-field user-picker-actions">
              <button class="btn btn-ghost" id="teamReportReset">↻ إعادة تعيين</button>
            </div>
          </div>

          <!-- محتوى الكشف -->
          <div id="teamReportContent" style="margin-top:1.5rem;">
            <div class="empty-state" style="padding:2rem;">
              <div class="empty-icon">👆</div>
              <p>اختر عضو من القائمة لعرض كشف حسابه</p>
            </div>
          </div>
        </div>
      </div>
    `;
  },

  afterRender: () => {
    // لا تعمل شيء، ينتظر التفاعل
  },

  bindEvents: () => {
    document.getElementById('teamReportUserSelect')?.addEventListener('change', (e) => {
      TeamReport._selectedUserId = e.target.value;
      TeamReport._renderStatement();
    });

    document.getElementById('teamReportFrom')?.addEventListener('change', (e) => {
      TeamReport._dateFrom = e.target.value;
      TeamReport._renderStatement();
    });

    document.getElementById('teamReportTo')?.addEventListener('change', (e) => {
      TeamReport._dateTo = e.target.value;
      TeamReport._renderStatement();
    });

    document.getElementById('teamReportReset')?.addEventListener('click', () => {
      const d = new Date();
      TeamReport._dateFrom = new Date(d.getFullYear(), d.getMonth(), 1).toISOString().slice(0, 10);
      TeamReport._dateTo = d.toISOString().slice(0, 10);
      const fromInp = document.getElementById('teamReportFrom');
      const toInp = document.getElementById('teamReportTo');
      if (fromInp) fromInp.value = TeamReport._dateFrom;
      if (toInp) toInp.value = TeamReport._dateTo;
      TeamReport._renderStatement();
    });
  },

  _renderStatement: () => {
    const container = document.getElementById('teamReportContent');
    if (!container) return;

    if (!TeamReport._selectedUserId) {
      container.innerHTML = `
        <div class="empty-state" style="padding:2rem;">
          <div class="empty-icon">👆</div>
          <p>اختر عضو من القائمة لعرض كشف حسابه</p>
        </div>
      `;
      return;
    }

    const user = Users.find(TeamReport._selectedUserId);
    if (!user) {
      container.innerHTML = '<div class="empty-state"><div class="empty-icon">❌</div><p>العضو غير موجود</p></div>';
      return;
    }

    const stats = TeamReport._computeUserStats(user, TeamReport._dateFrom, TeamReport._dateTo);
    const roleName = ROLES[user.role]?.name || user.role;
    const initials = (user.name || user.username || '?').trim().charAt(0);

    container.innerHTML = `
      <!-- هيدر العضو -->
      <div class="statement-header">
        <div class="statement-avatar">${escapeHtml(initials)}</div>
        <div class="statement-userinfo">
          <div class="statement-username">${escapeHtml(user.name)}</div>
          <div class="statement-userrole">${escapeHtml(user.username)} • د.ع{escapeHtml(roleName)}</div>
          <div class="statement-period">📅 من ${TeamReport._dateFrom} إلى ${TeamReport._dateTo}</div>
        </div>
        <button class="btn btn-primary" id="teamReportPrint">🖨️ طباعة</button>
      </div>

      <!-- 4 خانات رئيسية -->
      <div class="statement-stats">
        <div class="stmt-stat stmt-stat--primary">
          <div class="stmt-stat-icon">💵</div>
          <div class="stmt-stat-label">المبلغ الإجمالي</div>
          <div class="stmt-stat-value">${stats.totalOnUser.toFixed(2)} $</div>
          <div class="stmt-stat-sub">${stats.salesCount} فاتورة في الفترة</div>
        </div>
        <div class="stmt-stat stmt-stat--success">
          <div class="stmt-stat-icon">✅</div>
          <div class="stmt-stat-label">المبلغ المسدد</div>
          <div class="stmt-stat-value">${stats.totalPaid.toFixed(2)} $</div>
          <div class="stmt-stat-sub">${stats.paymentsList.length} دفعة</div>
        </div>
        <div class="stmt-stat stmt-stat--danger">
          <div class="stmt-stat-icon">⏳</div>
          <div class="stmt-stat-label">المبلغ المطلوب (الدين)</div>
          <div class="stmt-stat-value">${stats.totalRemaining.toFixed(2)} $</div>
          <div class="stmt-stat-sub">${stats.unpaidInvoices.length} فاتورة غير مسددة</div>
        </div>
        <div class="stmt-stat stmt-stat--warning">
          <div class="stmt-stat-icon">📦</div>
          <div class="stmt-stat-label">المبلغ المفتوح من بضاعة</div>
          <div class="stmt-stat-value">${stats.productsValue.toFixed(2)} $</div>
          <div class="stmt-stat-sub">${stats.productsUnits} وحدة في المخزون (تكلفة)</div>
        </div>
      </div>

      <!-- سجل الدفعات -->
      <div class="card statement-section">
        <div class="card-header">
          <h3>💰 سجل الدفعات (${stats.paymentsList.length})</h3>
        </div>
        <div class="card-body">
          ${stats.paymentsList.length === 0 ? `
            <p style="text-align:center;color:var(--text-muted);padding:1rem;">لا توجد دفعات في هذه الفترة</p>
          ` : `
            <table>
              <thead>
                <tr>
                  <th>#</th>
                  <th>التاريخ</th>
                  <th>الفاتورة</th>
                  <th>العميل</th>
                  <th>النوع</th>
                  <th>المبلغ</th>
                </tr>
              </thead>
              <tbody>
                ${stats.paymentsList.map((p, i) => `
                  <tr>
                    <td>${i + 1}</td>
                    <td>${new Date(p.date).toLocaleString('ar-EG')}</td>
                    <td>${p.invoiceNo || '—'}</td>
                    <td>${escapeHtml(p.customer)}</td>
                    <td>${p.type === 'cash' ? '<span class="badge badge-success">نقدي</span>' : '<span class="badge badge-info">دفعة دين</span>'}</td>
                    <td style="font-weight:700;color:var(--success);">${p.amount.toFixed(2)} $</td>
                  </tr>
                `).join('')}
              </tbody>
              <tfoot>
                <tr>
                  <td colspan="5" style="text-align:left;font-weight:700;">الإجمالي:</td>
                  <td style="font-weight:700;color:var(--success);font-size:1.05rem;">${stats.totalPaid.toFixed(2)} $</td>
                </tr>
              </tfoot>
            </table>
          `}
        </div>
      </div>

      <!-- الفواتير غير المسددة (الديون) -->
      <div class="card statement-section">
        <div class="card-header">
          <h3>⏳ الفواتير غير المسددة (${stats.unpaidInvoices.length})</h3>
        </div>
        <div class="card-body">
          ${stats.unpaidInvoices.length === 0 ? `
            <p style="text-align:center;color:var(--text-muted);padding:1rem;">✅ ممتاز! لا توجد فواتير غير مسددة</p>
          ` : `
            <table>
              <thead>
                <tr>
                  <th>الفاتورة</th>
                  <th>التاريخ</th>
                  <th>العميل</th>
                  <th>الإجمالي</th>
                  <th>المدفوع</th>
                  <th>المتبقي</th>
                </tr>
              </thead>
              <tbody>
                ${stats.unpaidInvoices.map(s => `
                  <tr>
                    <td><strong>${s.invoiceNo || '—'}</strong></td>
                    <td>${new Date(s.createdAt).toLocaleDateString('ar-EG')}</td>
                    <td>${escapeHtml(s.customerName || '—')}</td>
                    <td>${(s.total || 0).toFixed(2)} $</td>
                    <td style="color:var(--success);">${(s.paidAmount || 0).toFixed(2)} $</td>
                    <td style="color:var(--danger);font-weight:700;">${(s.remainingAmount || 0).toFixed(2)} $</td>
                  </tr>
                `).join('')}
              </tbody>
              <tfoot>
                <tr>
                  <td colspan="5" style="text-align:left;font-weight:700;">إجمالي المتبقي:</td>
                  <td style="font-weight:700;color:var(--danger);font-size:1.05rem;">${stats.totalRemaining.toFixed(2)} $</td>
                </tr>
              </tfoot>
            </table>
          `}
        </div>
      </div>

      <!-- كل مبيعاته في الفترة -->
      <div class="card statement-section">
        <div class="card-header">
          <h3>📜 كل مبيعاته في الفترة (${stats.userSales.length})</h3>
        </div>
        <div class="card-body">
          ${stats.userSales.length === 0 ? `
            <p style="text-align:center;color:var(--text-muted);padding:1rem;">لا توجد مبيعات في هذه الفترة</p>
          ` : `
            <table>
              <thead>
                <tr>
                  <th>الفاتورة</th>
                  <th>التاريخ</th>
                  <th>العميل</th>
                  <th>النوع</th>
                  <th>الإجمالي</th>
                  <th>المدفوع</th>
                  <th>المتبقي</th>
                </tr>
              </thead>
              <tbody>
                ${stats.userSales.map(s => `
                  <tr>
                    <td><strong>${s.invoiceNo || '—'}</strong></td>
                    <td>${new Date(s.createdAt).toLocaleString('ar-EG')}</td>
                    <td>${escapeHtml(s.customerName || '—')}</td>
                    <td>${s.type === 'cash' ? '<span class="badge badge-success">نقدي</span>' : '<span class="badge badge-warning">آجل</span>'}</td>
                    <td>${(s.total || 0).toFixed(2)} $</td>
                    <td style="color:var(--success);">${(s.paidAmount || 0).toFixed(2)} $</td>
                    <td style="${(s.remainingAmount || 0) > 0 ? 'color:var(--danger);font-weight:700;' : ''}">${(s.remainingAmount || 0).toFixed(2)} $</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          `}
        </div>
      </div>

      <!-- البضاعة المفتوحة -->
      <div class="card statement-section">
        <div class="card-header">
          <h3>📦 البضاعة المفتوحة (${stats.userProducts.length} منتج)</h3>
        </div>
        <div class="card-body">
          ${stats.userProducts.length === 0 ? `
            <p style="text-align:center;color:var(--text-muted);padding:1rem;">لا توجد بضاعة في المخزون مضافة من هذا العضو</p>
            <p style="text-align:center;color:var(--text-muted);font-size:0.85rem;">ملاحظة: البضاعة تُحسب فقط إذا تم تسجيل العضو كـ"مُضيف" للمنتج</p>
          ` : `
            <table>
              <thead>
                <tr>
                  <th>المنتج</th>
                  <th>الفئة</th>
                  <th>الكمية في المخزون</th>
                  <th>التكلفة</th>
                  <th>القيمة الإجمالية</th>
                </tr>
              </thead>
              <tbody>
                ${stats.userProducts.map(p => `
                  <tr>
                    <td><strong>${escapeHtml(p.name)}</strong></td>
                    <td>${p.category ? `<span class="badge badge-info">${escapeHtml(p.category)}</span>` : '—'}</td>
                    <td>${p.stock}</td>
                    <td>${(p.cost || 0).toFixed(2)} $</td>
                    <td style="font-weight:700;color:var(--warning,#f59e0b);">${(p.stock * p.cost).toFixed(2)} $</td>
                  </tr>
                `).join('')}
              </tbody>
              <tfoot>
                <tr>
                  <td colspan="4" style="text-align:left;font-weight:700;">إجمالي قيمة البضاعة:</td>
                  <td style="font-weight:700;color:var(--warning,#f59e0b);font-size:1.05rem;">${stats.productsValue.toFixed(2)} $</td>
                </tr>
              </tfoot>
            </table>
          `}
        </div>
      </div>
    `;

    // زر الطباعة
    document.getElementById('teamReportPrint')?.addEventListener('click', () => {
      TeamReport._print(user, stats);
    });
  },

  _print: (user, stats) => {
    const roleName = ROLES[user.role]?.name || user.role;
    const w = window.open('', '_blank');
    if (!w) { toast('الرجاء السماح بالنوافذ المنبثقة للطباعة', 'warning'); return; }
    w.document.write(`
      <!DOCTYPE html>
      <html lang="ar" dir="rtl">
      <head>
        <meta charset="UTF-8" />
        <title>كشف حساب - د.ع{escapeHtml(user.name)}</title>
        <style>
          body { font-family: 'Cairo', Arial, sans-serif; padding: 20px; color: #0f172a; }
          h1 { margin: 0 0 4px 0; font-size: 22px; }
          h2 { margin-top: 24px; font-size: 16px; border-bottom: 2px solid #2563eb; padding-bottom: 6px; }
          .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #2563eb; padding-bottom: 12px; }
          .meta { font-size: 13px; color: #64748b; }
          .stats { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; margin-top: 16px; }
          .stat-box { border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px; }
          .stat-label { font-size: 12px; color: #64748b; }
          .stat-value { font-size: 20px; font-weight: 700; margin-top: 4px; }
          table { width: 100%; border-collapse: collapse; margin-top: 12px; font-size: 13px; }
          th, td { padding: 8px; border-bottom: 1px solid #e2e8f0; text-align: right; }
          th { background: #f1f5f9; font-weight: 700; }
          tfoot td { font-weight: 700; background: #f8fafc; }
          .primary { color: #2563eb; } .success { color: #10b981; } .danger { color: #ef4444; } .warning { color: #f59e0b; }
        </style>
      </head>
      <body>
        <div class="header">
          <div>
            <h1>كشف حساب عضو الفريق</h1>
            <div class="meta">${escapeHtml(user.name)} • د.ع{escapeHtml(user.username)} • د.ع{escapeHtml(roleName)}</div>
          </div>
          <div class="meta">📅 من ${TeamReport._dateFrom} إلى ${TeamReport._dateTo}</div>
        </div>

        <div class="stats">
          <div class="stat-box">
            <div class="stat-label">المبلغ الإجمالي</div>
            <div class="stat-value primary">${stats.totalOnUser.toFixed(2)} $</div>
            <div class="meta">${stats.salesCount} فاتورة</div>
          </div>
          <div class="stat-box">
            <div class="stat-label">المبلغ المسدد</div>
            <div class="stat-value success">${stats.totalPaid.toFixed(2)} $</div>
            <div class="meta">${stats.paymentsList.length} دفعة</div>
          </div>
          <div class="stat-box">
            <div class="stat-label">المبلغ المطلوب (الدين)</div>
            <div class="stat-value danger">${stats.totalRemaining.toFixed(2)} $</div>
            <div class="meta">${stats.unpaidInvoices.length} فاتورة غير مسددة</div>
          </div>
          <div class="stat-box">
            <div class="stat-label">المبلغ المفتوح من بضاعة</div>
            <div class="stat-value warning">${stats.productsValue.toFixed(2)} $</div>
            <div class="meta">${stats.productsUnits} وحدة في المخزون</div>
          </div>
        </div>

        <h2>💰 سجل الدفعات</h2>
        ${stats.paymentsList.length === 0 ? '<p>لا توجد دفعات</p>' : `
          <table>
            <thead><tr><th>#</th><th>التاريخ</th><th>الفاتورة</th><th>العميل</th><th>المبلغ</th></tr></thead>
            <tbody>
              ${stats.paymentsList.map((p, i) => `<tr><td>${i+1}</td><td>${new Date(p.date).toLocaleString('ar-EG')}</td><td>${p.invoiceNo || '—'}</td><td>${escapeHtml(p.customer)}</td><td>${p.amount.toFixed(2)} $</td></tr>`).join('')}
            </tbody>
            <tfoot><tr><td colspan="4">الإجمالي:</td><td>${stats.totalPaid.toFixed(2)} $</td></tr></tfoot>
          </table>
        `}

        <h2>⏳ الفواتير غير المسددة</h2>
        ${stats.unpaidInvoices.length === 0 ? '<p>لا يوجد</p>' : `
          <table>
            <thead><tr><th>الفاتورة</th><th>التاريخ</th><th>العميل</th><th>الإجمالي</th><th>المدفوع</th><th>المتبقي</th></tr></thead>
            <tbody>
              ${stats.unpaidInvoices.map(s => `<tr><td>${s.invoiceNo || '—'}</td><td>${new Date(s.createdAt).toLocaleDateString('ar-EG')}</td><td>${escapeHtml(s.customerName || '—')}</td><td>${(s.total || 0).toFixed(2)} $</td><td>${(s.paidAmount || 0).toFixed(2)} $</td><td>${(s.remainingAmount || 0).toFixed(2)} $</td></tr>`).join('')}
            </tbody>
            <tfoot><tr><td colspan="5">إجمالي المتبقي:</td><td>${stats.totalRemaining.toFixed(2)} $</td></tr></tfoot>
          </table>
        `}

        <h2>📦 البضاعة المفتوحة</h2>
        ${stats.userProducts.length === 0 ? '<p>لا توجد بضاعة مضافة من هذا العضو</p>' : `
          <table>
            <thead><tr><th>المنتج</th><th>الكمية</th><th>التكلفة</th><th>القيمة</th></tr></thead>
            <tbody>
              ${stats.userProducts.map(p => `<tr><td>${escapeHtml(p.name)}</td><td>${p.stock}</td><td>${(p.cost || 0).toFixed(2)} $</td><td>${(p.stock * p.cost).toFixed(2)} $</td></tr>`).join('')}
            </tbody>
            <tfoot><tr><td colspan="3">إجمالي:</td><td>${stats.productsValue.toFixed(2)} $</td></tr></tfoot>
          </table>
        `}
      </body>
      </html>
    `);
    w.document.close();
    setTimeout(() => w.print(), 300);
  },

  // ===== حساب إحصائيات العضو =====
  _computeUserStats: (user, fromDate, toDate) => {
    const fromTs = new Date(fromDate).getTime();
    const toTs = new Date(toDate).getTime() + 24 * 60 * 60 * 1000 - 1;

    // كل مبيعات العضو (في الفترة)
    const userSales = Sales.all().filter(s => {
      if (s.sellerId !== user.id) return false;
      const ts = new Date(s.createdAt).getTime();
      return ts >= fromTs && ts <= toTs;
    }).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    const totalOnUser = userSales.reduce((sum, s) => sum + (s.total || 0), 0);
    const salesCount = userSales.length;

    // الدفعات: نقدي = كامل المبلغ، آجل = paidAmount
    // كل دفعة تُسجَّل كصف في السجل
    const paymentsList = [];
    let totalPaid = 0;
    let totalRemaining = 0;

    userSales.forEach(s => {
      if (s.type === 'cash') {
        // البيع النقدي = دفعة واحدة كاملة
        paymentsList.push({
          date: s.createdAt,
          invoiceNo: s.invoiceNo,
          customer: s.customerName || 'نقدي',
          type: 'cash',
          amount: s.total || 0,
        });
        totalPaid += s.total || 0;
      } else {
        // البيع الآجل: الدفعة = المبلغ المدفوع (لو > 0)
        if ((s.paidAmount || 0) > 0) {
          paymentsList.push({
            date: s.createdAt,
            invoiceNo: s.invoiceNo,
            customer: s.customerName || '—',
            type: 'debt_payment',
            amount: s.paidAmount || 0,
          });
          totalPaid += s.paidAmount || 0;
        }
        totalRemaining += s.remainingAmount || 0;
      }
    });

    // ترتيب الدفعات من الأحدث للأقدم
    paymentsList.sort((a, b) => new Date(b.date) - new Date(a.date));

    // الفواتير غير المسددة
    const unpaidInvoices = userSales.filter(s => (s.remainingAmount || 0) > 0);

    // البضاعة المفتوحة: المنتجات المُضافة من هذا العضو (اللي في المخزون حالياً)
    const userProducts = Products.all().filter(p => (p.createdBy || p.userId) === user.id);
    const productsValue = userProducts.reduce((sum, p) => sum + (p.stock * (p.cost || 0)), 0);
    const productsUnits = userProducts.reduce((sum, p) => sum + (p.stock || 0), 0);

    return {
      totalOnUser,
      salesCount,
      totalPaid,
      totalRemaining,
      paymentsList,
      unpaidInvoices,
      userSales,
      userProducts,
      productsValue,
      productsUnits,
    };
  },
};
