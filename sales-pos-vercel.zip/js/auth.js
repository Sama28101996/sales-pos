// =====================================================
// نظام المصادقة والصلاحيات
// =====================================================

const PERMISSIONS = {
  ALL: '*',
  VIEW_DASHBOARD: 'view_dashboard',
  INVENTORY_VIEW: 'inventory_view',
  INVENTORY_EDIT: 'inventory_edit',
  SELL: 'sell',
  PURCHASE: 'purchase',
  CUSTOMERS_VIEW: 'customers_view',
  CUSTOMERS_EDIT: 'customers_edit',
  DEBTS_VIEW: 'debts_view',
  DEBTS_MANAGE: 'debts_manage',
  REPORTS_VIEW: 'reports_view',
  TEAM_MANAGE: 'team_manage',
  TEAM_REPORT: 'team_report',
  SETTINGS_MANAGE: 'settings_manage',
};

const ROLES = {
  admin: {
    name: 'أدمن (مشرف)',
    permissions: [PERMISSIONS.ALL],
  },
  buyer: {
    name: 'مشتري',
    permissions: [PERMISSIONS.PURCHASE, PERMISSIONS.INVENTORY_VIEW, PERMISSIONS.CUSTOMERS_VIEW],
  },
  seller: {
    name: 'بائع',
    permissions: [PERMISSIONS.SELL, PERMISSIONS.INVENTORY_VIEW, PERMISSIONS.CUSTOMERS_VIEW, PERMISSIONS.CUSTOMERS_EDIT, PERMISSIONS.DEBTS_VIEW],
  },
  accountant: {
    name: 'محاسب',
    permissions: [PERMISSIONS.VIEW_DASHBOARD, PERMISSIONS.REPORTS_VIEW, PERMISSIONS.DEBTS_VIEW, PERMISSIONS.DEBTS_MANAGE, PERMISSIONS.CUSTOMERS_VIEW],
  },
};

const Auth = {
  current: () => dbGet(DB_KEYS.CURRENT_USER, null),

  login: (username, password) => {
    const user = Users.findByUsername(username);
    if (!user) return { ok: false, error: 'اسم المستخدم غير موجود' };
    if (user.password !== password) return { ok: false, error: 'كلمة المرور غير صحيحة' };
    if (user.disabled) return { ok: false, error: 'هذا الحساب معطّل' };

    dbSet(DB_KEYS.CURRENT_USER, { id: user.id, loginAt: new Date().toISOString() });
    return { ok: true, user };
  },

  logout: () => {
    // ملاحظة مهمة: نسجل الخروج فقط (نحذف الجلسة)
    // البيانات والمنتجات والعملاء تبقى محفوظة في localStorage
    localStorage.removeItem(DB_KEYS.CURRENT_USER);
    console.log('[Auth] Logged out. Products and other data are preserved.');
  },

  require: () => {
    const session = Auth.current();
    if (!session) return null;
    return Users.find(session.id);
  },

  hasPermission: (user, permission) => {
    if (!user) return false;
    if (user.permissions && user.permissions.includes('*')) return true;
    if (user.permissions && user.permissions.includes(permission)) return true;
    // fallback للأدوار الافتراضية
    const role = ROLES[user.role];
    if (role && role.permissions.includes('*')) return true;
    if (role && role.permissions.includes(permission)) return true;
    return false;
  },

  effectivePermissions: (user) => {
    if (!user) return [];
    if (user.permissions && user.permissions.length > 0) return user.permissions;
    const role = ROLES[user.role];
    return role ? role.permissions : [];
  },
};
