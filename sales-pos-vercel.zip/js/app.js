// =====================================================
// التطبيق الرئيسي - ربط كل الصفحات
// =====================================================

// ====== أدوات مساعدة ======
function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function toast(message, type = 'info', duration = 2500) {
  const el = document.getElementById('toast');
  el.className = 'toast ' + type;
  el.textContent = message;
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), duration);
}

function openModal(title, bodyHtml, options = {}) {
  const modal = document.getElementById('genericModal');
  document.getElementById('genericModalTitle').textContent = title;
  document.getElementById('genericModalBody').innerHTML = bodyHtml;
  if (options.large) modal.querySelector('.modal-content').classList.add('large');
  else modal.querySelector('.modal-content').classList.remove('large');
  modal.classList.add('active');
}

function closeModal(id) {
  const modal = document.getElementById(id || 'genericModal');
  modal.classList.remove('active');
}

// ====== قائمة الصفحات ======
const PAGES = {
  dashboard: {
    title: 'لوحة التحكم',
    icon: '📊',
    perm: PERMISSIONS.VIEW_DASHBOARD,
    render: () => {
      const stats = Reports._computeStats();
      const user = Auth.require();

      return `
        <div style="background:linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);color:white;padding:1.5rem;border-radius:12px;margin-bottom:1.5rem;">
          <h2 style="color:white;">أهلاً ${escapeHtml(user.name)} 👋</h2>
          <p style="opacity:0.9;">إليك نظرة سريعة على أداء متجرك اليوم</p>
        </div>

        ${Enhancements.renderAlertsWidget()}

        <div class="stats-grid">
          <div class="stat-card">
            <div class="stat-icon">💰</div>
            <div class="stat-label">إجمالي المبيعات</div>
            <div class="stat-value">${stats.totalSales.toFixed(2)} $</div>
          </div>
          <div class="stat-card danger">
            <div class="stat-icon">📥</div>
            <div class="stat-label">إجمالي المشتريات</div>
            <div class="stat-value">${stats.totalPurchases.toFixed(2)} $</div>
          </div>
          <div class="stat-card success">
            <div class="stat-icon">📈</div>
            <div class="stat-label">صافي الربح</div>
            <div class="stat-value" style="color:${stats.netProfit >= 0 ? 'var(--success)' : 'var(--danger)'};">${stats.netProfit.toFixed(2)} $</div>
          </div>
          <div class="stat-card warning">
            <div class="stat-icon">💳</div>
            <div class="stat-label">الديون المعلقة</div>
            <div class="stat-value">${stats.totalDebts.toFixed(2)} $</div>
          </div>
        </div>

        <div class="grid grid-2">
          <div class="card">
            <div class="card-header">
              <h2>📦 المنتجات</h2>
            </div>
            <div class="card-body">
              <p style="font-size:2rem;font-weight:700;color:var(--primary);">${Products.all().length}</p>
              <p style="color:var(--text-muted);">إجمالي المنتجات</p>
              <p style="font-size:1.3rem;font-weight:600;color:var(--warning);margin-top:0.5rem;">
                ${Products.all().filter(p => p.stock <= (Settings.get().lowStockAlert || 5)).length}
              </p>
              <p style="color:var(--text-muted);">منتجات بمخزون منخفض</p>
            </div>
          </div>

          <div class="card">
            <div class="card-header">
              <h2>👥 العملاء</h2>
            </div>
            <div class="card-body">
              <p style="font-size:2rem;font-weight:700;color:var(--primary);">${Customers.all().length}</p>
              <p style="color:var(--text-muted);">إجمالي العملاء</p>
              <p style="font-size:1.3rem;font-weight:600;color:var(--danger);margin-top:0.5rem;">
                ${Customers.all().filter(c => (c.totalDebt || 0) > 0).length}
              </p>
              <p style="color:var(--text-muted);">عملاء عليهم ديون</p>
            </div>
          </div>
        </div>

        <div class="card" style="margin-top:1.5rem;">
          <div class="card-header">
            <h2>📜 آخر العمليات</h2>
          </div>
          <div class="card-body">
            ${(() => {
              const recent = Sales.all().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 5);
              if (recent.length === 0) return '<p style="text-align:center;color:var(--text-muted);">لا توجد عمليات بعد</p>';
              return `
                <table>
                  <thead>
                    <tr>
                      <th>الفاتورة</th>
                      <th>التاريخ</th>
                      <th>العميل</th>
                      <th>الإجمالي</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${recent.map(s => `
                      <tr>
                        <td>${s.invoiceNo}</td>
                        <td>${new Date(s.createdAt).toLocaleString('ar-EG')}</td>
                        <td>${escapeHtml(s.customerName)}</td>
                        <td><strong>${s.total.toFixed(2)} $</strong></td>
                      </tr>
                    `).join('')}
                  </tbody>
                </table>
              `;
            })()}
          </div>
        </div>
      `;
    },
  },

  pos: {
    title: 'نقطة البيع',
    icon: '🛒',
    perm: PERMISSIONS.SELL,
    render: SalesPage.render,
    bind: SalesPage.bindEvents,
  },

  inventory: {
    title: 'إدارة المخزون',
    icon: '📦',
    perm: PERMISSIONS.INVENTORY_VIEW,
    render: Inventory.render,
    after: Inventory.refresh,
    bind: Inventory.bindEvents,
  },

  purchase: {
    title: 'إضافة بضاعة',
    icon: '📥',
    perm: PERMISSIONS.PURCHASE,
    render: Purchase.render,
    bind: Purchase.bindEvents,
  },

  purchaseHistory: {
    title: 'سجل المشتريات',
    icon: '📋',
    perm: PERMISSIONS.INVENTORY_VIEW,
    render: PurchaseHistory.render,
  },

  salesHistory: {
    title: 'سجل المبيعات',
    icon: '🧾',
    perm: PERMISSIONS.INVENTORY_VIEW,
    render: SalesHistory.render,
    bind: SalesHistory.bindEvents,
  },

  customers: {
    title: 'العملاء',
    icon: '👥',
    perm: PERMISSIONS.CUSTOMERS_VIEW,
    render: CustomersPage.render,
    after: CustomersPage.refresh,
    bind: CustomersPage.bindEvents,
  },

  debts: {
    title: 'الديون',
    icon: '💰',
    perm: PERMISSIONS.DEBTS_VIEW,
    render: DebtsPage.render,
    after: DebtsPage.refresh,
    bind: DebtsPage.bindEvents,
  },

  reports: {
    title: 'التقارير',
    icon: '📊',
    perm: PERMISSIONS.REPORTS_VIEW,
    render: Reports.render,
    after: Reports.afterRender,
    bind: Reports.bindEvents,
  },

  team: {
    title: 'إدارة الفريق',
    icon: '👨‍💼',
    perm: PERMISSIONS.TEAM_MANAGE,
    render: TeamPage.render,
    after: TeamPage.refresh,
    bind: TeamPage.bindEvents,
  },

  teamReport: {
    title: 'تقرير أعضاء الفريق',
    icon: '🧑‍💼',
    perm: PERMISSIONS.TEAM_REPORT,
    render: TeamReport.render,
    after: TeamReport.afterRender,
    bind: TeamReport.bindEvents,
  },

  teamCompare: {
    title: 'لوحة مقارنة الأعضاء',
    icon: '🏆',
    perm: PERMISSIONS.TEAM_REPORT,
    render: () => Enhancements.renderTeamComparison(),
  },

  alertsCenter: {
    title: 'مركز التنبيهات',
    icon: '🔔',
    perm: PERMISSIONS.VIEW_DASHBOARD,
    render: () => {
      const alerts = Enhancements._checkAlerts();
      if (alerts.length === 0) {
        return `
          <div class="card">
            <div class="card-body">
              <div class="empty-state">
                <div class="empty-icon">✅</div>
                <h2>كل شي تمام!</h2>
                <p>لا توجد تنبيهات حالياً</p>
              </div>
            </div>
          </div>
        `;
      }
      return `
        <div class="card">
          <div class="card-header">
            <h2>🔔 مركز التنبيهات (${alerts.length})</h2>
            <button class="btn btn-ghost" id="refreshAllAlerts">↻ تحديث</button>
          </div>
          <div class="card-body">
            ${Enhancements.renderAlertsWidget()}
            <div style="margin-top:1.5rem;">
              <h3 style="color:var(--primary);">تفاصيل التنبيهات</h3>
              <div style="display:grid;gap:0.75rem;margin-top:1rem;">
                ${alerts.map(a => `
                  <div class="alert-item alert-${a.type}">
                    <div class="alert-icon">${a.icon}</div>
                    <div class="alert-content">
                      <div class="alert-title">${escapeHtml(a.title)}</div>
                      <div class="alert-body">${escapeHtml(a.body)}</div>
                    </div>
                    ${a.action ? `<button class="btn btn-sm btn-primary" data-alert-page="${a.action}">${a.actionLabel}</button>` : ''}
                  </div>
                `).join('')}
              </div>
            </div>
          </div>
        </div>
      `;
    },
    after: () => {
      Enhancements.bindAlertsEvents();
      document.querySelectorAll('[data-alert-page]').forEach(btn => {
        btn.addEventListener('click', () => {
          const page = btn.dataset.alertPage;
          if (page && typeof navigateTo === 'function') navigateTo(page);
        });
      });
      document.getElementById('refreshAllAlerts')?.addEventListener('click', () => navigateTo('alertsCenter'));
    },
  },

  myAccount: {
    title: 'حسابي',
    icon: '👤',
    perm: PERMISSIONS.VIEW_DASHBOARD,
    render: () => {
      const u = Auth.require();
      if (!u) return '<p>خطأ</p>';
      const userSales = Sales.all().filter(s => s.sellerId === u.id);
      const myTotal = userSales.reduce((s, x) => s + x.total, 0);
      const myCount = userSales.length;
      return `
        <div class="card">
          <div class="card-header"><h2>👤 حسابي</h2></div>
          <div class="card-body">
            <div style="display:flex;align-items:center;gap:1rem;margin-bottom:1.5rem;">
              <div style="width:80px;height:80px;background:var(--primary);color:white;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:2rem;font-weight:700;">
                ${(u.name || u.username).charAt(0)}
              </div>
              <div>
                <h3>${escapeHtml(u.name)}</h3>
                <p style="color:var(--text-muted);">@${escapeHtml(u.username)} • د.ع{ROLES[u.role]?.name || u.role}</p>
              </div>
            </div>
            <div class="stats-grid">
              <div class="stat-card">
                <div class="stat-icon">🛒</div>
                <div class="stat-label">مبيعاتي</div>
                <div class="stat-value">${myCount}</div>
              </div>
              <div class="stat-card success">
                <div class="stat-icon">💰</div>
                <div class="stat-label">إجمالي مبيعاتي</div>
                <div class="stat-value">${myTotal.toFixed(2)} $</div>
              </div>
            </div>
            <div style="margin-top:1.5rem;display:flex;gap:0.5rem;flex-wrap:wrap;">
              <button class="btn btn-primary" id="changeMyPassBtn">🔑 تغيير كلمة المرور</button>
              <button class="btn btn-ghost" id="logoutFromAccount">🚪 تسجيل الخروج</button>
            </div>
          </div>
        </div>
      `;
    },
    after: () => {
      document.getElementById('changeMyPassBtn')?.addEventListener('click', () => {
        Enhancements.changeMyPassword();
      });
      document.getElementById('logoutFromAccount')?.addEventListener('click', () => {
        if (confirm('تسجيل الخروج؟')) {
          Auth.logout();
          window.location.href = 'login.html';
        }
      });
    },
  },

  settings: {
    title: 'الإعدادات',
    icon: '⚙️',
    perm: PERMISSIONS.SETTINGS_MANAGE,
    render: SettingsPage.render,
    after: SettingsPage.afterRender,
    bind: () => {
      const form = document.getElementById('settingsForm');
      if (form) form.addEventListener('submit', SettingsPage.handleSubmit);
    },
  },

  backup: {
    title: 'النسخ الاحتياطي السحابي',
    icon: '☁️',
    perm: PERMISSIONS.SETTINGS_MANAGE,
    render: BackupPage.render,
    bind: BackupPage.bindEvents,
  },

  debtReminders: {
    title: 'تذكير الديون',
    icon: '📅',
    perm: PERMISSIONS.VIEW_CUSTOMERS,
    render: DebtReminders.renderPage,
    bind: DebtReminders.bindEvents,
  },

  dataStatus: {
    title: 'حالة حفظ البيانات',
    icon: '💾',
    perm: PERMISSIONS.VIEW_DASHBOARD,
    render: () => {
      // فتح نافذة منبثقة بدلاً من صفحة
      setTimeout(() => Persistence.showStatus(), 100);
      return `
        <div class="card">
          <div class="card-header"><h2>💾 حالة حفظ البيانات</h2></div>
          <div class="card-body" style="text-align:center;padding:3rem;">
            <div style="font-size:4rem;">💾</div>
            <p>جاري فتح نافذة حالة البيانات...</p>
            <button class="btn btn-primary" onclick="Persistence.showStatus()">فتح نافذة الحالة</button>
          </div>
        </div>
      `;
    },
    bind: () => {},
  },

  invoiceList: {
    title: 'سجل الفواتير',
    icon: '🧾',
    perm: PERMISSIONS.VIEW_DASHBOARD,
    render: InvoiceList.render,
    bind: InvoiceList.bindEvents,
  },

  settings: {
    title: 'الإعدادات',
    icon: '⚙️',
    perm: PERMISSIONS.SETTINGS_MANAGE,
    render: () => {
      const s = Settings.get();
      return `
        <div class="card">
          <div class="card-header">
            <h2>⚙️ إعدادات المتجر</h2>
          </div>
          <div class="card-body">
            <form id="settingsForm">
              <div class="form-group">
                <label>اسم المتجر</label>
                <input type="text" name="storeName" value="${escapeHtml(s.storeName)}" />
              </div>
              <div class="form-group">
                <label>رقم الهاتف</label>
                <input type="tel" name="storePhone" value="${escapeHtml(s.storePhone)}" />
              </div>
              <div class="form-group">
                <label>العنوان</label>
                <textarea name="storeAddress" rows="2">${escapeHtml(s.storeAddress)}</textarea>
              </div>
              <div class="grid grid-2">
                <div class="form-group">
                  <label>العملة</label>
                  <input type="text" name="currency" value="${escapeHtml(s.currency)}" />
                </div>
                <div class="form-group">
                  <label>تنبيه نقص المخزون (أقل من)</label>
                  <input type="number" name="lowStockAlert" min="0" value="${s.lowStockAlert}" />
                </div>
              </div>
              <button type="submit" class="btn btn-primary">حفظ الإعدادات</button>
            </form>
          </div>
        </div>

        <div class="card" style="margin-top:1.5rem;">
          <div class="card-header">
            <h2>💾 النسخ الاحتياطي</h2>
          </div>
          <div class="card-body">
            <p style="margin-bottom:1rem;">يمكنك تصدير جميع البيانات كملف JSON لاستعادتها لاحقًا، أو استيراد ملف نسخة احتياطية.</p>
            <div style="display:flex;gap:0.5rem;flex-wrap:wrap;">
              <button class="btn btn-success" id="exportDataBtn">📤 تصدير البيانات</button>
              <label class="btn btn-warning">
                📥 استيراد البيانات
                <input type="file" id="importDataInput" accept=".json" style="display:none;" />
              </label>
              <button class="btn btn-danger" id="clearDataBtn">🗑️ مسح كل البيانات</button>
            </div>
          </div>
        </div>
      `;
    },
    bind: () => {
      document.getElementById('settingsForm')?.addEventListener('submit', (e) => {
        e.preventDefault();
        const data = Object.fromEntries(new FormData(e.target));
        data.lowStockAlert = Number(data.lowStockAlert);
        Settings.set(data);
        toast('تم حفظ الإعدادات', 'success');
      });

      document.getElementById('exportDataBtn')?.addEventListener('click', () => {
        const data = {
          version: '1.0',
          exportedAt: new Date().toISOString(),
          users: Users.all(),
          products: Products.all(),
          customers: Customers.all(),
          sales: Sales.all(),
          purchases: Purchases.all(),
          debts: Debts.all(),
          settings: Settings.get(),
        };
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `pos-backup-${new Date().toISOString().slice(0, 10)}.json`;
        a.click();
        URL.revokeObjectURL(url);
        toast('تم تصدير البيانات', 'success');
      });

      document.getElementById('importDataInput')?.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (evt) => {
          try {
            const data = JSON.parse(evt.target.result);
            if (!confirm('سيتم استبدال جميع البيانات الحالية. هل أنت متأكد؟')) return;
            if (data.users) dbSet(DB_KEYS.USERS, data.users);
            if (data.products) dbSet(DB_KEYS.PRODUCTS, data.products);
            if (data.customers) dbSet(DB_KEYS.CUSTOMERS, data.customers);
            if (data.sales) dbSet(DB_KEYS.SALES, data.sales);
            if (data.purchases) dbSet(DB_KEYS.PURCHASES, data.purchases);
            if (data.debts) dbSet(DB_KEYS.DEBTS, data.debts);
            if (data.settings) dbSet(DB_KEYS.SETTINGS, data.settings);
            toast('تم استيراد البيانات بنجاح', 'success');
            setTimeout(() => location.reload(), 1000);
          } catch (err) {
            toast('ملف غير صالح', 'error');
          }
        };
        reader.readAsText(file);
      });

      document.getElementById('clearDataBtn')?.addEventListener('click', () => {
        if (!confirm('⚠️ سيتم مسح كل البيانات نهائيًا (المنتجات، المبيعات، العملاء...). هل أنت متأكد؟')) return;
        if (!confirm('تأكيد أخير: هذا الإجراء لا يمكن التراجع عنه!')) return;
        Object.values(DB_KEYS).forEach(k => localStorage.removeItem(k));
        toast('تم مسح كل البيانات', 'success');
        setTimeout(() => location.reload(), 1000);
      });
    },
  },
};

// ====== بناء القائمة الجانبية ======
function buildNavMenu() {
  const user = Auth.require();
  const menu = document.getElementById('navMenu');
  const allowedPages = Object.entries(PAGES).filter(([key, page]) =>
    Auth.hasPermission(user, page.perm)
  );

  menu.innerHTML = allowedPages.map(([key, page]) => `
    <button class="nav-item" data-page="${key}">
      <span class="nav-icon">${page.icon}</span>
      <span>${page.title}</span>
    </button>
  `).join('');

  menu.querySelectorAll('.nav-item').forEach(btn => {
    btn.addEventListener('click', () => navigateTo(btn.dataset.page));
  });
}

// ====== التنقل بين الصفحات ======
function navigateTo(pageKey) {
  const page = PAGES[pageKey];
  if (!page) return;
  const user = Auth.require();
  if (!Auth.hasPermission(user, page.perm)) {
    toast('ليس لديك صلاحية', 'error');
    return;
  }

  document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
  document.querySelector(`.nav-item[data-page="${pageKey}"]`)?.classList.add('active');
  document.getElementById('pageTitle').textContent = page.title;
  document.getElementById('pageContainer').innerHTML = page.render();

  // ربط أحداث التنبيهات عند وجودها
  Enhancements.bindAlertsEvents();

  if (page.after) page.after();
  if (page.bind) page.bind();

  // إغلاق الشريط الجانبي على الموبايل
  document.getElementById('sidebar')?.classList.remove('open');
  document.getElementById('sidebarOverlay')?.classList.remove('show');
  currentPage = pageKey;
}

let currentPage = 'dashboard';

// ====== تسجيل الدخول ======
// (تم نقل منطق تسجيل الدخول إلى login.html)

function showApp(user) {
  // إزالة الإخفاء (لـ body.gated) وإظهار التطبيق
  document.body.classList.remove('gated');
  const appEl = document.getElementById('app');
  if (appEl) appEl.classList.remove('hidden');

  // بيانات المستخدم
  document.getElementById('currentUserName').textContent = user.name;
  document.getElementById('currentUserRole').textContent = ROLES[user.role]?.name || user.role;
  document.getElementById('userAvatar').textContent = user.name.charAt(0);

  // التاريخ
  const todayEl = document.getElementById('todayDate');
  todayEl.textContent = new Date().toLocaleDateString('ar-EG', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

  updateBackupBadge();
  // تحديث الـ badge كل 30 ثانية
  setInterval(updateBackupBadge, 30000);

  // مزامنة Supabase التلقائية كل 30 ثانية
  if (typeof SupabaseSync !== 'undefined') {
    setInterval(() => {
      SupabaseSync.lightSync().then(() => updateBackupBadge());
    }, 30000);
  }

  buildNavMenu();
  navigateTo('dashboard');
}

function updateBackupBadge() {
  const badge = document.getElementById('backupStatusBadge');
  if (!badge) return;
  const last = (typeof SupabaseSync !== 'undefined' && SupabaseSync.lastSync) ? SupabaseSync.lastSync : localStorage.getItem('last_backup_time');
  const lastText = last ? new Date(last).toLocaleDateString('ar-EG', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : 'الآن';
  badge.className = 'backup-status-badge connected';
  badge.innerHTML = `<span class="dot"></span>☁️ مزامنة · ${lastText}`;
  badge.title = `آخر مزامنة: ${last ? new Date(last).toLocaleString('ar-EG') : 'الآن'} - اضغط للمزامنة الفورية`;
  badge.onclick = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (typeof SupabaseSync === 'undefined') {
      toast('المزامنة السحابية غير مفعّلة', 'error');
      return;
    }
    try {
      badge.innerHTML = `<span class="dot"></span>⏳ جاري المزامنة...`;
    } catch (_) {}
    try {
      await SupabaseSync.sync();
      toast('✅ تمت المزامنة بنجاح', 'success');
    } catch (err) {
      toast('❌ فشلت المزامنة: ' + (err.message || err), 'error');
    } finally {
      try { updateBackupBadge(); } catch (_) {}
    }
  };
}

function setupLogout() {
  document.getElementById('logoutBtn').addEventListener('click', () => {
    if (confirm('تسجيل الخروج؟')) {
      Auth.logout();
      window.location.href = 'login.html';
    }
  });
}

// ====== الشريط الجانبي على الموبايل ======
function setupMobileMenu() {
  const toggle = () => {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    sidebar.classList.toggle('open');
    overlay.classList.toggle('show');
  };
  const close = () => {
    document.getElementById('sidebar').classList.remove('open');
    document.getElementById('sidebarOverlay').classList.remove('show');
  };

  document.getElementById('menuToggle')?.addEventListener('click', toggle);
  document.getElementById('sidebarOverlay')?.addEventListener('click', close);
}

// ====== إغلاق المودال بالنقر خارجها أو بالـ ESC ======
function setupModalClose() {
  document.querySelectorAll('.modal').forEach(modal => {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        if (modal.id === 'scannerModal') Scanner.close();
        else modal.classList.remove('active');
      }
    });
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      if (Scanner.isOpen) Scanner.close();
      else document.querySelectorAll('.modal.active').forEach(m => m.classList.remove('active'));
    }
  });

  document.querySelectorAll('[data-close]').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.dataset.close;
      if (target === 'scannerModal') Scanner.close();
      else closeModal(target);
    });
  });
}

// ====== تسجيل Service Worker (PWA) ======
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  });
}

// ====== التشغيل ======
document.addEventListener('DOMContentLoaded', () => {
  // صفحة index.html محمية - لن نصل هنا إلا إذا كان المستخدم مسجّلاً
  // (التحقق يتم في البوابة أعلى index.html)
  setupLogout();
  setupMobileMenu();
  setupModalClose();

  // تهيئة التحسينات (الوضع الداكن + زر المزامنة + باقي)
  if (typeof Enhancements !== 'undefined' && Enhancements.init) {
    Enhancements.init();
  }

  const user = Auth.require();
  if (user) {
    showApp(user);
  } else {
    // احتياط - في حال تم العبث بالجلسة
    window.location.href = 'login.html';
  }
});
