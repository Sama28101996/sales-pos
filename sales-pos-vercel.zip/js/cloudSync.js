// =====================================================
// مزامنة المستخدمين عبر JSONBin.io (سحابة مجانية)
// =====================================================
// الخدمة: https://jsonbin.io
// - مجانية 100k requests/شهر
// - ما تحتاج حساب معقد
// - API بسيط: PUT/GET

const CloudSync = {
  // ====== الإعدادات ======
  // هذا الـ bin خاص بالتطبيق (سننشئه تلقائياً أول مرة)
  // عند أول تحميل، إذا الـ bin مو موجود، يُنشأ تلقائياً
  BIN_ID: localStorage.getItem('cloud_bin_id') || null,
  API_KEY: '$2b$10$wQHJ3ZQFvE.Yp4YqGLnENOeKqvV8jKKC9P2L2KQbqQTgRJz.LHhqi',  // Master key مجاني
  BASE_URL: 'https://api.jsonbin.io/v3/b',

  // ====== حالة المزامنة ======
  isSyncing: false,
  lastSync: localStorage.getItem('cloud_last_sync') || null,

  /**
   * رفع المستخدمين الحاليين إلى السحابة
   */
  uploadUsers: async () => {
    if (CloudSync.isSyncing) {
      return { ok: false, error: 'جاري المزامنة بالفعل' };
    }
    CloudSync.isSyncing = true;

    try {
      const users = Users.all();
      const payload = {
        users,
        updatedAt: new Date().toISOString(),
        version: 1,
      };

      let binId = CloudSync.BIN_ID;

      // إذا ما في bin_id، ننشئ bin جديد
      if (!binId) {
        const createRes = await fetch(CloudSync.BASE_URL, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Master-Key': CloudSync.API_KEY,
            'X-Bin-Name': 'pos_users_cloud',
            'X-Bin-Private': 'false',  // عام للقراءة بدون API key
          },
          body: JSON.stringify(payload),
        });

        if (!createRes.ok) {
          const err = await createRes.text();
          throw new Error('فشل إنشاء السحابة: ' + err);
        }

        const data = await createRes.json();
        binId = data.metadata.id;
        localStorage.setItem('cloud_bin_id', binId);
        CloudSync.BIN_ID = binId;
      } else {
        // تحديث bin موجود
        const updateRes = await fetch(`${CloudSync.BASE_URL}/${binId}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'X-Master-Key': CloudSync.API_KEY,
          },
          body: JSON.stringify(payload),
        });

        if (!updateRes.ok) {
          const err = await updateRes.text();
          throw new Error('فشل تحديث السحابة: ' + err);
        }
      }

      CloudSync.lastSync = new Date().toISOString();
      localStorage.setItem('cloud_last_sync', CloudSync.lastSync);

      return { ok: true, binId, count: users.length };
    } catch (err) {
      console.error('[CloudSync] Upload error:', err);
      return { ok: false, error: err.message };
    } finally {
      CloudSync.isSyncing = false;
    }
  },

  /**
   * تحميل المستخدمين من السحابة
   */
  downloadUsers: async () => {
    if (CloudSync.isSyncing) {
      return { ok: false, error: 'جاري المزامنة بالفعل' };
    }
    CloudSync.isSyncing = true;

    try {
      // أولاً نقرأ الـ bin_id المخزن محلياً
      let binId = CloudSync.BIN_ID;

      // إذا ما في، نحاول نبحث أو نستخدم طريقة ثابتة
      // في حالتنا، لو ما في bin_id = ما في بيانات سحابية
      if (!binId) {
        return { ok: false, error: 'لا توجد بيانات سحابية بعد' };
      }

      const res = await fetch(`${CloudSync.BASE_URL}/${binId}/latest`, {
        method: 'GET',
        headers: {
          'X-Master-Key': CloudSync.API_KEY,
        },
      });

      if (!res.ok) {
        if (res.status === 404) {
          return { ok: false, error: 'سحابة البيانات غير موجودة' };
        }
        const err = await res.text();
        throw new Error('فشل التحميل: ' + err);
      }

      const data = await res.json();
      const users = data.record?.users || [];

      if (users.length === 0) {
        return { ok: false, error: 'السحابة فارغة' };
      }

      // دمج المستخدمين مع المحلي (السحابة لها الأولوية للأعضاء الجدد)
      const localUsers = Users.all();
      const localIds = new Set(localUsers.map(u => u.id));
      const cloudIds = new Set(users.map(u => u.id));

      let added = 0, updated = 0;

      users.forEach(cloudUser => {
        if (!localIds.has(cloudUser.id)) {
          localUsers.push(cloudUser);
          added++;
        } else {
          // تحديث من السحابة (الاسم، الصلاحيات، الحالة)
          const idx = localUsers.findIndex(u => u.id === cloudUser.id);
          if (idx !== -1) {
            localUsers[idx] = { ...localUsers[idx], ...cloudUser };
            updated++;
          }
        }
      });

      dbSet(DB_KEYS.USERS, localUsers);

      CloudSync.lastSync = new Date().toISOString();
      localStorage.setItem('cloud_last_sync', CloudSync.lastSync);

      return { ok: true, count: users.length, added, updated };
    } catch (err) {
      console.error('[CloudSync] Download error:', err);
      return { ok: false, error: err.message };
    } finally {
      CloudSync.isSyncing = false;
    }
  },

  /**
   * مزامنة كاملة: رفع + تحميل (تأكيد ثنائي الاتجاه)
   */
  fullSync: async () => {
    // أولاً: نحمل من السحابة
    const download = await CloudSync.downloadUsers();
    // ثانياً: نرفع (لو عندنا أعضاء محليين غير موجودين)
    const upload = await CloudSync.uploadUsers();
    return { download, upload };
  },

  /**
   * حالة المزامنة (للعرض)
   */
  getStatus: () => {
    return {
      enabled: !!CloudSync.BIN_ID,
      isSyncing: CloudSync.isSyncing,
      lastSync: CloudSync.lastSync,
    };
  },

  /**
   * إعادة تعيين (حذف bin_id المحلي، نبدأ من جديد)
   */
  reset: () => {
    localStorage.removeItem('cloud_bin_id');
    localStorage.removeItem('cloud_last_sync');
    CloudSync.BIN_ID = null;
    CloudSync.lastSync = null;
  },
};
