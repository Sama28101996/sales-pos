// =====================================================
// إدارة العملاء
// =====================================================

const CustomersPage = {
  render: () => {
    const user = Auth.require();
    const canEdit = Auth.hasPermission(user, PERMISSIONS.CUSTOMERS_EDIT);
    return `
      <div class="card">
        <div class="card-header">
          <h2>👥 إدارة العملاء</h2>
          <div style="display:flex;gap:0.5rem;">
            <input type="text" id="customerSearch" placeholder="ابحث عن عميل..." style="max-width:280px;" />
            ${canEdit ? '<button class="btn btn-success" id="addCustomerBtn">➕ إضافة عميل</button>' : ''}
          </div>
        </div>
        <div class="card-body">
          <div class="table-wrap" id="customersTableWrap"></div>
        </div>
      </div>
    `;
  },

  renderTable: () => {
    const user = Auth.require();
    const canEdit = Auth.hasPermission(user, PERMISSIONS.CUSTOMERS_EDIT);
    const search = (document.getElementById('customerSearch')?.value || '').toLowerCase();

    const customers = Customers.all()
      .filter(c => !search || c.name.toLowerCase().includes(search) || (c.phone || '').includes(search))
      .sort((a, b) => (b.totalDebt - a.totalDebt));

    if (customers.length === 0) {
      return '<div class="empty-state"><div class="empty-icon">👥</div><p>لا يوجد عملاء. ابدأ بإضافة عميل جديد.</p></div>';
    }

    return `
      <table>
        <thead>
          <tr>
            <th>الاسم</th>
            <th>الهاتف</th>
            <th>العنوان</th>
            <th>إجمالي المشتريات</th>
            <th>الدين الحالي</th>
            <th>إجراءات</th>
          </tr>
        </thead>
        <tbody>
          ${customers.map(c => `
            <tr>
              <td><strong>${escapeHtml(c.name)}</strong></td>
              <td>${c.phone ? `<a href="tel:${c.phone}">${escapeHtml(c.phone)}</a>` : '—'}</td>
              <td>${c.address ? escapeHtml(c.address) : '—'}</td>
              <td><strong>${(c.totalPurchases || 0).toFixed(2)} $</strong></td>
              <td>${(c.totalDebt || 0) > 0 ? `<span class="badge badge-danger">${(c.totalDebt).toFixed(2)} د.ع</span>` : '<span class="badge badge-success">لا ديون</span>'}</td>
              <td class="actions-cell">
                <button class="btn btn-sm btn-ghost" data-action="view-customer" data-id="${c.id}" title="السجل">📊</button>
                ${(c.totalDebt || 0) > 0 ? `<button class="btn btn-sm btn-success" data-action="remind-customer" data-id="${c.id}" title="تذكير بدفع الدين">📅</button>` : ''}
                ${canEdit ? `
                  <button class="btn btn-sm btn-ghost" data-action="edit-customer" data-id="${c.id}">✏️</button>
                  <button class="btn btn-sm btn-ghost" data-action="delete-customer" data-id="${c.id}">🗑️</button>
                ` : ''}
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;
  },

  form: (customer = null) => {
    const c = customer || { name: '', phone: '', address: '' };
    return `
      <form id="customerForm">
        <div class="form-group">
          <label>اسم العميل *</label>
          <input type="text" name="name" value="${escapeHtml(c.name)}" required />
        </div>
        <div class="form-group">
          <label>رقم الهاتف</label>
          <input type="tel" name="phone" value="${escapeHtml(c.phone || '')}" />
        </div>
        <div class="form-group">
          <label>العنوان</label>
          <textarea name="address" rows="2">${escapeHtml(c.address || '')}</textarea>
        </div>
        <div class="modal-footer" style="padding-inline-start:0;">
          <button type="submit" class="btn btn-primary">${customer ? 'حفظ التعديلات' : 'إضافة العميل'}</button>
          <button type="button" class="btn btn-ghost" data-close="genericModal">إلغاء</button>
        </div>
      </form>
    `;
  },

  handleSubmit: (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target));
    if (!data.name.trim()) {
      toast('اسم العميل مطلوب', 'error');
      return;
    }

    if (e.target.dataset.editId) {
      Customers.update(e.target.dataset.editId, {
        name: data.name.trim(),
        phone: data.phone.trim(),
        address: data.address.trim(),
      });
      toast('تم تحديث العميل', 'success');
    } else {
      Customers.add({
        name: data.name.trim(),
        phone: data.phone.trim(),
        address: data.address.trim(),
      });
      toast('تم إضافة العميل', 'success');
    }
    closeModal('genericModal');
    CustomersPage.refresh();
  },

  showHistory: (customer) => {
    const sales = Sales.all().filter(s => s.customerId === customer.id).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    const debts = Debts.byCustomer(customer.id);

    const content = `
      <div style="margin-bottom:1rem;">
        <h3 style="margin-bottom:0.5rem;">${escapeHtml(customer.name)}</h3>
        <p><strong>الهاتف:</strong> د.ع{customer.phone || '—'}</p>
        <p><strong>العنوان:</strong> د.ع{customer.address || '—'}</p>
        <div style="display:flex;gap:1rem;margin-top:1rem;">
          <div style="flex:1;padding:1rem;background:var(--success-light);border-radius:8px;">
            <div style="color:var(--success);font-size:0.85rem;">إجمالي المشتريات</div>
            <div style="font-size:1.3rem;font-weight:700;color:var(--success);">${(customer.totalPurchases || 0).toFixed(2)} $</div>
          </div>
          <div style="flex:1;padding:1rem;background:var(--danger-light);border-radius:8px;">
            <div style="color:var(--danger);font-size:0.85rem;">الدين الحالي</div>
            <div style="font-size:1.3rem;font-weight:700;color:var(--danger);">${(customer.totalDebt || 0).toFixed(2)} $</div>
          </div>
        </div>
      </div>

      <h4 style="margin-top:1.5rem;margin-bottom:0.5rem;">📋 سجل المعاملات (${sales.length})</h4>
      ${sales.length === 0 ? '<p style="color:var(--text-muted);">لا توجد معاملات</p>' : `
        <div class="table-wrap" style="max-height:300px;overflow-y:auto;">
          <table>
            <thead>
              <tr>
                <th>الفاتورة</th>
                <th>التاريخ</th>
                <th>النوع</th>
                <th>الإجمالي</th>
              </tr>
            </thead>
            <tbody>
              ${sales.map(s => `
                <tr>
                  <td>${s.invoiceNo}</td>
                  <td>${new Date(s.createdAt).toLocaleDateString('ar-EG')}</td>
                  <td>${s.type === 'cash' ? 'نقدي' : 'آجل'}</td>
                  <td>${s.total.toFixed(2)} $</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      `}
    `;
    openModal('سجل العميل', content);
  },

  bindEvents: () => {
    document.getElementById('customerSearch')?.addEventListener('input', () => {
      const wrap = document.getElementById('customersTableWrap');
      if (wrap) wrap.innerHTML = CustomersPage.renderTable();
    });

    document.getElementById('addCustomerBtn')?.addEventListener('click', () => {
      openModal('إضافة عميل جديد', CustomersPage.form());
      document.getElementById('customerForm').addEventListener('submit', CustomersPage.handleSubmit);
    });

    document.getElementById('customersTableWrap')?.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-action]');
      if (!btn) return;
      const action = btn.dataset.action;
      const id = btn.dataset.id;
      const customer = Customers.find(id);
      if (!customer) return;

      if (action === 'view-customer') {
        CustomersPage.showHistory(customer);
      } else if (action === 'remind-customer') {
        DebtReminders.showReminderDialog(customer);
        customer.lastReminder = new Date().toISOString();
        Customers.update(customer.id, customer);
      } else if (action === 'edit-customer') {
        openModal('تعديل العميل', CustomersPage.form(customer));
        const form = document.getElementById('customerForm');
        form.dataset.editId = id;
        form.addEventListener('submit', CustomersPage.handleSubmit);
      } else if (action === 'delete-customer') {
        if (confirm(`حذف العميل "${customer.name}"؟`)) {
          Customers.remove(id);
          toast('تم الحذف', 'success');
          CustomersPage.refresh();
        }
      }
    });
  },

  refresh: () => {
    const wrap = document.getElementById('customersTableWrap');
    if (wrap) wrap.innerHTML = CustomersPage.renderTable();
  },
};

// =====================================================
// سجل الديون
// =====================================================
const DebtsPage = {
  render: () => {
    return `
      <div class="card">
        <div class="card-header">
          <h2>💰 سجل الديون</h2>
          <div style="display:flex;gap:0.5rem;">
            <select id="debtStatusFilter">
              <option value="unpaid">غير المسددة</option>
              <option value="paid">المسددة</option>
              <option value="all">الكل</option>
            </select>
          </div>
        </div>
        <div class="card-body">
          <div class="table-wrap" id="debtsTableWrap"></div>
        </div>
      </div>
    `;
  },

  renderTable: () => {
    const filter = document.getElementById('debtStatusFilter')?.value || 'unpaid';
    let debts = Debts.all().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    if (filter === 'unpaid') debts = debts.filter(d => d.remainingAmount > 0);
    else if (filter === 'paid') debts = debts.filter(d => d.remainingAmount === 0);

    const totalRemaining = Debts.all().filter(d => d.remainingAmount > 0).reduce((s, d) => s + d.remainingAmount, 0);

    if (debts.length === 0) {
      return `
        <div style="background:var(--primary-light);padding:1rem;border-radius:8px;margin-bottom:1rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:0.5rem;">
          <strong>إجمالي الديون المعلقة:</strong>
          <span style="font-size:1.3rem;font-weight:700;color:var(--danger);">${totalRemaining.toFixed(2)} د.ع</span>
        </div>
        <div class="empty-state"><div class="empty-icon">✅</div><p>لا توجد ديون ${filter === 'unpaid' ? 'معلقة' : ''}</p></div>
      `;
    }

    return `
      <div style="background:var(--primary-light);padding:1rem;border-radius:8px;margin-bottom:1rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:0.5rem;">
        <strong>إجمالي الديون المعلقة:</strong>
        <span style="font-size:1.3rem;font-weight:700;color:var(--danger);">${totalRemaining.toFixed(2)} د.ع</span>
      </div>
      <table>
        <thead>
          <tr>
            <th>التاريخ</th>
            <th>الفاتورة</th>
            <th>العميل</th>
            <th>المبلغ الأصلي</th>
            <th>المدفوع</th>
            <th>المتبقي</th>
            <th>الحالة</th>
            <th>إجراءات</th>
          </tr>
        </thead>
        <tbody>
          ${debts.map(d => `
            <tr>
              <td>${new Date(d.createdAt).toLocaleDateString('ar-EG')}</td>
              <td><strong>${d.invoiceNo || '—'}</strong></td>
              <td>${escapeHtml(d.customerName)}</td>
              <td>${d.amount.toFixed(2)} $</td>
              <td style="color:var(--success);">${(d.paidAmount || 0).toFixed(2)} $</td>
              <td>${d.remainingAmount > 0 ? `<strong style="color:var(--danger);">${d.remainingAmount.toFixed(2)} $</strong>` : '<span class="badge badge-success">مسدد</span>'}</td>
              <td>${d.remainingAmount > 0 ? '<span class="badge badge-warning">معلق</span>' : '<span class="badge badge-success">مسدد</span>'}</td>
              <td class="actions-cell">
                ${d.remainingAmount > 0 ? `<button class="btn btn-sm btn-success" data-action="pay-debt" data-id="${d.id}">💵 تحصيل</button>` : ''}
                <button class="btn btn-sm btn-ghost" data-action="view-debt" data-id="${d.id}">👁️</button>
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;
  },

  showPayForm: (debt) => {
    const content = `
      <div style="background:var(--bg);padding:1rem;border-radius:8px;margin-bottom:1rem;">
        <p><strong>العميل:</strong> د.ع{escapeHtml(debt.customerName)}</p>
        <p><strong>فاتورة:</strong> د.ع{debt.invoiceNo}</p>
        <p><strong>المتبقي:</strong> <span style="color:var(--danger);font-weight:700;">${debt.remainingAmount.toFixed(2)} د.ع</span></p>
      </div>
      <form id="payDebtForm">
        <div class="form-group">
          <label>مبلغ التحصيل *</label>
          <input type="number" name="amount" min="0.01" max="${debt.remainingAmount}" step="0.01" value="${debt.remainingAmount.toFixed(2)}" required />
        </div>
        <div class="form-group">
          <label>ملاحظات (اختياري)</label>
          <input type="text" name="note" placeholder="مثال: دفعة جزئية" />
        </div>
        <div class="modal-footer" style="padding-inline-start:0;">
          <button type="submit" class="btn btn-success">تأكيد التحصيل</button>
          <button type="button" class="btn btn-ghost" data-close="genericModal">إلغاء</button>
        </div>
      </form>
    `;
    openModal('تحصيل دين', content);

    document.getElementById('payDebtForm').addEventListener('submit', (e) => {
      e.preventDefault();
      const amount = Number(e.target.amount.value);
      const note = e.target.note.value;

      if (amount <= 0 || amount > debt.remainingAmount) {
        toast('قيمة غير صحيحة', 'error');
        return;
      }

      // تحديث الدين
      const newPaid = (debt.paidAmount || 0) + amount;
      const newRemaining = debt.remainingAmount - amount;
      const payments = debt.payments || [];
      payments.push({ amount, date: new Date().toISOString(), note });

      Debts.update(debt.id, {
        paidAmount: newPaid,
        remainingAmount: newRemaining,
        status: newRemaining <= 0 ? 'paid' : 'partial',
        payments,
      });

      // تحديث الفاتورة
      if (debt.saleId) {
        const sale = Sales.find(debt.saleId);
        if (sale) {
          const saleNewPaid = (sale.paidAmount || 0) + amount;
          const saleNewRemaining = sale.total - saleNewPaid;
          // تحديث الفاتورة
          const allSales = Sales.all();
          const idx = allSales.findIndex(s => s.id === sale.id);
          if (idx !== -1) {
            allSales[idx].paidAmount = saleNewPaid;
            allSales[idx].remainingAmount = saleNewRemaining;
            allSales[idx].status = saleNewRemaining <= 0 ? 'paid' : 'partial';
            dbSet(DB_KEYS.SALES, allSales);
          }
        }
      }

      // تحديث إجمالي ديون العميل
      const customer = Customers.find(debt.customerId);
      if (customer) {
        const allDebts = Debts.byCustomer(customer.id);
        const totalDebt = allDebts.reduce((s, d) => s + d.remainingAmount, 0);
        Customers.update(customer.id, { totalDebt });
      }

      toast(`تم تحصيل ${amount.toFixed(2)} $ بنجاح`, 'success');
      closeModal('genericModal');
      DebtsPage.refresh();
    });
  },

  viewDebt: (debt) => {
    const content = `
      <p><strong>العميل:</strong> د.ع{escapeHtml(debt.customerName)}</p>
      <p><strong>فاتورة:</strong> د.ع{debt.invoiceNo || '—'}</p>
      <p><strong>التاريخ:</strong> د.ع{new Date(debt.createdAt).toLocaleString('ar-EG')}</p>
      <p><strong>المبلغ الأصلي:</strong> د.ع{debt.amount.toFixed(2)} $</p>
      <p><strong>المدفوع:</strong> د.ع{(debt.paidAmount || 0).toFixed(2)} $</p>
      <p><strong>المتبقي:</strong> د.ع{debt.remainingAmount.toFixed(2)} $</p>
      ${debt.payments && debt.payments.length > 0 ? `
        <h4 style="margin-top:1rem;margin-bottom:0.5rem;">سجل الدفعات (${debt.payments.length})</h4>
        <ul style="list-style:none;padding:0;">
          ${debt.payments.map(p => `
            <li style="padding:0.5rem;border-bottom:1px solid var(--border);">
              ${p.amount.toFixed(2)} $ — ${new Date(p.date).toLocaleString('ar-EG')} ${p.note ? `<small>(${escapeHtml(p.note)})</small>` : ''}
            </li>
          `).join('')}
        </ul>
      ` : ''}
    `;
    openModal('تفاصيل الدين', content);
  },

  bindEvents: () => {
    document.getElementById('debtStatusFilter')?.addEventListener('change', () => {
      const wrap = document.getElementById('debtsTableWrap');
      if (wrap) wrap.innerHTML = DebtsPage.renderTable();
    });

    document.getElementById('debtsTableWrap')?.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-action]');
      if (!btn) return;
      const debt = Debts.all().find(d => d.id === btn.dataset.id);
      if (!debt) return;

      if (btn.dataset.action === 'pay-debt') DebtsPage.showPayForm(debt);
      else if (btn.dataset.action === 'view-debt') DebtsPage.viewDebt(debt);
    });
  },

  refresh: () => {
    const wrap = document.getElementById('debtsTableWrap');
    if (wrap) wrap.innerHTML = DebtsPage.renderTable();
  },
};
