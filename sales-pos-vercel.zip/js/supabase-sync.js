// =====================================================
// مزامنة Supabase - يخلي كل البيانات تتزامن بين كل الأجهزة
// =====================================================

const SUPABASE_URL = 'https://bwjsgsaioryotpzaletr.supabase.co';
const SUPABASE_KEY = 'sb_publishable_OMaiYCOZ_3lJX6-TM_4MDA_cyRGS1QB';

// خريطة الجداول: localStorage key -> Supabase table
const TABLE_MAP = {
  PRODUCTS: { local: 'pos_products', remote: 'products' },
  CUSTOMERS: { local: 'pos_customers', remote: 'customers' },
  SALES: { local: 'pos_sales', remote: 'sales' },
  USERS: { local: 'pos_users', remote: 'users' },
  SUPPLIERS: { local: 'pos_suppliers', remote: 'suppliers' },
  PURCHASES: { local: 'pos_purchases', remote: 'purchases' },
  DEBTS: { local: 'pos_debts', remote: 'debts' },
  SETTINGS: { local: 'pos_settings', remote: 'settings' },
};

const SupabaseSync = {
  online: navigator.onLine,
  syncing: false,
  lastSync: null,

  // دالة مساعدة للتعامل مع Supabase REST API
  async api(table, method = 'GET', body = null) {
    const url = `${SUPABASE_URL}/rest/v1/${table}`;
    const headers = {
      'apikey': SUPABASE_KEY,
      'Authorization': `Bearer ${SUPABASE_KEY}`,
      'Content-Type': 'application/json',
      'Prefer': method === 'POST' ? 'return=representation' : 'return=minimal',
    };
    const opts = { method, headers };
    if (body) opts.body = JSON.stringify(body);
    try {
      const res = await fetch(url, opts);
      if (!res.ok) {
        console.error(`[SupabaseSync] ${method} ${table} failed:`, res.status, await res.text());
        return null;
      }
      if (method === 'GET') return res.json();
      if (method === 'POST' || method === 'PATCH') return res.json();
      return true;
    } catch (e) {
      console.error(`[SupabaseSync] network error:`, e);
      return null;
    }
  },

  // رفع كل البيانات المحلية إلى Supabase (push)
  async pushAll() {
    if (this.syncing) return;
    this.syncing = true;
    try {
      for (const [key, map] of Object.entries(TABLE_MAP)) {
        const localData = dbGet(map.local, []);
        if (!Array.isArray(localData) || localData.length === 0) continue;
        // حذف القديم وإدراج الجديد (full sync)
        await this.api(map.remote, 'DELETE', {});
        // إدراج بالدفعات
        const batchSize = 50;
        for (let i = 0; i < localData.length; i += batchSize) {
          const batch = localData.slice(i, i + batchSize);
          // تنظيف البيانات - تحويل undefined إلى null
          const cleanBatch = batch.map(item => {
            const cleaned = {};
            for (const [k, v] of Object.entries(item)) {
              cleaned[k] = v === undefined ? null : v;
            }
            return cleaned;
          });
          await this.api(map.remote, 'POST', cleanBatch);
        }
        console.log(`[SupabaseSync] pushed ${localData.length} items to ${map.remote}`);
      }
      this.lastSync = new Date().toISOString();
      console.log('[SupabaseSync] push complete');
    } catch (e) {
      console.error('[SupabaseSync] push error:', e);
    } finally {
      this.syncing = false;
    }
  },

  // جلب كل البيانات من Supabase وحفظها محلياً (pull)
  async pullAll() {
    if (this.syncing) return;
    this.syncing = true;
    try {
      for (const [key, map] of Object.entries(TABLE_MAP)) {
        const remoteData = await this.api(map.remote, 'GET');
        if (remoteData === null) continue;
        if (Array.isArray(remoteData) && remoteData.length > 0) {
          // تنظيف البيانات (تحويل ISO date strings إلى arrays/json)
          const cleanData = remoteData.map(item => {
            const cleaned = {};
            for (const [k, v] of Object.entries(item)) {
              if (typeof v === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(v)) {
                cleaned[k] = v; // ISO date
              } else {
                cleaned[k] = v;
              }
            }
            return cleaned;
          });
          dbSet(map.local, cleanData);
          console.log(`[SupabaseSync] pulled ${cleanData.length} items from ${map.remote}`);
        } else if (Array.isArray(remoteData) && remoteData.length === 0) {
          // لا توجد بيانات عن بُعد - لا نمسح المحلي
          console.log(`[SupabaseSync] no remote data for ${map.remote}, keeping local`);
        }
      }
      this.lastSync = new Date().toISOString();
      console.log('[SupabaseSync] pull complete');
    } catch (e) {
      console.error('[SupabaseSync] pull error:', e);
    } finally {
      this.syncing = false;
    }
  },

  // مزامنة كاملة: رفع ثم جلب ثم تحديث الواجهة
  async sync() {
    if (!this.online) {
      console.log('[SupabaseSync] offline - skipping sync');
      return;
    }
    console.log('[SupabaseSync] starting full sync...');
    // رفع المحلي أولاً
    await this.pushAll();
    // جلب البعيد
    await this.pullAll();
    // إعادة تحميل الواجهة
    if (typeof refreshAllPages === 'function') {
      refreshAllPages();
    } else {
      location.reload();
    }
  },

  // مزامنة خفيفة (كل 30 ثانية) - فقط الجلب
  async lightSync() {
    if (!this.online) return;
    if (this.syncing) return;
    try {
      for (const [key, map] of Object.entries(TABLE_MAP)) {
        const remoteData = await this.api(map.remote, 'GET');
        if (Array.isArray(remoteData) && remoteData.length > 0) {
          const localData = dbGet(map.local, []);
          // مقارنة: لو البعيد أحدث، نحدّث المحلي
          if (remoteData.length !== localData.length) {
            dbSet(map.local, remoteData);
            console.log(`[SupabaseSync] updated ${map.local} (${remoteData.length} items)`);
          }
        }
      }
      this.lastSync = new Date().toISOString();
    } catch (e) {
      console.error('[SupabaseSync] light sync error:', e);
    }
  },

  // إضافة/تعديل سجل محلياً ودفعه للسحابة
  async saveAndSync(localKey, item) {
    // تحديث محلي أولاً
    const items = dbGet(localKey, []);
    const idx = items.findIndex(i => i.id === item.id);
    if (idx >= 0) {
      items[idx] = { ...items[idx], ...item };
    } else {
      items.push(item);
    }
    dbSet(localKey, items);
    // دفع للسحابة
    if (this.online) {
      const map = Object.values(TABLE_MAP).find(m => m.local === localKey);
      if (map) {
        // تنظيف
        const cleanItem = {};
        for (const [k, v] of Object.entries(item)) {
          cleanItem[k] = v === undefined ? null : v;
        }
        // محاولة INSERT
        const result = await this.api(map.remote, 'POST', cleanItem);
        if (result === null) {
          // فشل INSERT، نحاول UPDATE
          await this.api(`${map.remote}?id=eq.${item.id}`, 'PATCH', cleanItem);
        }
      }
    }
  },

  // حذف سجل محلياً ومن السحابة
  async deleteAndSync(localKey, id) {
    const items = dbGet(localKey, []);
    dbSet(localKey, items.filter(i => i.id !== id));
    if (this.online) {
      const map = Object.values(TABLE_MAP).find(m => m.local === localKey);
      if (map) {
        await this.api(`${map.remote}?id=eq.${id}`, 'DELETE');
      }
    }
  },

  // بدء المزامنة التلقائية
  startAutoSync() {
    // مزامنة كاملة عند البدء
    this.sync();
    // مزامنة خفيفة كل 30 ثانية
    setInterval(() => this.lightSync(), 30000);
    // مزامنة لما يرجع النت
    window.addEventListener('online', () => {
      this.online = true;
      this.sync();
    });
    window.addEventListener('offline', () => {
      this.online = false;
    });
  },
};

// دالة مساعدة لتحديث كل الصفحات بعد المزامنة
function refreshAllPages() {
  if (typeof Inventory !== 'undefined' && Inventory.refresh) Inventory.refresh();
  if (typeof SalesPage !== 'undefined' && SalesPage.renderCart) SalesPage.renderCart();
  if (typeof CustomersPage !== 'undefined' && CustomersPage.refresh) CustomersPage.refresh();
  if (typeof DebtsPage !== 'undefined' && DebtsPage.refresh) DebtsPage.refresh();
  if (typeof SalesHistory !== 'undefined' && SalesHistory.render) SalesHistory.render();
  if (typeof TeamPage !== 'undefined' && TeamPage.refresh) TeamPage.refresh();
  if (typeof Reports !== 'undefined' && Reports.afterRender) Reports.afterRender();
  // أعد تحميل الـ dashboard
  if (typeof location !== 'undefined') {
    const hash = location.hash;
    if (hash && hash.includes('dashboard')) location.reload();
  }
}

// عند تحميل الصفحة - بدء المزامنة التلقائية
document.addEventListener('DOMContentLoaded', () => {
  setTimeout(() => {
    SupabaseSync.startAutoSync();
    // إشعار بسيط
    if (typeof toast === 'function') {
      console.log('[SupabaseSync] مزامنة سحابية مفعّلة ☁️');
    }
  }, 2000);
});
