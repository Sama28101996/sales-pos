// =====================================================
// إدارة المخزون والمنتجات
// =====================================================

const Inventory = {
  _activeTab: 'all', // all | top-selling | top-profit | low-stock | top-priced

  render: () => {
    const user = Auth.require();
    const canEdit = Auth.hasPermission(user, PERMISSIONS.INVENTORY_EDIT);

    return `
      <div class="card">
        <div class="card-header">
          <h2>📦 إدارة المخزون</h2>
          <div style="display:flex;gap:0.5rem;flex-wrap:wrap;">
            <input type="text" id="invSearch" placeholder="ابحث بالاسم أو الباركود..." style="max-width:280px;" />
            <select id="invCategoryFilter">
              <option value="">كل الفئات</option>
              ${Inventory._categories().map(c => `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('')}
            </select>
            <button class="btn btn-primary" id="scanBarcodeBtn">📷 سكان باركود</button>
            ${canEdit ? '<button class="btn btn-success" id="addProductBtn">➕ إضافة منتج</button>' : ''}
          </div>
        </div>
        <div class="card-body">
          <!-- تبويبات التحليل -->
          <div class="inv-tabs" id="invTabs">
            <button class="inv-tab ${Inventory._activeTab === 'all' ? 'active' : ''}" data-tab="all">📋 كل المنتجات</button>
            <button class="inv-tab ${Inventory._activeTab === 'top-selling' ? 'active' : ''}" data-tab="top-selling">📈 الأكثر مبيعاً</button>
            <button class="inv-tab ${Inventory._activeTab === 'top-profit' ? 'active' : ''}" data-tab="top-profit">💰 الأكثر ربحاً</button>
            <button class="inv-tab ${Inventory._activeTab === 'top-priced' ? 'active' : ''}" data-tab="top-priced">💎 الأغلى سعراً</button>
            <button class="inv-tab ${Inventory._activeTab === 'low-stock' ? 'active' : ''}" data-tab="low-stock">📉 الأقل عدداً</button>
          </div>
          <div class="table-wrap" id="inventoryTableWrap"></div>
        </div>
      </div>
    `;
  },

  _categories: () => {
    const cats = new Set();
    Products.all().forEach(p => p.category && cats.add(p.category));
    return Array.from(cats);
  },

  renderTable: () => {
    const search = (document.getElementById('invSearch')?.value || '').toLowerCase();
    const cat = document.getElementById('invCategoryFilter')?.value || '';
    const user = Auth.require();
    const canEdit = Auth.hasPermission(user, PERMISSIONS.INVENTORY_EDIT);
    const lowStockAlert = Settings.get().lowStockAlert || 5;
    const tab = Inventory._activeTab;

    let products = Products.all().filter(p => {
      const matchSearch = !search || p.name.toLowerCase().includes(search) || p.barcode.includes(search);
      const matchCat = !cat || p.category === cat;
      return matchSearch && matchCat;
    });

    // ============= التبويبات التحليلية =============
    if (tab === 'top-selling' || tab === 'top-profit') {
      // نحسب من المبيعات الفعلية (كم مرة بيع + كم ربح)
      const salesStats = {};
      Sales.all().forEach(s => {
        (s.items || []).forEach(item => {
          if (!salesStats[item.productId]) {
            salesStats[item.productId] = { qtySold: 0, revenue: 0, profit: 0 };
          }
          salesStats[item.productId].qtySold += Number(item.qty) || 0;
          salesStats[item.productId].revenue += Number(item.subtotal) || 0;
          salesStats[item.productId].profit += (Number(item.subtotal) || 0) - (Number(item.cost) * Number(item.qty) || 0);
        });
      });

      products = products.map(p => {
        const st = salesStats[p.id] || { qtySold: 0, revenue: 0, profit: 0 };
        return { ...p, _qtySold: st.qtySold, _revenue: st.revenue, _profit: st.profit };
      });

      if (tab === 'top-selling') {
        products = products.sort((a, b) => b._qtySold - a._qtySold).slice(0, 50);
      } else {
        products = products.sort((a, b) => b._profit - a._profit).slice(0, 50);
      }
    } else if (tab === 'top-priced') {
      // الأغلى سعراً (أعلى سعر بيع)
      products = products.sort((a, b) => b.price - a.price).slice(0, 50);
    } else if (tab === 'low-stock') {
      // الأقل عدداً (اللي قارب يخلص)
      products = products
        .filter(p => p.stock <= lowStockAlert)
        .sort((a, b) => a.stock - b.stock);
    }

    // ============= رسائل خاصة بكل تبويب =============
    if (products.length === 0) {
      let msg = 'لا توجد منتجات.';
      if (tab === 'top-selling') msg = 'لا توجد مبيعات بعد — ابدأ بعمليات بيع من نقطة البيع';
      else if (tab === 'top-profit') msg = 'لا توجد مبيعات بعد';
      else if (tab === 'top-priced') msg = 'لا توجد منتجات بعد';
      else if (tab === 'low-stock') msg = `✅ ممتاز! كل المنتجات فوق حد التنبيه (${lowStockAlert} وحدة)`;
      return `<div class="empty-state"><div class="empty-icon">📦</div><p>${msg}</p></div>`;
    }

    // ============= رؤوس الأعمدة حسب التبويب =============
    let headerRow = '';
    if (tab === 'top-selling') {
      headerRow = `
        <tr>
          <th>#</th>
          <th>المنتج</th>
          <th>الفئة</th>
          <th>الكمية المباعة</th>
          <th>الإيرادات</th>
          <th>المخزون الحالي</th>
          ${canEdit ? '<th>إجراءات</th>' : ''}
        </tr>`;
    } else if (tab === 'top-profit') {
      headerRow = `
        <tr>
          <th>#</th>
          <th>المنتج</th>
          <th>الفئة</th>
          <th>الربح الكلي</th>
          <th>الإيرادات</th>
          <th>الكمية المباعة</th>
          ${canEdit ? '<th>إجراءات</th>' : ''}
        </tr>`;
    } else if (tab === 'top-priced') {
      headerRow = `
        <tr>
          <th>#</th>
          <th>المنتج</th>
          <th>الفئة</th>
          <th>سعر البيع</th>
          <th>التكلفة</th>
          <th>هامش الربح</th>
          <th>المخزون</th>
          ${canEdit ? '<th>إجراءات</th>' : ''}
        </tr>`;
    } else if (tab === 'low-stock') {
      headerRow = `
        <tr>
          <th>#</th>
          <th>المنتج</th>
          <th>الفئة</th>
          <th>التكلفة</th>
          <th>السعر</th>
          <th>المخزون</th>
          <th>الحالة</th>
          ${canEdit ? '<th>إجراءات</th>' : ''}
        </tr>`;
    } else {
      headerRow = `
        <tr>
          <th>الباركود</th>
          <th>الصورة</th>
          <th>المنتج</th>
          <th>الفئة</th>
          <th>التكلفة</th>
          <th>السعر</th>
          <th>الربح</th>
          <th>المخزون</th>
          <th>الحالة</th>
          ${canEdit ? '<th>إجراءات</th>' : ''}
        </tr>`;
    }

    // ============= الصفوف حسب التبويب =============
    const rows = products.map((p, idx) => {
      const profit = (p.price - p.cost).toFixed(2);
      const profitPct = p.cost > 0 ? ((p.price - p.cost) / p.cost * 100).toFixed(0) : 0;
      const isLow = p.stock <= lowStockAlert;
      const isOut = p.stock <= 0;
      const rank = idx + 1;
      const rankBadge = rank <= 3 ? `<span style="background:#fbbf24;color:#fff;padding:1px 6px;border-radius:4px;font-size:0.75rem;font-weight:700;margin-inline-end:4px;">${rank === 1 ? '🥇' : rank === 2 ? '🥈' : '🥉'}</span>` : `<span style="color:var(--text-muted);">#${rank}</span>`;

      if (tab === 'top-selling') {
        return `
          <tr>
            <td>${rankBadge}</td>
            <td><strong>${escapeHtml(p.name)}</strong></td>
            <td>${p.category ? `<span class="badge badge-info">${escapeHtml(p.category)}</span>` : '—'}</td>
            <td><strong style="color:var(--primary);">${p._qtySold}</strong> وحدة</td>
            <td><strong>${p._revenue.toFixed(2)} $</strong></td>
            <td>${p.stock} وحدة</td>
            ${canEdit ? `
              <td class="actions-cell">
                <button class="btn btn-sm btn-ghost" data-action="edit-product" data-id="${p.id}">✏️</button>
                <button class="btn btn-sm btn-ghost" data-action="delete-product" data-id="${p.id}">🗑️</button>
              </td>` : ''}
          </tr>`;
      } else if (tab === 'top-profit') {
        return `
          <tr>
            <td>${rankBadge}</td>
            <td><strong>${escapeHtml(p.name)}</strong></td>
            <td>${p.category ? `<span class="badge badge-info">${escapeHtml(p.category)}</span>` : '—'}</td>
            <td><strong style="color:var(--success);">+${p._profit.toFixed(2)} $</strong></td>
            <td>${p._revenue.toFixed(2)} $</td>
            <td>${p._qtySold} وحدة</td>
            ${canEdit ? `
              <td class="actions-cell">
                <button class="btn btn-sm btn-ghost" data-action="edit-product" data-id="${p.id}">✏️</button>
                <button class="btn btn-sm btn-ghost" data-action="delete-product" data-id="${p.id}">🗑️</button>
              </td>` : ''}
          </tr>`;
      } else if (tab === 'top-priced') {
        const margin = p.cost > 0 ? ((p.price - p.cost) / p.cost * 100).toFixed(0) : 0;
        return `
          <tr>
            <td>${rankBadge}</td>
            <td><strong>${escapeHtml(p.name)}</strong></td>
            <td>${p.category ? `<span class="badge badge-info">${escapeHtml(p.category)}</span>` : '—'}</td>
            <td><strong style="color:var(--primary);font-size:1.05rem;">${p.price.toFixed(2)} $</strong></td>
            <td>${p.cost.toFixed(2)} $</td>
            <td style="color:var(--success);">+${(p.price - p.cost).toFixed(2)} $ (${margin}%)</td>
            <td>${p.stock} وحدة</td>
            ${canEdit ? `
              <td class="actions-cell">
                <button class="btn btn-sm btn-ghost" data-action="edit-product" data-id="${p.id}">✏️</button>
                <button class="btn btn-sm btn-ghost" data-action="delete-product" data-id="${p.id}">🗑️</button>
              </td>` : ''}
          </tr>`;
      } else if (tab === 'low-stock') {
        return `
          <tr>
            <td>${idx + 1}</td>
            <td><strong>${escapeHtml(p.name)}</strong></td>
            <td>${p.category ? `<span class="badge badge-info">${escapeHtml(p.category)}</span>` : '—'}</td>
            <td>${p.cost.toFixed(2)} $</td>
            <td><strong>${p.price.toFixed(2)} $</strong></td>
            <td><strong style="color:${isOut ? 'var(--danger)' : 'var(--warning)'};">${p.stock}</strong></td>
            <td>${isOut ? '<span class="badge badge-danger">نفد</span>' : '<span class="badge badge-warning">منخفض</span>'}</td>
            ${canEdit ? `
              <td class="actions-cell">
                <button class="btn btn-sm btn-ghost" data-action="edit-product" data-id="${p.id}">✏️</button>
                <button class="btn btn-sm btn-ghost" data-action="delete-product" data-id="${p.id}">🗑️</button>
              </td>` : ''}
          </tr>`;
      } else {
        // التبويب الافتراضي: كل المنتجات
        const allBcs = Products.getAllBarcodes(p);
        const extrasCount = Math.max(0, allBcs.length - 1);
        return `
          <tr>
            <td>
              <code style="background:var(--bg);padding:2px 6px;border-radius:4px;font-size:0.8rem;">${escapeHtml(p.barcode)}</code>
              ${extrasCount > 0 ? `<div style="margin-top:3px;"><span style="background:#2563eb;color:#fff;padding:1px 6px;border-radius:4px;font-size:0.7rem;">+${extrasCount} إضافي</span></div>` : ''}
            </td>
            <td>
              ${p.image
                ? `<img src="${p.image}" class="product-thumb product-thumb-medium" alt="${escapeHtml(p.name)}" />`
                : `<div class="product-thumb product-thumb-medium" style="display:flex;align-items:center;justify-content:center;font-size:1.5rem;background:var(--bg);">📦</div>`
              }
            </td>
            <td><strong>${escapeHtml(p.name)}</strong></td>
            <td>${p.category ? `<span class="badge badge-info">${escapeHtml(p.category)}</span>` : '—'}</td>
            <td>${p.cost.toFixed(2)} $</td>
            <td><strong>${p.price.toFixed(2)} $</strong></td>
            <td style="color:var(--success)">+${profit} $ <small>(${profitPct}%)</small></td>
            <td><strong>${p.stock}</strong></td>
            <td>${isOut ? '<span class="badge badge-danger">نفد</span>' : isLow ? '<span class="badge badge-warning">منخفض</span>' : '<span class="badge badge-success">متوفر</span>'}</td>
            ${canEdit ? `
              <td class="actions-cell">
                <button class="btn btn-sm btn-ghost" data-action="edit-product" data-id="${p.id}">✏️</button>
                <button class="btn btn-sm btn-ghost" data-action="delete-product" data-id="${p.id}">🗑️</button>
              </td>
            ` : ''}
          </tr>
        `;
      }
    }).join('');

    return `
      <table>
        <thead>${headerRow}</thead>
        <tbody>${rows}</tbody>
      </table>
    `;
  },

  productForm: (product = null) => {
    const p = product || { barcode: '', barcodes: [], name: '', cost: 0, price: 0, stock: 0, category: '', image: '' };
    // لو التعديل على منتج قديم: نعرض كل الباركودات (الرئيسي + الإضافية) ونخفي الرئيسي من قائمة الإضافية
    const allBcs = Products.getAllBarcodes(p);
    const mainBc = String(p.barcode || '').trim();
    const extraBcs = allBcs.filter(b => b !== mainBc);
    return `
      <form id="productForm">
        <div class="form-group">
          <label>الباركود الرئيسي *</label>
          <div style="display:flex;gap:0.5rem;">
            <input type="text" name="barcode" id="mainBarcodeInput" value="${escapeHtml(p.barcode)}" required style="flex:1;" />
            <button type="button" class="btn btn-ghost" id="formScanBtn" title="سكان باركود">📷</button>
            <button type="button" class="btn btn-ghost" id="formGenBarcodeBtn" title="توليد باركود تلقائي">🎲</button>
          </div>
        </div>
        <div class="form-group">
          <label>اسم المنتج *</label>
          <input type="text" name="name" value="${escapeHtml(p.name)}" required />
        </div>
        ${ProductImages.imageField(p.image || '')}
        <div class="grid grid-2">
          <div class="form-group">
            <label>الفئة</label>
            <input type="text" name="category" list="catList" value="${escapeHtml(p.category)}" placeholder="مثال: مشروبات" />
            <datalist id="catList">
              ${Inventory._categories().map(c => `<option value="${escapeHtml(c)}">`).join('')}
            </datalist>
          </div>
          <div class="form-group">
            <label>الكمية في المخزون</label>
            <input type="number" name="stock" value="${p.stock || 0}" min="0" step="1" />
          </div>
        </div>
        <div class="grid grid-2">
          <div class="form-group">
            <label>سعر التكلفة ($)</label>
            <input type="number" name="cost" value="${p.cost || 0}" min="0" step="0.01" required />
          </div>
          <div class="form-group">
            <label>سعر البيع المُقترَح ($)</label>
            <input type="number" name="price" value="${p.price || 0}" min="0" step="0.01" required />
            <small style="color:var(--text-muted); display:block; margin-top:0.25rem;">هذا السعر المُقترَح. البائع يقدر يغيّره عند البيع من نقطة البيع.</small>
          </div>
        </div>

        <!-- ====== باركودات إضافية ====== -->
        <div class="form-group" style="background:var(--bg);padding:0.85rem;border-radius:10px;border:1.5px dashed #cbd5e1;">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:0.5rem;flex-wrap:wrap;gap:0.5rem;">
            <label style="margin:0;font-weight:700;color:#1e293b;">🏷️ باركودات إضافية (اختياري)</label>
            <div style="display:flex;gap:0.4rem;">
              <button type="button" class="btn btn-ghost" id="addExtraBarcodeBtn" style="padding:0.35rem 0.7rem;font-size:0.8rem;">➕ إضافة</button>
              <button type="button" class="btn btn-ghost" id="scanExtraBarcodeBtn" style="padding:0.35rem 0.7rem;font-size:0.8rem;">📷 سكان</button>
            </div>
          </div>
          <small style="color:var(--text-muted);display:block;margin-bottom:0.5rem;">
            كل باركود يميّز وحدة (علبة/قطعة) من نفس المنتج. البائع يقدر يسكن <b>أي</b> باركود منهم في نقطة البيع.
          </small>
          <div id="extraBarcodesList" style="display:flex;flex-direction:column;gap:0.4rem;">
            ${extraBcs.map((bc, i) => `
              <div class="extra-bc-row" style="display:flex;gap:0.4rem;align-items:center;">
                <span style="background:#2563eb;color:#fff;width:24px;height:24px;display:flex;align-items:center;justify-content:center;border-radius:50%;font-size:0.75rem;flex-shrink:0;">${i + 1}</span>
                <input type="text" class="extra-bc-input" value="${escapeHtml(bc)}" placeholder="باركود إضافي" style="flex:1;font-family:monospace;" />
                <button type="button" class="btn btn-ghost remove-bc-btn" style="padding:0.3rem 0.5rem;color:#dc2626;" title="حذف">✕</button>
              </div>
            `).join('')}
          </div>
          <div id="extraBarcodesEmpty" style="text-align:center;padding:0.8rem;color:#94a3b8;font-size:0.85rem;${extraBcs.length === 0 ? '' : 'display:none;'}">
            لا توجد باركودات إضافية — اضغط "➕ إضافة" لإضافة باركود جديد
          </div>
          <div style="margin-top:0.5rem;font-size:0.8rem;color:#475569;">
            📊 <b>إجمالي الباركودات:</b> <span id="bcCountMain">1</span> (رئيسي) + <span id="bcCountExtra">${extraBcs.length}</span> (إضافية) = <b><span id="bcCountTotal">${1 + extraBcs.length}</span></b>
          </div>
        </div>

        <div style="background:var(--primary-light);padding:0.75rem;border-radius:8px;margin-bottom:1rem;">
          <strong>الربح المتوقع:</strong> <span id="profitPreview" style="color:var(--success);font-weight:700;"></span>
        </div>
        <div class="modal-footer" style="padding-inline-start:0;">
          <button type="submit" class="btn btn-primary">${product ? 'حفظ التعديلات' : 'إضافة المنتج'}</button>
          <button type="button" class="btn btn-ghost" data-close="genericModal">إلغاء</button>
        </div>
      </form>
    `;
  },

  handleSubmit: (e) => {
    e.preventDefault();
    const form = e.target;
    const data = Object.fromEntries(new FormData(form));
    data.barcode = String(data.barcode).trim();
    data.name = String(data.name).trim();
    data.cost = Number(data.cost);
    data.price = Number(data.price);
    data.stock = Number(data.stock);
    data.image = String(data.image || '');

    // جمع الباركودات الإضافية من الـ DOM
    const extraInputs = form.querySelectorAll('.extra-bc-input');
    const extras = Array.from(extraInputs)
      .map(inp => String(inp.value).trim())
      .filter(Boolean);
    // إزالة التكرار داخل الإضافية نفسها + استبعاد الباركود الرئيسي
    const mainBc = data.barcode;
    const seen = new Set([mainBc]);
    const cleanedExtras = [];
    let dupInExtras = null;
    extras.forEach(bc => {
      if (seen.has(bc)) {
        if (!dupInExtras) dupInExtras = bc;
      } else {
        seen.add(bc);
        cleanedExtras.push(bc);
      }
    });
    if (dupInExtras) {
      toast(`⚠️ الباركود "${dupInExtras}" مكرر (تم تجاهل التكرار)`, 'error');
    }
    data.barcodes = [mainBc, ...cleanedExtras];

    if (!data.barcode || !data.name) {
      toast('الباركود والاسم مطلوبان', 'error');
      return;
    }

    // التحقق من تكرار الباركودات مع منتجات أخرى (الكل بما فيه الإضافية)
    const editId = form.dataset.editId || null;
    for (const bc of data.barcodes) {
      if (Products.isBarcodeTaken(bc, editId)) {
        // إذا الباركود تبع نفس المنتج (المعدّل) → مسموح
        const owner = Products.findByBarcode(bc);
        if (owner && owner.id !== editId) {
          toast(`⚠️ الباركود "${bc}" مستخدم بالفعل للمنتج "${owner.name}"`, 'error');
          return;
        }
      }
    }

    if (form.dataset.editId) {
      Products.update(form.dataset.editId, data);
      toast('تم تحديث المنتج بنجاح', 'success');
    } else {
      const user = Auth.require();
      if (user) data.createdBy = user.id;
      Products.add(data);
      toast('تم إضافة المنتج بنجاح', 'success');
    }

    closeModal('genericModal');
    Inventory.refresh();
  },

  // ربط أزرار إدارة الباركودات الإضافية
  bindExtraBarcodes: (form) => {
    if (!form) return;
    const list = form.querySelector('#extraBarcodesList');
    const empty = form.querySelector('#extraBarcodesEmpty');
    const countExtra = form.querySelector('#bcCountExtra');
    const countTotal = form.querySelector('#bcCountTotal');
    if (!list) return;

    function updateCount() {
      const rows = list.querySelectorAll('.extra-bc-row').length;
      if (countExtra) countExtra.textContent = rows;
      if (countTotal) countTotal.textContent = 1 + rows;
      if (empty) empty.style.display = rows === 0 ? 'block' : 'none';
      // أعد ترقيم
      list.querySelectorAll('.extra-bc-row').forEach((r, i) => {
        const badge = r.querySelector('span');
        if (badge) badge.textContent = i + 1;
      });
    }

    function addRow(value = '') {
      const row = document.createElement('div');
      row.className = 'extra-bc-row';
      row.style.cssText = 'display:flex;gap:0.4rem;align-items:center;';
      const idx = list.querySelectorAll('.extra-bc-row').length + 1;
      row.innerHTML = `
        <span style="background:#2563eb;color:#fff;width:24px;height:24px;display:flex;align-items:center;justify-content:center;border-radius:50%;font-size:0.75rem;flex-shrink:0;">${idx}</span>
        <input type="text" class="extra-bc-input" value="${escapeHtml(value)}" placeholder="باركود إضافي" style="flex:1;font-family:monospace;" />
        <button type="button" class="btn btn-ghost remove-bc-btn" style="padding:0.3rem 0.5rem;color:#dc2626;" title="حذف">✕</button>
      `;
      list.appendChild(row);
      const input = row.querySelector('.extra-bc-input');
      input.focus();
      input.select();
      updateCount();
    }

    // زر "➕ إضافة"
    form.querySelector('#addExtraBarcodeBtn')?.addEventListener('click', () => addRow(''));

    // زر "📷 سكان" - يفتح السكان ويضيف الناتج كصف جديد
    form.querySelector('#scanExtraBarcodeBtn')?.addEventListener('click', () => {
      if (typeof Scanner === 'undefined' || !Scanner.open) {
        toast('السكان غير متاح', 'error');
        return;
      }
      Scanner.open((code) => {
        if (code) addRow(String(code).trim());
      });
    });

    // حذف صف (delegation)
    list.addEventListener('click', (ev) => {
      const btn = ev.target.closest('.remove-bc-btn');
      if (!btn) return;
      const row = btn.closest('.extra-bc-row');
      if (row) {
        row.remove();
        updateCount();
      }
    });

    // Enter في حقل باركود → يضيف صف جديد تلقائياً
    list.addEventListener('keydown', (ev) => {
      if (ev.key === 'Enter' && ev.target.classList.contains('extra-bc-input')) {
        ev.preventDefault();
        const val = ev.target.value.trim();
        addRow('');
        if (val) {
          // انقل القيمة للصف السابق
          const rows = list.querySelectorAll('.extra-bc-row');
          const prev = rows[rows.length - 2];
          if (prev) prev.querySelector('.extra-bc-input').value = val;
          updateCount();
        }
      }
    });
  },

  refresh: () => {
    const wrap = document.getElementById('inventoryTableWrap');
    if (wrap) wrap.innerHTML = Inventory.renderTable();
  },

  bindEvents: () => {
    document.getElementById('invSearch')?.addEventListener('input', Inventory.refresh);
    document.getElementById('invCategoryFilter')?.addEventListener('change', Inventory.refresh);

    // تبويبات التحليل
    document.querySelectorAll('#invTabs .inv-tab').forEach(btn => {
      btn.addEventListener('click', () => {
        Inventory._activeTab = btn.dataset.tab;
        // تحديث الحالة النشطة
        document.querySelectorAll('#invTabs .inv-tab').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        Inventory.refresh();
      });
    });

    document.getElementById('addProductBtn')?.addEventListener('click', () => {
      openModal('إضافة منتج جديد', Inventory.productForm());
      Inventory._bindFormEvents();
    });

    document.getElementById('scanBarcodeBtn')?.addEventListener('click', () => {
      Scanner.open((barcode) => {
        Scanner.close();
        // إذا كنا في نموذج، حط الباركود فيه
        const barcodeInput = document.querySelector('#productForm input[name="barcode"]');
        if (barcodeInput) {
          barcodeInput.value = barcode;
        } else {
          // بحث عن المنتج
          const product = Products.findByBarcode(barcode);
          if (product) {
            toast(`المنتج: ${product.name}`, 'success');
            // عرض تفاصيله
            Inventory.showProductDetails(product);
          } else {
            toast('المنتج غير موجود - أضفه الآن', 'warning');
            openModal('إضافة منتج جديد', Inventory.productForm({ barcode }));
            Inventory._bindFormEvents();
          }
        }
      });
    });

    // إجراءات الجدول
    document.getElementById('inventoryTableWrap')?.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-action]');
      if (!btn) return;
      const action = btn.dataset.action;
      const id = btn.dataset.id;

      if (action === 'edit-product') {
        const product = Products.find(id);
        if (product) {
          openModal('تعديل المنتج', Inventory.productForm(product));
          const form = document.getElementById('productForm');
          form.dataset.editId = id;
          Inventory._bindFormEvents();
        }
      } else if (action === 'delete-product') {
        const product = Products.find(id);
        if (!product) return;
        if (confirm(`هل أنت متأكد من حذف "${product.name}"؟`)) {
          Products.remove(id);
          toast('تم الحذف', 'success');
          Inventory.refresh();
        }
      }
    });
  },

  _bindFormEvents: () => {
    const form = document.getElementById('productForm');
    if (!form) return;

    form.addEventListener('submit', Inventory.handleSubmit);

    // ربط أحداث حقل الصورة
    ProductImages.bindImageField();

    // ربط أحداث الباركودات الإضافية
    Inventory.bindExtraBarcodes(form);

    // تحديث معاينة الربح
    const updateProfit = () => {
      const cost = Number(form.cost.value || 0);
      const price = Number(form.price.value || 0);
      const profit = price - cost;
      const profitPct = cost > 0 ? (profit / cost * 100).toFixed(0) : 0;
      const preview = document.getElementById('profitPreview');
      if (preview) {
        preview.innerHTML = `${profit.toFixed(2)} $ <small>(${profitPct}%)</small>`;
        preview.style.color = profit >= 0 ? 'var(--success)' : 'var(--danger)';
      }
    };
    form.cost.addEventListener('input', updateProfit);
    form.price.addEventListener('input', updateProfit);
    updateProfit();

    // زر السكان في النموذج
    document.getElementById('formScanBtn')?.addEventListener('click', () => {
      Scanner.open((barcode) => {
        Scanner.close();
        form.barcode.value = barcode;
      });
    });

    // توليد باركود عشوائي
    document.getElementById('formGenBarcodeBtn')?.addEventListener('click', () => {
      let code;
      do {
        code = String(Math.floor(1000000000000 + Math.random() * 9000000000000));
      } while (Products.findByBarcode(code));
      form.barcode.value = code;
    });
  },

  showProductDetails: (product) => {
    const allBcs = Products.getAllBarcodes(product);
    const mainBc = String(product.barcode || '').trim();
    const extras = allBcs.filter(b => b !== mainBc);
    const content = `
      <div style="text-align:right;">
        <p><strong>الاسم:</strong> د.ع{escapeHtml(product.name)}</p>
        <p><strong>الفئة:</strong> د.ع{product.category || '—'}</p>
        <p><strong>المخزون:</strong> د.ع{product.stock}</p>
        <p><strong>التكلفة:</strong> د.ع{product.cost.toFixed(2)} $</p>
        <p><strong>السعر:</strong> د.ع{product.price.toFixed(2)} $</p>
        <p><strong>الربح:</strong> <span style="color:var(--success);">${(product.price - product.cost).toFixed(2)} د.ع</span></p>
        <div style="margin-top:0.75rem;padding:0.6rem;background:var(--bg);border-radius:8px;">
          <strong>🏷️ الباركودات (${allBcs.length}):</strong>
          <div style="margin-top:0.4rem;display:flex;flex-direction:column;gap:0.3rem;">
            <div><span style="background:#16a34a;color:#fff;padding:1px 6px;border-radius:4px;font-size:0.7rem;">رئيسي</span> <code style="font-size:0.85rem;">${escapeHtml(mainBc)}</code></div>
            ${extras.map((bc, i) => `<div><span style="background:#2563eb;color:#fff;padding:1px 6px;border-radius:4px;font-size:0.7rem;">${i + 1}</span> <code style="font-size:0.85rem;">${escapeHtml(bc)}</code></div>`).join('')}
          </div>
        </div>
      </div>
    `;
    openModal('تفاصيل المنتج', content);
  },
};
