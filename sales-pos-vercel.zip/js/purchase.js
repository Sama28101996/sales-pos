// =====================================================
// نظام الشراء - إضافة بضاعة للمخزون
// =====================================================

const Purchase = {
  cart: [], // { product, qty, cost }

  render: () => {
    return `
      <div class="pos-layout">
        <div class="product-search-area">
          <div class="card">
            <div class="card-header">
              <h2>📥 إضافة بضاعة للمخزون</h2>
            </div>
            <div class="card-body">
              <div class="search-input-wrap">
                <input type="text" id="purchaseSearch" placeholder="ابحث عن منتج موجود أو امسح باركود..." />
              </div>
              <div style="margin-top:0.75rem;display:flex;gap:0.5rem;flex-wrap:wrap;">
                <button class="btn btn-primary" id="purchaseScanBtn">📷 سكان باركود</button>
                <button class="btn btn-success" id="addNewProductPurchaseBtn">➕ منتج جديد</button>
              </div>
              <div id="purchaseSearchResults" style="margin-top:1rem;"></div>
            </div>
          </div>
        </div>
        <div class="cart-panel">
          <div class="card-header">
            <h2>📋 فاتورة الشراء</h2>
          </div>
          <div class="cart-items" id="purchaseCartItems">
            <div class="empty-state">
              <div class="empty-icon">📦</div>
              <p>لا توجد أصناف</p>
            </div>
          </div>
          <div class="cart-total">
            <div class="cart-total-row">
              <span>عدد الأصناف:</span>
              <span id="purchaseItemCount">0</span>
            </div>
            <div class="cart-total-row grand">
              <span>إجمالي التكلفة:</span>
              <span id="purchaseTotal">0.00 د.ع</span>
            </div>
          </div>
          <div class="cart-actions">
            <button class="btn btn-primary btn-block" id="confirmPurchase">✅ تأكيد الشراء</button>
            <button class="btn btn-ghost btn-block" id="clearPurchaseCart">🗑️ إفراغ</button>
          </div>
        </div>
      </div>
    `;
  },

  bindEvents: () => {
    const searchInput = document.getElementById('purchaseSearch');

    const onSearch = () => {
      const q = searchInput.value.trim();
      if (q.length === 0) {
        document.getElementById('purchaseSearchResults').innerHTML = '';
        return;
      }
      // إذا باركود
      if (q.length >= 8 && /^\d+$/.test(q)) {
        const product = Products.findByBarcode(q);
        if (product) {
          Purchase._showAddToPurchase(product);
          searchInput.value = '';
          return;
        } else {
          // باركود جديد - اسأل المستخدم
          if (confirm(`الباركود ${q} غير موجود. هل تريد إضافة منتج جديد بهذا الباركود؟`)) {
            Purchase._showNewProductForm(q);
            searchInput.value = '';
          }
          return;
        }
      }
      Purchase._showSearchResults(q);
    };

    searchInput?.addEventListener('input', onSearch);
    searchInput?.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); onSearch(); }
    });

    document.getElementById('purchaseScanBtn')?.addEventListener('click', () => {
      Scanner.open((barcode) => {
        Scanner.close();
        const product = Products.findByBarcode(barcode);
        if (product) {
          Purchase._showAddToPurchase(product);
        } else {
          if (confirm(`الباركود ${barcode} غير موجود. هل تريد إضافة منتج جديد؟`)) {
            Purchase._showNewProductForm(barcode);
          }
        }
      });
    });

    document.getElementById('addNewProductPurchaseBtn')?.addEventListener('click', () => {
      Purchase._showNewProductForm();
    });

    document.getElementById('confirmPurchase')?.addEventListener('click', Purchase.confirm);
    document.getElementById('clearPurchaseCart')?.addEventListener('click', () => {
      if (Purchase.cart.length === 0) return;
      if (confirm('إفراغ قائمة الشراء؟')) {
        Purchase.cart = [];
        Purchase.renderCart();
      }
    });

    document.getElementById('purchaseCartItems')?.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-purchase-action]');
      if (!btn) return;
      const action = btn.dataset.purchaseAction;
      const productId = btn.dataset.productId;
      const item = Purchase.cart.find(c => c.product.id === productId);
      if (!item) return;

      if (action === 'increase') {
        item.qty += 1;
        Purchase.renderCart();
      } else if (action === 'decrease') {
        item.qty = Math.max(1, item.qty - 1);
        Purchase.renderCart();
      } else if (action === 'remove') {
        Purchase.cart = Purchase.cart.filter(c => c.product.id !== productId);
        Purchase.renderCart();
      }
    });
  },

  _showSearchResults: (query) => {
    const q = query.toLowerCase();
    const results = Products.all().filter(p =>
      p.name.toLowerCase().includes(q) || p.barcode.includes(q)
    ).slice(0, 20);

    const container = document.getElementById('purchaseSearchResults');
    if (results.length === 0) {
      container.innerHTML = '<p style="text-align:center;color:var(--text-muted);padding:1rem;">لا توجد نتائج</p>';
      return;
    }

    container.innerHTML = results.map(p => `
      <div class="cart-item" style="border:1px solid var(--border);border-radius:8px;cursor:pointer;margin-bottom:0.5rem;" data-purchase-add="${p.id}">
        <div class="cart-item-info">
          <div class="cart-item-name">${escapeHtml(p.name)}</div>
          <div class="cart-item-price">التكلفة الحالية: ${p.cost.toFixed(2)} $ • المخزون: ${p.stock}</div>
        </div>
        <button class="btn btn-sm btn-primary">إضافة</button>
      </div>
    `).join('');

    container.querySelectorAll('[data-purchase-add]').forEach(el => {
      el.addEventListener('click', () => {
        const product = Products.find(el.dataset.purchaseAdd);
        if (product) Purchase._showAddToPurchase(product);
      });
    });
  },

  _showAddToPurchase: (product) => {
    const content = `
      <form id="addToPurchaseForm">
        <p><strong>المنتج:</strong> د.ع{escapeHtml(product.name)}</p>
        <p><strong>المخزون الحالي:</strong> د.ع{product.stock}</p>
        <p><strong>التكلفة الحالية:</strong> د.ع{product.cost.toFixed(2)} $</p>
        <div class="form-group">
          <label>الكمية المضافة *</label>
          <input type="number" name="qty" min="1" value="1" required />
        </div>
        <div class="form-group">
          <label>سعر التكلفة للوحدة ($) *</label>
          <input type="number" name="cost" min="0" step="0.01" value="${product.cost}" required />
          <small style="color:var(--text-muted);">اتركه كما هو أو غيّره حسب سعر الشراء الجديد</small>
        </div>
        <div class="modal-footer" style="padding-inline-start:0;">
          <button type="submit" class="btn btn-primary">إضافة للفاتورة</button>
          <button type="button" class="btn btn-ghost" data-close="genericModal">إلغاء</button>
        </div>
      </form>
    `;
    openModal('إضافة للمشتريات', content);

    document.getElementById('addToPurchaseForm').addEventListener('submit', (e) => {
      e.preventDefault();
      const qty = Number(e.target.qty.value);
      const cost = Number(e.target.cost.value);
      if (qty <= 0 || cost < 0) {
        toast('قيم غير صحيحة', 'error');
        return;
      }

      const existing = Purchase.cart.find(c => c.product.id === product.id);
      if (existing) {
        existing.qty += qty;
        // متوسط التكلفة المرجحة
        const totalCost = (existing.cost * (existing.qty - qty) + cost * qty);
        existing.cost = totalCost / existing.qty;
      } else {
        Purchase.cart.push({
          product: { ...product },
          qty,
          cost,
        });
      }

      Purchase.renderCart();
      closeModal('genericModal');
      toast(`تم إضافة ${qty} من ${product.name}`, 'success');
    });
  },

  _showNewProductForm: (barcode = '') => {
    const formHtml = Inventory.productForm({ barcode });
    openModal('منتج جديد', formHtml);
    const form = document.getElementById('productForm');

    // ربط أحداث الفورم (أزرار الباركود، الصورة، الباركودات الإضافية)
    // بدون هذا السطر، الأزرار ما تشتغل
    if (typeof Inventory._bindFormEvents === 'function') {
      Inventory._bindFormEvents();
    }

    const origHandler = form.onsubmit;
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const data = Object.fromEntries(new FormData(form));
      data.barcode = String(data.barcode).trim();
      data.name = String(data.name).trim();
      data.cost = Number(data.cost);
      data.price = Number(data.price);
      data.stock = Number(data.stock);

      if (!data.barcode || !data.name) {
        toast('الباركود والاسم مطلوبان', 'error');
        return;
      }

      if (Products.findByBarcode(data.barcode)) {
        toast('هذا الباركود مستخدم', 'error');
        return;
      }

      const newProduct = Products.add(data);
      // تسجيل المستخدم اللي أضاف المنتج (لتقرير البضاعة المفتوحة)
      const currentUser = Auth.require();
      if (currentUser) Products.update(newProduct.id, { createdBy: currentUser.id });
      // أضف مباشرة لفاتورة الشراء
      Purchase.cart.push({
        product: newProduct,
        qty: newProduct.stock,
        cost: newProduct.cost,
      });
      Purchase.renderCart();
      closeModal('genericModal');
      toast(`تم إضافة المنتج ${newProduct.name}`, 'success');
    });
  },

  renderCart: () => {
    const container = document.getElementById('purchaseCartItems');
    const countEl = document.getElementById('purchaseItemCount');
    const totalEl = document.getElementById('purchaseTotal');

    if (Purchase.cart.length === 0) {
      container.innerHTML = '<div class="empty-state"><div class="empty-icon">📦</div><p>لا توجد أصناف</p></div>';
      countEl.textContent = '0';
      totalEl.textContent = '0.00 د.ع';
      return;
    }

    let total = 0;
    container.innerHTML = Purchase.cart.map(({ product, qty, cost }) => {
      const subtotal = cost * qty;
      total += subtotal;
      return `
        <div class="cart-item">
          <div class="cart-item-info">
            <div class="cart-item-name">${escapeHtml(product.name)}</div>
            <div class="cart-item-price">${cost.toFixed(2)} $ × ${qty} = <strong>${subtotal.toFixed(2)} $</strong></div>
          </div>
          <div class="qty-control">
            <button data-purchase-action="decrease" data-product-id="${product.id}">−</button>
            <span style="min-width:30px;text-align:center;font-weight:600;">${qty}</span>
            <button data-purchase-action="increase" data-product-id="${product.id}">+</button>
            <button data-purchase-action="remove" data-product-id="${product.id}" style="background:var(--danger-light);color:var(--danger);">✕</button>
          </div>
        </div>
      `;
    }).join('');

    countEl.textContent = Purchase.cart.length;
    totalEl.textContent = total.toFixed(2) + ' د.ع';
  },

  confirm: () => {
    if (Purchase.cart.length === 0) {
      toast('لا توجد أصناف', 'warning');
      return;
    }

    const user = Auth.require();
    const items = Purchase.cart.map(c => ({
      productId: c.product.id,
      name: c.product.name,
      barcode: c.product.barcode,
      qty: c.qty,
      cost: c.cost,
      subtotal: c.qty * c.cost,
    }));

    const total = items.reduce((s, i) => s + i.subtotal, 0);

    const purchase = {
      items,
      total,
      buyerId: user.id,
      buyerName: user.name,
    };

    const saved = Purchases.add(purchase);

    // تحديث المخزون + التكلفة
    items.forEach(i => {
      const product = Products.find(i.productId);
      if (product) {
        const newStock = product.stock + i.qty;
        // المتوسط المرجح للتكلفة
        const oldTotalCost = product.cost * product.stock;
        const newTotalCost = i.cost * i.qty;
        const avgCost = newStock > 0 ? (oldTotalCost + newTotalCost) / newStock : i.cost;
        Products.update(i.productId, { stock: newStock, cost: avgCost });
      }
    });

    Purchase.cart = [];
    Purchase.renderCart();
    toast(`تمت عملية الشراء - فاتورة رقم ${saved.invoiceNo}`, 'success');
  },
};

// سجل المشتريات
const PurchaseHistory = {
  render: () => {
    const purchases = Purchases.all().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    return `
      <div class="card">
        <div class="card-header">
          <h2>📥 سجل المشتريات</h2>
        </div>
        <div class="card-body">
          <div class="table-wrap">
            ${purchases.length === 0 ? '<div class="empty-state"><div class="empty-icon">📥</div><p>لا توجد مشتريات بعد</p></div>' : `
              <table>
                <thead>
                  <tr>
                    <th>رقم الفاتورة</th>
                    <th>التاريخ</th>
                    <th>عدد الأصناف</th>
                    <th>الإجمالي</th>
                    <th>المشتري</th>
                  </tr>
                </thead>
                <tbody>
                  ${purchases.map(p => `
                    <tr>
                      <td><strong>${p.invoiceNo}</strong></td>
                      <td>${new Date(p.createdAt).toLocaleString('ar-EG')}</td>
                      <td>${p.items.length} صنف</td>
                      <td><strong>${p.total.toFixed(2)} $</strong></td>
                      <td>${escapeHtml(p.buyerName)}</td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            `}
          </div>
        </div>
      </div>
    `;
  },
};
