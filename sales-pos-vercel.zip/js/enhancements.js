// =====================================================
// التحسينات والإضافات الجديدة
// الإصدار 2.0 - إضافة كل الميزات المطلوبة
// =====================================================

const Enhancements = {

  // ============================================================
  // 1️⃣ الوضع الداكن (Dark Mode)
  // ============================================================
  initDarkMode: () => {
    const isDark = localStorage.getItem('pos_dark_mode') === '1';
    if (isDark) {
      document.documentElement.classList.add('dark-mode');
    }
    Enhancements._updateDarkModeButton();
  },

  toggleDarkMode: () => {
    const isDark = document.documentElement.classList.toggle('dark-mode');
    localStorage.setItem('pos_dark_mode', isDark ? '1' : '0');
    Enhancements._updateDarkModeButton();
    toast(isDark ? '🌙 تم تفعيل الوضع الداكن' : '☀️ تم تفعيل الوضع الفاتح', 'success');
  },

  _updateDarkModeButton: () => {
    const btn = document.getElementById('darkModeToggle');
    if (!btn) return;
    const isDark = document.documentElement.classList.contains('dark-mode');
    btn.textContent = isDark ? '☀️' : '🌙';
    btn.title = isDark ? 'الوضع الفاتح' : 'الوضع الداكن';
  },

  // ============================================================
  // 2️⃣ تحديث البيانات القديمة لربطها بالبائع (Migration)
  // ============================================================
  migrateOldData: () => {
    const flagKey = 'pos_migration_v2_done';
    if (localStorage.getItem(flagKey) === '1') return;

    try {
      // ربط المبيعات القديمة بالأدمن
      const admin = Users.findByUsername('admin');
      if (!admin) {
        localStorage.setItem(flagKey, '1');
        return;
      }

      const sales = Sales.all();
      let updated = 0;
      sales.forEach(s => {
        if (!s.sellerId) {
          s.sellerId = admin.id;
          s.sellerName = s.sellerName || admin.name;
          updated++;
        }
      });
      if (updated > 0) {
        dbSet(DB_KEYS.SALES, sales);
        console.log(`Migration: ${updated} sales updated with seller info`);
      }

      // ربط المنتجات القديمة بالأدمن
      const products = Products.all();
      let pUpdated = 0;
      products.forEach(p => {
        if (!p.createdBy) {
          p.createdBy = admin.id;
          pUpdated++;
        }
      });
      if (pUpdated > 0) {
        dbSet(DB_KEYS.PRODUCTS, products);
        console.log(`Migration: ${pUpdated} products updated with creator info`);
      }

      localStorage.setItem(flagKey, '1');
    } catch (e) {
      console.error('Migration error', e);
    }
  },

  // ============================================================
  // 3️⃣ تنبيهات ذكية (Smart Alerts)
  // ============================================================
  _checkAlerts: () => {
    const settings = Settings.get();
    const lowStockThreshold = settings.lowStockAlert || 5;
    const alerts = [];

    // أ) منتجات قاربت على النفاد
    const lowStock = Products.all().filter(p => p.stock > 0 && p.stock <= lowStockThreshold);
    const outOfStock = Products.all().filter(p => p.stock <= 0);

    if (outOfStock.length > 0) {
      alerts.push({
        type: 'critical',
        icon: '🚨',
        title: `${outOfStock.length} منتج نفد من المخزون`,
        body: outOfStock.slice(0, 3).map(p => p.name).join('، ') + (outOfStock.length > 3 ? '...' : ''),
        action: 'inventory',
        actionLabel: 'عرض المخزون',
      });
    }

    if (lowStock.length > 0) {
      alerts.push({
        type: 'warning',
        icon: '⚠️',
        title: `${lowStock.length} منتج قارب يخلص`,
        body: lowStock.slice(0, 3).map(p => `${p.name} (${p.stock})`).join('، ') + (lowStock.length > 3 ? '...' : ''),
        action: 'inventory',
        actionLabel: 'عرض المخزون',
      });
    }

    // ب) عملاء عليهم ديون قديمة (أكثر من 30 يوم)
    const now = new Date();
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    const oldDebts = Debts.unpaid().filter(d => {
      const created = new Date(d.createdAt);
      return created < thirtyDaysAgo;
    });

    if (oldDebts.length > 0) {
      const totalOldDebt = oldDebts.reduce((s, d) => s + d.remainingAmount, 0);
      alerts.push({
        type: 'danger',
        icon: '💸',
        title: `${oldDebts.length} عميل عليه دين من شهر+`,
        body: `إجمالي: ${totalOldDebt.toFixed(2)} $`,
        action: 'debts',
        actionLabel: 'عرض الديون',
      });
    }

    // ج) أعضاء لم يبيعوا اليوم (للمشرفين)
    const user = Auth.require();
    if (user && (user.role === 'admin' || (user.permissions && user.permissions.includes(PERMISSIONS.TEAM_REPORT)))) {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const sellers = Users.all().filter(u => u.role === 'seller' || u.role === 'admin');
      const inactiveSellers = sellers.filter(u => {
        const hasSaleToday = Sales.all().some(s => {
          if (s.sellerId !== u.id) return false;
          return new Date(s.createdAt) >= today;
        });
        return !hasSaleToday;
      });

      if (inactiveSellers.length > 0 && sellers.length > 1) {
        alerts.push({
          type: 'info',
          icon: '😴',
          title: `${inactiveSellers.length} عضو لم يبع اليوم`,
          body: inactiveSellers.slice(0, 3).map(u => u.name).join('، '),
          action: 'teamReport',
          actionLabel: 'عرض كشوفات',
        });
      }
    }

    return alerts;
  },

  renderAlertsWidget: () => {
    const alerts = Enhancements._checkAlerts();
    if (alerts.length === 0) {
      return `
        <div class="alerts-widget">
          <div class="alerts-empty">
            <span style="font-size:2rem;">✅</span>
            <p>كل شي تمام! لا توجد تنبيهات</p>
          </div>
        </div>
      `;
    }

    return `
      <div class="alerts-widget">
        <div class="alerts-header">
          <h3>🔔 تنبيهات ذكية (${alerts.length})</h3>
          <button class="btn btn-ghost btn-sm" id="refreshAlertsBtn">↻</button>
        </div>
        <div class="alerts-list">
          ${alerts.map((a, i) => `
            <div class="alert-item alert-${a.type}" data-alert-idx="${i}">
              <div class="alert-icon">${a.icon}</div>
              <div class="alert-content">
                <div class="alert-title">${escapeHtml(a.title)}</div>
                <div class="alert-body">${escapeHtml(a.body)}</div>
              </div>
              ${a.action ? `<button class="btn btn-sm btn-primary alert-action" data-page="${a.action}">${a.actionLabel}</button>` : ''}
            </div>
          `).join('')}
        </div>
      </div>
    `;
  },

  bindAlertsEvents: () => {
    document.getElementById('refreshAlertsBtn')?.addEventListener('click', () => {
      const widget = document.querySelector('.alerts-widget');
      if (widget) {
        const parent = widget.parentElement;
        parent.innerHTML = Enhancements.renderAlertsWidget();
        Enhancements.bindAlertsEvents();
      }
    });

    document.querySelectorAll('.alert-action').forEach(btn => {
      btn.addEventListener('click', () => {
        const page = btn.dataset.page;
        if (page && typeof navigateTo === 'function') {
          navigateTo(page);
        }
      });
    });
  },

  // ============================================================
  // 4️⃣ لوحة مقارنة أعضاء الفريق
  // ============================================================
  renderTeamComparison: () => {
    const users = Users.all().filter(u => u.role !== undefined);
    if (users.length === 0) {
      return '<div class="empty-state"><div class="empty-icon">👥</div><p>لا يوجد أعضاء</p></div>';
    }

    // نطاق زمني: آخر 30 يوم
    const now = new Date();
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

    const stats = users.map(u => {
      const userSales = Sales.all().filter(s => {
        if (s.sellerId !== u.id) return false;
        return new Date(s.createdAt) >= thirtyDaysAgo;
      });
      const totalSales = userSales.reduce((s, x) => s + x.total, 0);
      const salesCount = userSales.length;
      const totalItems = userSales.reduce((s, x) => s + (x.items || []).reduce((sum, i) => sum + i.qty, 0), 0);
      const totalProfit = userSales.reduce((s, x) => s + (x.items || []).reduce((sum, i) => sum + (i.subtotal - (i.cost * i.qty)), 0), 0);
      const avgSale = salesCount > 0 ? totalSales / salesCount : 0;
      return {
        user: u,
        totalSales,
        salesCount,
        totalItems,
        totalProfit,
        avgSale,
      };
    });

    // ترتيب حسب المبيعات
    stats.sort((a, b) => b.totalSales - a.totalSales);

    const maxSales = Math.max(...stats.map(s => s.totalSales), 1);

    return `
      <div class="card">
        <div class="card-header">
          <h2>🏆 لوحة مقارنة الأعضاء (آخر 30 يوم)</h2>
        </div>
        <div class="card-body">
          <!-- الـ Top 3 -->
          <div class="top-podium">
            ${stats.slice(0, 3).map((s, i) => {
              const medals = ['🥇', '🥈', '🥉'];
              return `
                <div class="podium-item rank-${i + 1}">
                  <div class="podium-medal">${medals[i]}</div>
                  <div class="podium-avatar">${(s.user.name || s.user.username).charAt(0)}</div>
                  <div class="podium-name">${escapeHtml(s.user.name)}</div>
                  <div class="podium-value">${s.totalSales.toFixed(2)} $</div>
                  <div class="podium-count">${s.salesCount} فاتورة</div>
                </div>
              `;
            }).join('')}
          </div>

          <!-- جدول مفصّل -->
          <div class="table-wrap" style="margin-top:1.5rem;">
            <table>
              <thead>
                <tr>
                  <th>الترتيب</th>
                  <th>العضو</th>
                  <th>إجمالي المبيعات</th>
                  <th>عدد الفواتير</th>
                  <th>صافي الربح</th>
                  <th>متوسط الفاتورة</th>
                  <th>الأداء</th>
                </tr>
              </thead>
              <tbody>
                ${stats.map((s, idx) => `
                  <tr>
                    <td>
                      ${idx === 0 ? '🥇' : idx === 1 ? '🥈' : idx === 2 ? '🥉' : `<strong>#${idx + 1}</strong>`}
                    </td>
                    <td><strong>${escapeHtml(s.user.name)}</strong></td>
                    <td><strong>${s.totalSales.toFixed(2)} $</strong></td>
                    <td>${s.salesCount}</td>
                    <td style="color:var(--success);">${s.totalProfit.toFixed(2)} $</td>
                    <td>${s.avgSale.toFixed(2)} $</td>
                    <td>
                      <div class="performance-bar">
                        <div class="performance-fill" style="width: ${(s.totalSales / maxSales * 100).toFixed(0)}%;"></div>
                      </div>
                    </td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;
  },

  // ============================================================
  // 5️⃣ البحث برقم الفاتورة
  // ============================================================
  searchInvoice: (query) => {
    if (!query) return null;
    const q = query.trim().toLowerCase();
    return Sales.all().find(s =>
      s.invoiceNo && s.invoiceNo.toLowerCase().includes(q)
    );
  },

  // ============================================================
  // 6️⃣ تغيير كلمة المرور (للعضو نفسه)
  // ============================================================
  changeMyPassword: () => {
    const user = Auth.require();
    if (!user) return;

    const content = `
      <form id="changeMyPassForm">
        <div class="form-group">
          <label>كلمة المرور الحالية</label>
          <input type="password" name="currentPass" required autocomplete="current-password" />
        </div>
        <div class="form-group">
          <label>كلمة المرور الجديدة</label>
          <input type="password" name="newPass" required minlength="3" autocomplete="new-password" />
        </div>
        <div class="form-group">
          <label>تأكيد كلمة المرور الجديدة</label>
          <input type="password" name="confirmPass" required minlength="3" autocomplete="new-password" />
        </div>
        <div class="modal-footer" style="padding-inline-start:0;">
          <button type="submit" class="btn btn-primary">تغيير كلمة المرور</button>
          <button type="button" class="btn btn-ghost" data-close="genericModal">إلغاء</button>
        </div>
      </form>
    `;
    openModal('🔑 تغيير كلمة المرور', content);

    document.getElementById('changeMyPassForm').addEventListener('submit', (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      const current = fd.get('currentPass');
      const newPass = fd.get('newPass');
      const confirm = fd.get('confirmPass');

      if (user.password !== current) {
        toast('❌ كلمة المرور الحالية غير صحيحة', 'error');
        return;
      }
      if (newPass !== confirm) {
        toast('❌ كلمة المرور الجديدة غير متطابقة', 'error');
        return;
      }
      if (newPass.length < 3) {
        toast('❌ كلمة المرور يجب أن تكون 3 أحرف على الأقل', 'error');
        return;
      }

      Users.update(user.id, { password: newPass });
      toast('✅ تم تغيير كلمة المرور بنجاح', 'success');
      closeModal('genericModal');
    });
  },

  // ============================================================
  // 7️⃣ عرض كلمات المرور للأدمن
  // ============================================================
  showPasswordsModal: () => {
    const users = Users.all();
    const content = `
      <div style="background:var(--warning-light);padding:0.75rem;border-radius:8px;margin-bottom:1rem;color:var(--warning);font-size:0.9rem;">
        ⚠️ هذه الشاشة تعرض كلمات المرور لأغراض إدارية. لا تشاركها مع أحد.
      </div>
      <table>
        <thead>
          <tr>
            <th>الاسم</th>
            <th>اسم المستخدم</th>
            <th>الدور</th>
            <th>كلمة المرور</th>
          </tr>
        </thead>
        <tbody>
          ${users.map(u => `
            <tr>
              <td><strong>${escapeHtml(u.name)}</strong></td>
              <td><code>${escapeHtml(u.username)}</code></td>
              <td>${ROLES[u.role]?.name || u.role}</td>
              <td>
                <code style="background:var(--bg);padding:4px 8px;border-radius:4px;user-select:all;">${escapeHtml(u.password || '')}</code>
                <button class="btn btn-sm btn-ghost" data-copy-pass="${u.password || ''}" title="نسخ">📋</button>
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
      <div style="margin-top:1rem;text-align:left;">
        <button class="btn btn-ghost" data-close="genericModal">إغلاق</button>
      </div>
    `;
    openModal('🔐 كلمات المرور', content, { large: true });

    document.querySelectorAll('[data-copy-pass]').forEach(btn => {
      btn.addEventListener('click', () => {
        const pass = btn.dataset.copyPass;
        navigator.clipboard.writeText(pass).then(() => {
          toast('✅ تم نسخ كلمة المرور', 'success');
        });
      });
    });
  },

  // ============================================================
  // 8️⃣ تهيئة زر الوضع الداكن في الشريط العلوي
  // ============================================================
  injectDarkModeButton: () => {
    const topbar = document.querySelector('.topbar-right');
    if (!topbar || document.getElementById('darkModeToggle')) return;

    const btn = document.createElement('button');
    btn.id = 'darkModeToggle';
    btn.className = 'icon-btn dark-mode-btn';
    btn.title = 'الوضع الداكن';
    btn.addEventListener('click', Enhancements.toggleDarkMode);
    topbar.insertBefore(btn, topbar.firstChild);
    Enhancements._updateDarkModeButton();
  },

  // ============================================================
  // 9️⃣ إضافة "الأغلى سعراً" في تبويبات المخزن
  // ============================================================
  addTopPricedTab: () => {
    // نضيف التبويب ديناميكياً - الـ Inventory module يكتشفه تلقائياً
    // عبر توسيع active tabs
  },

  // ============================================================
  // 🚀 تهيئة كل التحسينات
  // ============================================================
  init: () => {
    // 1. الوضع الداكن
    Enhancements.initDarkMode();
    Enhancements.injectDarkModeButton();

    // 2. تحديث البيانات القديمة
    Enhancements.migrateOldData();

    // 3. إعدادات افتراضية
    if (!localStorage.getItem('pos_migration_v2_done')) {
      localStorage.setItem('pos_migration_v2_done', '1');
    }
  },
};

// تهيئة عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', () => {
  Enhancements.init();
});
