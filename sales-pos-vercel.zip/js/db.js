// =====================================================
// قاعدة البيانات - تخزين محلي في LocalStorage
// =====================================================

const DB_KEYS = {
  USERS: 'pos_users',
  PRODUCTS: 'pos_products',
  CUSTOMERS: 'pos_customers',
  SUPPLIERS: 'pos_suppliers',
  SALES: 'pos_sales',
  PURCHASES: 'pos_purchases',
  DEBTS: 'pos_debts',
  SETTINGS: 'pos_settings',
  CURRENT_USER: 'pos_current_user',
  NEXT_IDS: 'pos_next_ids',
};

// قراءة/كتابة عامة
function dbGet(key, fallback = null) {
  try {
    const v = localStorage.getItem(key);
    return v ? JSON.parse(v) : fallback;
  } catch (e) {
    console.error('dbGet error', e);
    return fallback;
  }
}

function dbSet(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (e) {
    console.error('dbSet error', e);
    return false;
  }
}

// مولّد أرقام متسلسلة
function getNextId(type) {
  const ids = dbGet(DB_KEYS.NEXT_IDS, { invoice: 1000, purchase: 1000, customer: 1, supplier: 1, debt: 1, product: 1 });
  const next = (ids[type] || 1);
  ids[type] = next + 1;
  dbSet(DB_KEYS.NEXT_IDS, ids);
  return next;
}

// المستخدمين
const Users = {
  all: () => dbGet(DB_KEYS.USERS, []),
  find: (id) => Users.all().find(u => u.id === id),
  findByUsername: (username) => Users.all().find(u => u.username === username.toLowerCase().trim()),
  add: (user) => {
    const users = Users.all();
    user.id = 'u_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
    user.username = user.username.toLowerCase().trim();
    user.createdAt = user.createdAt || new Date().toISOString();
    users.push(user);
    dbSet(DB_KEYS.USERS, users);
    return user;
  },
  update: (id, updates) => {
    const users = Users.all();
    const idx = users.findIndex(u => u.id === id);
    if (idx === -1) return null;
    users[idx] = { ...users[idx], ...updates };
    dbSet(DB_KEYS.USERS, users);
    return users[idx];
  },
  remove: (id) => {
    const users = Users.all().filter(u => u.id !== id);
    dbSet(DB_KEYS.USERS, users);
  },
};

// المنتجات
const Products = {
  all: () => {
    const list = dbGet(DB_KEYS.PRODUCTS, []);
    // migration: أي منتج قديم بدون barcodes[]، نولّدها من barcode الحالي
    let dirty = false;
    list.forEach(p => {
      if (!Array.isArray(p.barcodes)) {
        p.barcodes = p.barcode ? [p.barcode] : [];
        dirty = true;
      }
    });
    if (dirty) dbSet(DB_KEYS.PRODUCTS, list);
    return list;
  },
  find: (id) => Products.all().find(p => p.id === id),
  // يبحث في الباركود الرئيسي + كل الباركودات الإضافية
  findByBarcode: (barcode) => {
    const code = String(barcode).trim();
    if (!code) return null;
    return Products.all().find(p => {
      if (p.barcode === code) return true;
      return Array.isArray(p.barcodes) && p.barcodes.includes(code);
    });
  },
  // يرجع كل باركودات المنتج (الرئيسي + الإضافية) كمسطح بدون تكرار
  getAllBarcodes: (p) => {
    if (!p) return [];
    const set = new Set();
    if (p.barcode) set.add(String(p.barcode).trim());
    if (Array.isArray(p.barcodes)) p.barcodes.forEach(b => b && set.add(String(b).trim()));
    return Array.from(set).filter(Boolean);
  },
  // يتحقق هل الباركود مستخدم (مع استثناء منتج معيّن) - عبر كل الباركودات
  isBarcodeTaken: (code, excludeProductId = null) => {
    const c = String(code).trim();
    if (!c) return false;
    return Products.all().some(p => {
      if (excludeProductId && p.id === excludeProductId) return false;
      if (p.barcode === c) return true;
      return Array.isArray(p.barcodes) && p.barcodes.includes(c);
    });
  },
  add: (product) => {
    const products = Products.all();
    product.id = 'p_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
    product.createdAt = new Date().toISOString();
    product.updatedAt = product.createdAt;
    product.stock = Number(product.stock || 0);
    product.cost = Number(product.cost || 0);
    product.price = Number(product.price || 0);
    // ضمان أن barcodes مصفوفة (يشمل الباركود الرئيسي)
    const allBcs = Products.getAllBarcodes(product);
    product.barcodes = allBcs;
    products.push(product);
    dbSet(DB_KEYS.PRODUCTS, products);
    return product;
  },
  update: (id, updates) => {
    const products = Products.all();
    const idx = products.findIndex(p => p.id === id);
    if (idx === -1) return null;
    // لو حدّث barcodes يدوياً، نضمن التنظيف
    if (Array.isArray(updates.barcodes)) {
      updates.barcodes = updates.barcodes.map(b => String(b).trim()).filter(Boolean);
      // نضمن أن الباركود الرئيسي موجود في المصفوفة
      if (updates.barcode && !updates.barcodes.includes(String(updates.barcode).trim())) {
        updates.barcodes.unshift(String(updates.barcode).trim());
      }
    }
    products[idx] = { ...products[idx], ...updates, updatedAt: new Date().toISOString() };
    // ضمان أن barcodes دائماً متزامن مع barcode
    products[idx].barcodes = Products.getAllBarcodes(products[idx]);
    dbSet(DB_KEYS.PRODUCTS, products);
    return products[idx];
  },
  remove: (id) => {
    const products = Products.all().filter(p => p.id !== id);
    dbSet(DB_KEYS.PRODUCTS, products);
  },
  adjustStock: (id, delta) => {
    const p = Products.find(id);
    if (!p) return null;
    const newStock = Math.max(0, Number(p.stock || 0) + Number(delta));
    return Products.update(id, { stock: newStock });
  },
};

// العملاء
const Customers = {
  all: () => dbGet(DB_KEYS.CUSTOMERS, []),
  find: (id) => Customers.all().find(c => c.id === id),
  add: (customer) => {
    const customers = Customers.all();
    customer.id = 'c_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
    customer.createdAt = new Date().toISOString();
    customer.totalPurchases = 0;
    customer.totalDebt = 0;
    customers.push(customer);
    dbSet(DB_KEYS.CUSTOMERS, customers);
    return customer;
  },
  update: (id, updates) => {
    const customers = Customers.all();
    const idx = customers.findIndex(c => c.id === id);
    if (idx === -1) return null;
    customers[idx] = { ...customers[idx], ...updates };
    dbSet(DB_KEYS.CUSTOMERS, customers);
    return customers[idx];
  },
  remove: (id) => {
    const customers = Customers.all().filter(c => c.id !== id);
    dbSet(DB_KEYS.CUSTOMERS, customers);
  },
};

// المبيعات
const Sales = {
  all: () => dbGet(DB_KEYS.SALES, []),
  find: (id) => Sales.all().find(s => s.id === id),
  add: (sale) => {
    const sales = Sales.all();
    sale.id = 's_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
    sale.invoiceNo = 'INV-' + getNextId('invoice');
    sale.createdAt = new Date().toISOString();
    sales.push(sale);
    dbSet(DB_KEYS.SALES, sales);
    return sale;
  },
  remove: (id) => {
    const sales = Sales.all().filter(s => s.id !== id);
    dbSet(DB_KEYS.SALES, sales);
  },
  byDateRange: (start, end) => {
    return Sales.all().filter(s => {
      const d = new Date(s.createdAt);
      return d >= new Date(start) && d <= new Date(end);
    });
  },
};

// المشتريات
const Purchases = {
  all: () => dbGet(DB_KEYS.PURCHASES, []),
  add: (purchase) => {
    const purchases = Purchases.all();
    purchase.id = 'pu_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
    purchase.invoiceNo = 'PUR-' + getNextId('purchase');
    purchase.createdAt = new Date().toISOString();
    purchases.push(purchase);
    dbSet(DB_KEYS.PURCHASES, purchases);
    return purchase;
  },
  remove: (id) => {
    const purchases = Purchases.all().filter(p => p.id !== id);
    dbSet(DB_KEYS.PURCHASES, purchases);
  },
  byDateRange: (start, end) => {
    return Purchases.all().filter(p => {
      const d = new Date(p.createdAt);
      return d >= new Date(start) && d <= new Date(end);
    });
  },
};

// الديون
const Debts = {
  all: () => dbGet(DB_KEYS.DEBTS, []),
  add: (debt) => {
    const debts = Debts.all();
    debt.id = 'd_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
    debt.createdAt = new Date().toISOString();
    debt.remainingAmount = debt.remainingAmount ?? debt.amount;
    debt.payments = debt.payments || [];
    debts.push(debt);
    dbSet(DB_KEYS.DEBTS, debts);
    return debt;
  },
  update: (id, updates) => {
    const debts = Debts.all();
    const idx = debts.findIndex(d => d.id === id);
    if (idx === -1) return null;
    debts[idx] = { ...debts[idx], ...updates };
    dbSet(DB_KEYS.DEBTS, debts);
    return debts[idx];
  },
  remove: (id) => {
    const debts = Debts.all().filter(d => d.id !== id);
    dbSet(DB_KEYS.DEBTS, debts);
  },
  byCustomer: (customerId) => Debts.all().filter(d => d.customerId === customerId),
  unpaid: () => Debts.all().filter(d => d.remainingAmount > 0 && d.status !== 'paid'),
};

// الإعدادات
const Settings = {
  get: () => dbGet(DB_KEYS.SETTINGS, {
    storeName: 'متجري',
    storePhone: '',
    storeAddress: '',
    currency: 'د.ع',
    taxRate: 0,
    lowStockAlert: 5,
    language: 'ar',
    primaryNotes: '',
    secondaryNotes: '',
    logoBase64: '',
  }),
  set: (updates) => {
    const current = Settings.get();
    const next = { ...current, ...updates };
    dbSet(DB_KEYS.SETTINGS, next);
    return next;
  },
};

// =====================================================
// تهيئة أولية - حساب الأدمن الافتراضي + بيانات تجريبية
// =====================================================
function initializeDB() {
  // إنشاء حساب الأدمن إذا ما في مستخدمين
  if (Users.all().length === 0) {
    Users.add({
      username: 'admin',
      password: 'admin123',
      name: 'المشرف العام',
      role: 'admin',
      permissions: ['*'], // كل الصلاحيات
    });
  }

  // إضافة بيانات تجريبية إذا ما في منتجات
  if (Products.all().length === 0) {
    const samples = [
      { barcode: '0123456789012', name: 'كوكا كولا 330 مل', cost: 0.5, price: 1.0, stock: 50, category: 'مشروبات' },
      { barcode: '0123456789013', name: 'بيبسي 330 مل', cost: 0.5, price: 1.0, stock: 45, category: 'مشروبات' },
      { barcode: '0123456789014', name: 'شيبس Lays', cost: 0.75, price: 1.5, stock: 30, category: 'وجبات خفيفة' },
      { barcode: '0123456789015', name: 'بسكويت أوريو', cost: 1.0, price: 2.0, stock: 25, category: 'وجبات خفيفة' },
      { barcode: '0123456789016', name: 'عصير برتقال 1 لتر', cost: 1.5, price: 3.0, stock: 20, category: 'مشروبات' },
      { barcode: '0123456789017', name: 'حليب طازج 1 لتر', cost: 1.2, price: 2.5, stock: 35, category: 'ألبان' },
      { barcode: '0123456789018', name: 'جبنة شرائح', cost: 2.0, price: 4.0, stock: 15, category: 'ألبان' },
      { barcode: '0123456789019', name: 'خبز عربي', cost: 0.3, price: 0.5, stock: 100, category: 'مخبوزات' },
      { barcode: '0123456789020', name: 'قهوة عربية 250جم', cost: 3.0, price: 5.5, stock: 18, category: 'مشروبات' },
      { barcode: '0123456789021', name: 'شاي أسود 500جم', cost: 2.5, price: 4.5, stock: 22, category: 'مشروبات' },
    ];
    samples.forEach(s => Products.add(s));
  }

  // إضافة عملاء تجريبيين
  if (Customers.all().length === 0) {
    Customers.add({ name: 'أحمد محمد', phone: '0501234567', address: 'الرياض - حي العليا' });
    Customers.add({ name: 'فاطمة علي', phone: '0507654321', address: 'جدة - الروضة' });
  }
}

// تهيئة عند التحميل
initializeDB();
