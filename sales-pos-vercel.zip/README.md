# Sales POS - Vercel Deployment

## Steps to deploy:

1. **Create a GitHub account** (https://github.com) - 2 minutes
2. **Create a new repository** on GitHub (e.g., `sales-pos`)
3. **Upload all files** in this folder to the repository
4. **Connect Vercel to GitHub** (https://vercel.com/new)
5. **Import the repository** on Vercel
6. **Add Environment Variable**:
   - Key: `JSONBIN_MASTER_KEY`
   - Value: (your JSONBin Master Key)
7. **Click Deploy**

## Default Login:
- Username: `admin`
- Password: `admin123`
