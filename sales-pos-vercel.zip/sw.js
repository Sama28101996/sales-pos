// =====================================================
// Service Worker - تشغيل التطبيق offline + cache
// =====================================================

const CACHE_NAME = 'sales-app-v3-' + Date.now();
const RUNTIME_CACHE = 'sales-runtime-v3';

const PRECACHE_URLS = [
  './',
  './index.html',
  './manifest.json',
  './css/style.css',
  './js/db.js',
  './js/i18n.js',
  './js/auth.js',
  './js/scanner.js',
  './js/enhancements.js',
  './js/inventory.js',
  './js/sales.js',
  './js/purchase.js',
  './js/customers.js',
  './js/team.js',
  './js/teamReport.js',
  './js/settingsPage.js',
  './js/reports.js',
  './js/invoice.js',
  './js/backup.js',
  './js/productImages.js',
  './js/debtReminders.js',
  './js/app.js',
];

// ===== التثبيت =====
self.addEventListener('install', (event) => {
  console.log('[SW] Installing...');
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('[SW] Pre-caching app shell');
        return cache.addAll(PRECACHE_URLS).catch((err) => {
          console.warn('[SW] Some files failed to cache:', err);
        });
      })
      .then(() => self.skipWaiting())
  );
});

// ===== التفعيل - حذف caches القديمة =====
self.addEventListener('activate', (event) => {
  console.log('[SW] Activating...');
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter((name) => name !== CACHE_NAME && name !== RUNTIME_CACHE)
          .map((name) => {
            console.log('[SW] Deleting old cache:', name);
            return caches.delete(name);
          })
      );
    }).then(() => self.clients.claim())
  );
});

// ===== استراتيجية: Network First ثم Cache =====
self.addEventListener('fetch', (event) => {
  const { request } = event;

  // طلبات POST/PUT لا نتدخل بها
  if (request.method !== 'GET') return;

  // تجاهل طلبات chrome-extension
  if (request.url.startsWith('chrome-extension://')) return;

  // تجاهل طلبات Google APIs (لا نريد تخزينها)
  if (request.url.includes('googleapis.com') || request.url.includes('accounts.google.com')) {
    return;
  }

  event.respondWith(
    fetch(request)
      .then((response) => {
        // إذا نجح الطلب، نخزن نسخة في cache
        if (response && response.status === 200 && response.type === 'basic') {
          const responseClone = response.clone();
          caches.open(RUNTIME_CACHE).then((cache) => {
            cache.put(request, responseClone);
          });
        }
        return response;
      })
      .catch(() => {
        // إذا فشل الطلب (offline)، نبحث في cache
        return caches.match(request).then((cachedResponse) => {
          if (cachedResponse) {
            return cachedResponse;
          }
          // fallback للصفحة الرئيسية
          if (request.mode === 'navigate') {
            return caches.match('./index.html');
          }
        });
      })
  );
});

// ===== استقبال رسائل من الصفحة =====
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});
